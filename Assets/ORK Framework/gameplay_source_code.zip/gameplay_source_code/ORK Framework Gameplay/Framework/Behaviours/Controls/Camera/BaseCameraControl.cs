
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Controls/Camera: Top Down Border")]
	public abstract class BaseCameraControl : MonoBehaviour
	{
		private GameObject cameraTarget;
		
		public GameObject CameraTarget
		{
			get
			{
				if(this.cameraTarget == null)
				{
					return ORK.Game.GetPlayer();
				}
				else
				{
					return this.cameraTarget;
				}
			}
			set{ this.cameraTarget = value;}
		}
	}
}
