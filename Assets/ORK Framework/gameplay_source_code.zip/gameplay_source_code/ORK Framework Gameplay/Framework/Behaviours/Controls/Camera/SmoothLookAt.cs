
using ORKFramework;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Controls/Camera: Smooth Look At")]
	public class SmoothLookAt : BaseCameraControl
	{
		public string onChild = "";

		public float damping = 6.0f;

		public bool smooth = true;
	
		void Start()
		{
			if(rigidbody)
			{
				rigidbody.freezeRotation = true;
			}
		}
	
		void LateUpdate()
		{
			GameObject obj = TransformHelper.GetChildObject(this.onChild, this.CameraTarget);
			if(obj != null)
			{
				Transform target = obj.transform;
			
				if(smooth)
				{
					// Look at and dampen the rotation
					Quaternion rotation = Quaternion.LookRotation(target.position - transform.position);
					if(this.damping > 0)
					{
						transform.rotation = Quaternion.Slerp(transform.rotation, rotation, Time.deltaTime * this.damping);
					}
					else
					{
						transform.rotation = rotation;
					}
				}
				else
				{
					// Just lookat
					transform.LookAt(target);
				}
			}
		}
	}
}
