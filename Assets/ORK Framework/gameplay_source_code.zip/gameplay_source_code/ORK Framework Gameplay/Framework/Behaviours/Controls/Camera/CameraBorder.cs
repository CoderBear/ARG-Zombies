
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Controls/Camera Border")]
	public class CameraBorder : MonoBehaviour
	{
		// set height to upper border
		public bool useBorderHeight = false;
		
		
		// set start rotation
		public bool setRotation = false;
		
		public float rotation = 0;
		
		
		// set padding
		public bool setPadding = false;
		
		public Vector4 positionPadding = new Vector4(0, 0, 0, 0);
		
		
		// collider
		private Collider colliderComponent;
		
		void Start()
		{
			this.colliderComponent = this.GetComponent<Collider>();
		}
		
		public void UpdatePosition(ref Vector3 position, Vector4 padding)
		{
			if(this.colliderComponent != null)
			{
				if(this.setPadding)
				{
					padding = this.positionPadding;
				}
				
				// clamp to border
				// x-axis
				if(position.x < this.colliderComponent.bounds.min.x + padding.x)
				{
					position.x = this.colliderComponent.bounds.min.x + padding.x;
				}
				else if(position.x > this.colliderComponent.bounds.max.x - padding.z)
				{
					position.x = this.colliderComponent.bounds.max.x - padding.z;
				}
				// z-axis
				if(position.z > this.colliderComponent.bounds.max.z - padding.y)
				{
					position.z = this.colliderComponent.bounds.max.z - padding.y;
				}
				else if(position.z < this.colliderComponent.bounds.min.z + padding.w)
				{
					position.z = this.colliderComponent.bounds.min.z + padding.w;
				}
			}
		}
		
		public void UpdateCameraHeight(ref Vector3 position)
		{
			if(this.colliderComponent != null && this.useBorderHeight)
			{
				position.y = this.colliderComponent.bounds.max.y;
			}
		}
		
		
		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "CameraBorder.psd");
		}
	}
}
