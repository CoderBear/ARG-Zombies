
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Scenes/Add Combatant")]
	public class AddCombatant : MonoBehaviour
	{
		public BattleSystemType battleType = BattleSystemType.TurnBased;
		
		[ORKEditorInfo(ORKDataType.Faction)]
		public int factionID = 0;
		
		public CombatantGroupMember combatantSetting = new CombatantGroupMember();
		
		
		// waypoint settings
		public bool randomWaypointOrder = false;
		
		public GameObject[] waypoints = new GameObject[0];
		
		void Start()
		{
			Combatant combatant = this.combatantSetting.Create(new Group(this.factionID));
			combatant.GameObject = this.gameObject;
			combatant.Group.BattleType = this.battleType;
			
			if(this.waypoints.Length > 0 && combatant.MoveAI != null)
			{
				combatant.MoveAI.SetWaypoints(this.waypoints, this.randomWaypointOrder);
			}
			
			GameObject.Destroy(this);
		}
		
		
		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "Combatant.psd");
		}
	}
}
