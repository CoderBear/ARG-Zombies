
using UnityEngine;
using UnityEngine.UI;
using ORKFramework;
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("")]
	public class DisplayText : MonoBehaviour, IEventStarter
	{
		private DisplayTextSettings settings;
		
		private GameObject combatant;
		
		private Vector3 screenPosition;
		
		
		// move
		private MoveEvent moveEvent;
		
		
		// color for fading
		private Color color = new Color(1, 1, 1, 1);
		
		
		// text
		private string text;
		
		private Color textColor;
	
		private Color shadowColor;
		
		
		// count to value
		private bool counting = false;
	
		private int value = 0;
	
		private int currentValue = 0;
	
		private int startValue = 0;
	
		private int countDistance = 0;
		
		private float time = 0;
	
		private Function countInterpolate;
		
		
		// new UI
		private RectTransform textRect;
		
		private Text textComp;
		
		private CanvasRenderer textRenderer;
		
		
		/*
		============================================================================
		Get/set functions
		============================================================================
		*/
		public Color Color
		{
			get{ return this.color;}
			set
			{
				if(this.color != value)
				{
					this.color = value;
					
					if(this.textRenderer != null)
					{
						this.textRenderer.SetColor(this.color);
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Show functions
		============================================================================
		*/
		public void ShowNumber(int i, GameObject c, DisplayTextSettings ts)
		{
			this.combatant = c;
			this.settings = ts;
			if(this.InitSettings())
			{
				this.text = this.settings.text[ORK.Game.Language];
				this.value = i;
				this.startValue = (int)((this.value / 100.0f) * this.settings.startCountFrom);
				this.countDistance = this.value - this.startValue;
				this.countInterpolate = Interpolate.Ease(this.settings.countInterpolate);
				this.counting = true;
				this.CreateObject();
			}
		}
		
		public void ShowText(string t, GameObject c, DisplayTextSettings ts)
		{
			this.combatant = c;
			this.settings = ts;
			if(this.InitSettings())
			{
				this.text = t;
				this.CreateObject();
			}
		}
		
		
		/*
		============================================================================
		Init functions
		============================================================================
		*/
		private bool InitSettings()
		{
			if(this.settings != null)
			{
				this.textColor = this.settings.textFormat.GetTextColor();
				if(this.settings.textFormat.showShadow)
				{
					this.shadowColor = this.settings.textFormat.GetShadowColor();
				}
				
				if(this.settings.localSpace)
				{
					this.transform.localPosition += this.settings.baseOffset + new Vector3(
							Random.Range(this.settings.randomOffsetFrom.x, this.settings.randomOffsetTo.x),
							Random.Range(this.settings.randomOffsetFrom.y, this.settings.randomOffsetTo.y),
							Random.Range(this.settings.randomOffsetFrom.z, this.settings.randomOffsetTo.z));
				}
				else
				{
					this.transform.position += this.settings.baseOffset + new Vector3(
							Random.Range(this.settings.randomOffsetFrom.x, this.settings.randomOffsetTo.x),
							Random.Range(this.settings.randomOffsetFrom.y, this.settings.randomOffsetTo.y),
							Random.Range(this.settings.randomOffsetFrom.z, this.settings.randomOffsetTo.z));
				}
				this.screenPosition = VectorHelper.GetScreenPosition(this.transform.position);
				
				if(this.settings.useFlash && this.settings.flash != null)
				{
					EventFader fader = ComponentHelper.Get<EventFader>(this.combatant);
					fader.Flash(this.settings.flash, this.settings.flashChildren, this.settings.shared, 
						this.settings.setProp ? this.settings.prop : "_Color", this.settings.isFloat);
				}
				
				if(this.settings.moveEvent != null)
				{
					List<GameObject> tmp = new List<GameObject>();
					tmp.Add(this.gameObject);
					this.moveEvent = new MoveEvent(tmp);
					this.moveEvent.SetData(this.settings.moveEvent.GetData().ToDataObject());
					this.moveEvent.StartEvent(this, this.gameObject);
				}
				return true;
			}
			else
			{
				GameObject.Destroy(this.gameObject);
			}
			return false;
		}
		
		private void CreateObject()
		{
			if(ORK.GUI.IsNewUI)
			{
				Vector2 pos = new Vector2(this.screenPosition.x, this.screenPosition.y);
				
				Vector2 v = UIHelper.CalculateTextSize(this.text, this.settings.textFormat);
				pos.x -= v.x / 2;
				pos.y -= v.y / 2;
				
				pos = ORK.Core.GUIMatrix.MultiplyPoint3x4(pos);
				
				GameObject gameObject = UIHelper.CreateText(this.text, 
					new Rect(pos.x, -pos.y, v.x, v.y), 
					this.settings.textFormat, ORK.GUI.NotificationLayer);
				
				this.textRect = gameObject.GetComponent<RectTransform>();
				
				this.textComp = gameObject.GetComponent<Text>();
				this.textComp.alignment = TextAnchor.MiddleCenter;
				// TODO: set vertical overflow instead of bound size > currently not exposed
				
				this.textRenderer = gameObject.GetComponent<CanvasRenderer>();
				if(this.textRenderer != null)
				{
					this.textRenderer.SetColor(this.color);
				}
			}
		}
		
		
		/*
		============================================================================
		Update functions
		============================================================================
		*/
		void Update()
		{
			if(this.text != null && this.settings != null)
			{
				float t = ORK.Game.DeltaTime;
				this.time += t;
				
				if(this.moveEvent != null)
				{
					this.moveEvent.Tick(t);
				}
				else if(this.time >= this.settings.destroyTime)
				{
					GameObject.Destroy(this.gameObject);
				}
				
				if(this.countInterpolate != null)
				{
					if(this.time <= this.settings.countTime)
					{
						this.currentValue = (int)Interpolate.Ease(this.countInterpolate, this.startValue, this.countDistance, this.time, this.settings.countTime);
					}
					if(this.time >= this.settings.countTime)
					{
						this.currentValue = this.value;
						this.countInterpolate = null;
						this.text = this.text.Replace("%", this.currentValue.ToString());
						this.counting = false;
					}
				}
				this.screenPosition = VectorHelper.GetScreenPosition(this.transform.position);
				
				// new UI
				if(this.textRect != null)
				{
					if(this.counting)
					{
						this.textComp.text = this.text.Replace("%", this.currentValue.ToString());
					}
					else
					{
						this.textComp.text = this.text;
					}
					
					Vector2 pos = new Vector2(this.screenPosition.x, this.screenPosition.y);
					
					Vector2 v = UIHelper.CalculateTextSize(this.textComp.text, this.settings.textFormat);
					pos.x -= v.x / 2;
					pos.y -= v.y / 2;
					
					pos = ORK.Core.GUIMatrix.MultiplyPoint3x4(pos);
					
					this.textRect.anchoredPosition = new Vector2(pos.x, -pos.y);
					this.textRect.sizeDelta = new Vector2(v.x, v.y);
				}
			}
		}
		
		void OnGUI()
		{
			if(!ORK.GUI.IsNewUI && this.text != null && this.settings != null)
			{
				GUI.color = this.color;
				
				GUISkin tmp = GUI.skin;
				if(this.settings.GUISkin)
				{
					GUI.skin = this.settings.GUISkin;
				}
				else if(ORK.BattleTexts.GUISkin)
				{
					GUI.skin = ORK.BattleTexts.GUISkin;
				}
				
				GUIContent content = new GUIContent(this.text);
				
				if(this.counting)
				{
					content.text = content.text.Replace("%", this.currentValue.ToString());
				}
				
				GUI.matrix = ORK.Core.GUIMatrix;
				Vector2 pos = new Vector2(this.screenPosition.x, this.screenPosition.y);
				
				GUIStyle textStyle = new GUIStyle(GUI.skin.label);
				if(this.settings.textFormat.font != null)
				{
					textStyle.font = this.settings.textFormat.font;
				}
				textStyle.fontSize = this.settings.textFormat.fontSize;
				textStyle.fontStyle = this.settings.textFormat.fontStyle;
				
				Vector2 v = textStyle.CalcSize(content);
				pos.x -= v.x / 2;
				pos.y -= v.y / 2;
				
				if(this.settings.textFormat.showShadow)
				{
					textStyle.normal.textColor = this.shadowColor;
					GUI.Label(this.settings.textFormat.GetShadowRect(pos, v), content, textStyle); 
				}
				
				textStyle.normal.textColor = this.textColor;
				GUI.Label(new Rect(pos.x, pos.y, v.x, v.y), content, textStyle);
				
				GUI.skin = tmp;
			}
		}
		
		
		/*
		============================================================================
		Event functions
		============================================================================
		*/
		public void EventEnded()
		{
			GameObject.Destroy(this.gameObject);
		}
	
		public void DontDestroy()
		{
			
		}
	
		public GameObject GameObject
		{
			get{ return this.gameObject;}
		}
		
		void OnDestroy()
		{
			if(this.textRect != null)
			{
				GameObject.Destroy(this.textRect.gameObject);
			}
		}
	}
}
