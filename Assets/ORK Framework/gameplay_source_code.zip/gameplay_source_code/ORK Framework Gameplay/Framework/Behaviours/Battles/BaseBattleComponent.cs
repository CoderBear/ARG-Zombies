
using ORKFramework;
using ORKFramework.Events;
using System.Collections.Generic;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	public abstract class BaseBattleComponent : BaseInteraction
	{
		protected string sceneName = "";
		
		public bool IsSceneIDSet()
		{
			return this.useSceneID && 
				ORK.Game.Scene.IsBattleFinished(this.sceneName, this.sceneID);
		}
		
		public virtual void SetSceneID()
		{
			if(this.useSceneID)
			{
				ORK.Game.Scene.BattleFinished(this.sceneName, this.sceneID);
			}
		}
		
		public override bool CanInteract(EventStartType type, GameObject gameObject)
		{
			return base.CanInteract(type, gameObject) && !this.IsSceneIDSet();
		}
	}
}
