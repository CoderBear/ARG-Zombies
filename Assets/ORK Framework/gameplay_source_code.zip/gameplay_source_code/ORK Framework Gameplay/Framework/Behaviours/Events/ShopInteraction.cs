
using ORKFramework;
using ORKFramework.Events;
using ORKFramework.Shop;
using System.Collections;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Events/Shop Interaction")]
	public class ShopInteraction : BaseInteraction, IEventStarter
	{
		public string shopSceneID = "";
		
		[ORKEditorInfo(ORKDataType.Shop)]
		public int shopID = 0;
		
		
		// turn
		public bool turnToEvent = true;
		
		public bool turnToPlayer = false;
		
		
		// faction settings
		public bool useFaction = false;
		
		[ORKEditorInfo(ORKDataType.Faction)]
		public int factionID = 0;
		
		
		// ingame
		private ShopScreen shopScreen;
		
		
		/*
		============================================================================
		Interaction type functions
		============================================================================
		*/
		public override InteractionType Type
		{
			get{ return InteractionType.Shop;}
		}
		
		
		/*
		============================================================================
		Event functions
		============================================================================
		*/
		public override void StartEvent(GameObject startingObject)
		{
			this.CancelInvoke("AutoDestroy");
			this.isInvoking = false;
			
			if(!this.eventStarted)
			{
				this.eventStarted = true;
				
				// do turns
				GameObject p = startingObject != null ? startingObject : ORK.Game.GetPlayer();
				if(this.turnToEvent && p != null)
				{
					p.transform.LookAt(new Vector3(this.transform.position.x, p.transform.position.y, this.transform.position.z));
				}
				if(this.turnToPlayer && p != null)
				{
					this.transform.LookAt(new Vector3(p.transform.position.x, this.transform.position.y, p.transform.position.z));
				}
				
				this.shopScreen = new ShopScreen(this, this.shopID, this.shopSceneID, this.useFaction ? this.factionID : -1);
			}
		}
		
		public void EventEnded()
		{
			this.shopScreen = null;
			this.SetVariables();
			this.eventStarted = false;
		}
		
		public void DontDestroy()
		{
		
		}
		
		public GameObject GameObject
		{
			get{ return this.gameObject;}
		}
		
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "ShopEvent.psd");
		}
	}
}
