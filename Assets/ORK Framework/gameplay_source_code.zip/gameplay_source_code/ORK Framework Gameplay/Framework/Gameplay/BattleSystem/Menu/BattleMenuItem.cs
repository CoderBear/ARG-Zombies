
using System.Collections.Generic;
using UnityEngine;

namespace ORKFramework
{
	public class BattleMenuItem : BaseData
	{
		[ORKEditorHelp("Type", "Select the type of the battle menu option/command:\n" +
			"- Attack: The combatant's base or counter attack.\n" +
			"- Ability: Lists the combatant's abilities.\n" +
			"- Class Ability: The combatant's class ability (will only be displayed if a class ability is available).\n" +
			"- Item: Lists the combatant's items.\n" +
			"- Defend: Uses the combatant's defend command.\n" +
			"- Escape: Uses the combatant's escape command.\n" +
			"- End: Ends the combatant's turn.\n" +
			"- Auto: Automatically selects a command using the combatant's AI settings.\n" +
			"- Equipment: Lists the combatant's equipment parts and allows changing the equipment (similar to the equipment menu).\n" +
			"- Command: Give a member of the combatant's group a command (i.e. the next action they should use).\n" +
			"- Change Member: Lists the combatant group's non-battle members and allows changing the combatant.", "")]
		public BMItemType type = BMItemType.Attack;
		
		
		// ability/item
		[ORKEditorHelp("Type Display", "Select how ability/item types are displayed:\n" +
			"- Combined: All types are displayed in a combined option. You can display the types in a sub-menu.\n" +
			"- Type: All types are listed individually.\n" +
			"- List: All abilities/items are listed directly, without any type list.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout(new string[] {"type", "type"}, 
			new System.Object[] {BMItemType.Ability, BMItemType.Item}, 
			needed=Needed.One, setDefault=true, defaultValue=BMTypeDisplay.Combined)]
		public BMTypeDisplay typeDisplay = BMTypeDisplay.Combined;
		
		[ORKEditorHelp("Sub Menu", "Display the ability/item types in a sub-menu.\n" +
			"If disabled, all abilities/items will be displayed without a type filter.", "")]
		[ORKEditorLayout("typeDisplay", BMTypeDisplay.Combined, endCheckGroup=true, endGroups=2, 
			setDefault=true, defaultValue=false)]
		public bool subMenu = false;
		
		
		// sorting
		[ORKEditorInfo(separator=true, labelText="Type Sorting")]
		[ORKEditorLayout(new string[] {"typeDisplay", "subMenu"}, 
			new System.Object[] {BMTypeDisplay.Type, true}, needed=Needed.One, 
			endCheckGroup=true, autoInit=true)]
		public TypeSorter typeSorter;
		
		[ORKEditorInfo(separator=true, labelText="List Sorting")]
		[ORKEditorLayout(new string[] {"type", "type"}, 
			new System.Object[] {BMItemType.Ability, BMItemType.Item}, 
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public ContentSorter contentSorter;
		
		
		// button
		[ORKEditorHelp("Use Ability Information", "Use the name, icon and description of the ability for the button.\n" +
			"The button will also display the use costs of the ability.", "")]
		[ORKEditorInfo(separator=true, labelText="Button Settings")]
		[ORKEditorLayout(new string[] {"type", "type"}, 
			new System.Object[] {BMItemType.Attack, BMItemType.ClassAbility}, 
			needed=Needed.One, endCheckGroup=true, 
			setDefault=true, defaultValue=false)]
		public bool useAbilityInfo = false;
		
		[ORKEditorArray(dataType=ORKDataType.Language, foldout=true, languageFoldout=true)]
		[ORKEditorInfo(separator=true, labelText="Button Content")]
		[ORKEditorLayout(new string[] {"typeDisplay", "useAbilityInfo"}, 
			new System.Object[] {BMTypeDisplay.Combined, false}, endCheckGroup=true, 
			autoInit=true, autoLangSize=true)]
		public LanguageInfo[] button;
		
		
		// equip
		// equipment part list
		// layout
		[ORKEditorInfo("Part Content Layout", "Define the layout of the equipment part buttons.", "", 
			endFoldout=true)]
		[ORKEditorLayout("type", BMItemType.Equipment)]
		public TitleContentLayout partContentLayout = new TitleContentLayout(
			ContentLayoutType.Both, ContentLayoutType.Both, ContentLayoutInfoType.None);
		
		// empty button
		[ORKEditorInfo("Empty Button", "The empty button is displayed when an equipment part has nothing equipped.", "", 
			endFoldout=true)]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		[ORKEditorLayout(endCheckGroup=true)]
		public LanguageInfo[] emptyPartButton = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"Empty"});
		
		
		// command
		[ORKEditorHelp("Only AI Combatants", "Commands can only be given to AI controlled combatants of the group.\n" +
			"If disabled, commands can be given to all combatants of the group.", "")]
		[ORKEditorLayout("type", BMItemType.Command, endCheckGroup=true)]
		public bool onlyAICombatants = false;
		
		public BattleMenuItem()
		{
			
		}
		
		
		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public void AddToMenu(ref List<BMItem> list, Combatant owner, BattleMenu bm)
		{
			// attack option
			if(BMItemType.Attack.Equals(this.type))
			{
				AbilityShortcut ability = owner.GetCurrentBaseAttack();
				BMItem bmi = new AbilityBMItem(ability, bm.contentLayout.GetChoiceContent(ability, owner));
				if(!this.useAbilityInfo)
				{
					bmi.content = bm.contentLayout.GetChoiceContent(this.button);
				}
				list.Add(bmi);
			}
			// ability option
			else if(BMItemType.Ability.Equals(this.type))
			{
				// combined
				if(BMTypeDisplay.Combined.Equals(this.typeDisplay))
				{
					list.Add(new TypeBMItem(bm.contentLayout.GetChoiceContent(this.button), 
						this.type, -1, this, false));
				}
				// list types
				else if(BMTypeDisplay.Type.Equals(this.typeDisplay))
				{
					List<int> types = owner.Abilities.GetTypes(UseableIn.Battle);
					this.typeSorter.Sort(ref types, ORKDataType.AbilityType);
					foreach(int id in types)
					{
						list.Add(new TypeBMItem(
							bm.contentLayout.GetChoiceContent(ORK.AbilityTypes.Get(id)), 
							this.type, id, this, false));
					}
				}
				// list abilities
				else if(BMTypeDisplay.List.Equals(this.typeDisplay))
				{
					List<AbilityShortcut> abilities = owner.Abilities.GetAbilities(UseableIn.Battle);
					this.contentSorter.Sort(ref abilities);
					foreach(AbilityShortcut ability in abilities)
					{
						list.Add(new AbilityBMItem(ability, bm.contentLayout.GetChoiceContent(ability, owner)));
					}
				}
			}
			// class ability option
			else if(BMItemType.ClassAbility.Equals(this.type) && owner.Abilities.HasClassAbility())
			{
				AbilityShortcut ability = owner.Abilities.GetClassAbility();
				BMItem bmi = new AbilityBMItem(ability, bm.contentLayout.GetChoiceContent(ability, owner));
				if(!this.useAbilityInfo)
				{
					bmi.content = bm.contentLayout.GetChoiceContent(this.button);
				}
				list.Add(bmi);
			}
			// item option
			else if(BMItemType.Item.Equals(this.type))
			{
				// combined
				if(BMTypeDisplay.Combined.Equals(this.typeDisplay))
				{
					list.Add(new TypeBMItem(bm.contentLayout.GetChoiceContent(this.button), 
						this.type, -1, this, false));
				}
				// list types
				else if(BMTypeDisplay.Type.Equals(this.typeDisplay))
				{
					List<int> types = owner.Inventory.GetUseableItemTypes(UseableIn.Battle);
					this.typeSorter.Sort(ref types, ORKDataType.ItemType);
					foreach(int id in types)
					{
						list.Add(new TypeBMItem(
							bm.contentLayout.GetChoiceContent(ORK.ItemTypes.Get(id)), 
							this.type, id, this, false));
					}
				}
				// list items
				else if(BMTypeDisplay.List.Equals(this.typeDisplay))
				{
					List<IShortcut> items = owner.Inventory.GetUseableItems(UseableIn.Battle);
					this.contentSorter.Sort(ref items);
					for(int i=0; i<items.Count; i++)
					{
						if(items[i] is ItemShortcut)
						{
							list.Add(new ItemBMItem(items[i] as ItemShortcut, 
								bm.contentLayout.GetChoiceContent(items[i], owner)));
						}
					}
				}
			}
			// equip option
			else if(BMItemType.Equipment.Equals(this.type))
			{
				list.Add(new EquipmentPartBMItem(bm.contentLayout.GetChoiceContent(this.button), -1, this));
			}
			// command option
			else if(BMItemType.Command.Equals(this.type))
			{
				list.Add(new CommandBMItem(bm.contentLayout.GetChoiceContent(this.button), null, this));
			}
			// change member option
			else if(BMItemType.ChangeMember.Equals(this.type))
			{
				list.Add(new ChangeMemberBMItem(bm.contentLayout.GetChoiceContent(this.button), null));
			}
			// defend, escape, end option
			else if(BMItemType.Defend.Equals(this.type) || 
				BMItemType.Escape.Equals(this.type) || 
				BMItemType.End.Equals(this.type) || 
				BMItemType.Auto.Equals(this.type))
			{
				list.Add(new BaseBMItem(bm.contentLayout.GetChoiceContent(this.button), this.type));
			}
		}
	}
}
