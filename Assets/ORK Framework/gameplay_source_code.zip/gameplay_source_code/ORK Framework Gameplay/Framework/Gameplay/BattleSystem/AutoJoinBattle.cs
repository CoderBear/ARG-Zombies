
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class AutoJoinBattle : BaseData
	{
		[ORKEditorHelp("Auto Join", "Combatants within a defined range of a battle will " +
			"automatically join the battle when it starts.\n" +
			"If disabled, only combatants defined by the battle or " +
			"that are part of a combatant's group will participate in the battle.\n" +
			"Note that this isn't used for real time area battles.", "")]
		public bool autoJoin = false;
		
		[ORKEditorHelp("Use Player", "The player's current position is used for range checks.\n" +
			"If disabled, the battle's position is used.", "")]
		[ORKEditorLayout("autoJoin", true)]
		public bool usePlayer = false;
		
		[ORKEditorHelp("Join Running Battle", "Combatants also join a running battle when coming within range.\n" +
			"If disabled, only combatants within range at the start of the battle will join.", "")]
		public bool runningBattle = false;
		
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public Range range;
		
		public AutoJoinBattle()
		{
			
		}
		
		public List<Combatant> GetCombatants(Vector3 position)
		{
			if(this.autoJoin)
			{
				if(this.usePlayer && ORK.Game.ActiveGroup.Leader != null && 
					ORK.Game.ActiveGroup.Leader.GameObject != null)
				{
					position = ORK.Game.ActiveGroup.Leader.GameObject.transform.position;
				}
				
				return ORK.Game.Combatants.Get(position, ORK.Game.ActiveGroup.Leader, false, 
					this.range, Consider.Ignore, Consider.No, Consider.No);
			}
			return new List<Combatant>();
		}
	}
}
