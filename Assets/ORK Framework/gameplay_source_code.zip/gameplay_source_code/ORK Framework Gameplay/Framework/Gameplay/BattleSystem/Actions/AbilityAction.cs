
using System.Collections.Generic;
using UnityEngine;
using ORKFramework.Behaviours;

namespace ORKFramework
{
	public class AbilityAction : BaseAction
	{
		private AbilityShortcut ability;
		
		// ability casting
		public float castTime = -2;
	
		public float castTimeMax = -1;
		
		public bool castMove = true;
	
		public bool casted = false;
		
		public AbilityAction(Combatant user, AbilityShortcut ability)
		{
			this.user = user;
			this.ability = ability;
			
			ActiveAbility activeLevel = this.ability.GetActiveLevel();
			if(activeLevel != null)
			{
				this.targetDead = activeLevel.targetSettings.isDead;
				this.targetRaycast = activeLevel.targetSettings.targetRaycast;
				
				if(AbilityActionType.CounterAttack.Equals(this.ability.Type))
				{
					this.consumeTime = false;
				}
				else
				{
					if(activeLevel.endTurn)
					{
						this.timeUse = ORK.BattleSystem.activeTime.actionBorder;
					}
					else
					{
						this.timeUse = activeLevel.timebarUse;
					}
				}
			}
		}
		
		public override bool IsType(ActionType t)
		{
			return (ActionType.Attack.Equals(t) && AbilityActionType.BaseAttack.Equals(this.ability.Type)) || 
				(ActionType.CounterAttack.Equals(t) && AbilityActionType.CounterAttack.Equals(this.ability.Type)) || 
				(ActionType.Ability.Equals(t) && AbilityActionType.Ability.Equals(this.ability.Type));
		}
		
		public override string GetName()
		{
			return this.ability.GetName();
		}
		
		public override void SetTarget(Combatant t)
		{
			this.target = new List<Combatant>();
			this.target.Add(t);
		}
		
		public override void SetTargets(List<Combatant> t)
		{
			this.target = t;
		}
		
		public override void AutoTarget(List<Combatant> preferredTargets, List<Combatant> allies, List<Combatant> enemies)
		{
			if(this.user.Status.AttackAllies)
			{
				enemies = allies;
			}
			this.ability.GetActiveLevel().targetSettings.SetAutoTargets(this, preferredTargets, allies, enemies);
		}
		
		public override bool SetGroupTarget()
		{
			Combatant tmpTarget = this.user.Group.SelectedTargets.GetAbilityTarget(this.user, this.ability);
			if(tmpTarget != null)
			{
				this.SetTarget(tmpTarget);
				return true;
			}
			return false;
		}
		
		public override bool SetIndividualTarget()
		{
			Combatant tmpTarget = this.user.SelectedTargets.GetAbilityTarget(this.user, this.ability);
			if(tmpTarget != null)
			{
				this.SetTarget(tmpTarget);
				return true;
			}
			return false;
		}
		
		
		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool CanDamage(Combatant c)
		{
			return (this.user.Status.AttackAllies || 
				this.ability.CanTarget(this.user, c));
		}
		
		
		/*
		============================================================================
		Damage dealer functions
		============================================================================
		*/
		public override void AutoActivateUserDamageDealers(bool activate)
		{
			if(this.user != null && this.user.GameObject != null)
			{
				DamageDealer[] damage = this.user.GameObject.GetComponentsInChildren<DamageDealer>();
				for(int i=0; i<damage.Length; i++)
				{
					if((!this.user.InBattle && damage[i].autoField) || 
						(this.user.InBattle && 
							((ORK.Battle.IsTurnBased() && damage[i].autoTurnBased) || 
							(ORK.Battle.IsActiveTime() && damage[i].autoActiveTime) || 
							(ORK.Battle.IsRealTime() && damage[i].autoRealTime) || 
							(ORK.Battle.IsPhase() && damage[i].autoPhase))))
					{
						damage[i].SetAction(activate ? this : null);
						
						ActiveAbility activeLevel = this.ability.GetActiveLevel();
						if(activeLevel != null)
						{
							damage[i].SetDamageActive(activate, activeLevel.activationTags);
							activeLevel.ddActivation.Add(damage[i], this.user);
						}
					}
				}
			}
		}
		
		public override bool CheckDamageDealer(DamageDealer dealer)
		{
			if(AbilityActionType.Ability.Equals(this.ability.Type))
			{
				for(int i=0; i<dealer.abilityID.Length; i++)
				{
					if(dealer.abilityID[i] == this.ability.ID)
					{
						return true;
					}
				}
			}
			else if(AbilityActionType.BaseAttack.Equals(this.ability.Type))
			{
				return dealer.baseAttack;
			}
			else if(AbilityActionType.CounterAttack.Equals(this.ability.Type))
			{
				return dealer.counterAttack;
			}
			return false;
		}
		
		public override string[] GetActivationTags()
		{
			return this.ability.GetActiveLevel().activationTags;
		}
		
		public override DamageDealerActivation GetDamageDealerActivation()
		{
			return this.ability.GetActiveLevel().ddActivation;
		}
		
		
		/*
		============================================================================
		Ability cast functions
		============================================================================
		*/
		public override bool IsCastingAbility()
		{
			float time = this.ability.GetCastTime(this.user);
			if(!this.casted && time > 0)
			{
				this.castTimeMax = time;
				this.castMove = this.ability.GetActiveLevel().castMove;
				this.castTime = 0;
				if(this.user != null)
				{
					this.user.Actions.CastAbility(this);
					
					if(ORK.ConsoleSettings.displayActions)
					{
						if(this.ability.Setting.ownConsoleCast)
						{
							this.ability.Setting.consoleCast.Print(this.user, this.target, this.ability);
						}
						else
						{
							ORK.ConsoleSettings.actionCast.Print(this.user, this.target, this.ability);
						}
					}
				}
				return true;
			}
			return false;
		}
		
		public override bool CancelAbilityCast()
		{
			if(!this.casted && this.castTime > 0 && this.ability.Cancelable())
			{
				if(ORK.ConsoleSettings.displayActions)
				{
					if(this.ability.Setting.ownConsoleCastCancel)
					{
						this.ability.Setting.consoleCastCancel.Print(this.user, this.target, this.ability);
					}
					else
					{
						ORK.ConsoleSettings.actionCastCancel.Print(this.user, this.target, this.ability);
					}
				}
				return true;
			}
			return false;
		}
		
		
		/*
		============================================================================
		Target selection functions
		============================================================================
		*/
		public override void SetRandomTarget()
		{
			this.AutoTarget(null, 
				ORK.Game.Combatants.Get(this.user, true, Range.Battle, Consider.No, Consider.Ignore, Consider.Ignore), 
				ORK.Game.Combatants.Get(this.user, true, Range.Battle, Consider.Yes, Consider.Ignore, Consider.Ignore));
		}
		
		public override bool TargetNone()
		{
			return this.ability.NoneTarget();
		}
		
		
		/*
		============================================================================
		Range functions
		============================================================================
		*/
		public override bool InRange(Combatant t)
		{
			if(this.user != null && t != null && 
				!this.ability.InRange(this.user, t))
			{
				return false;
			}
			return true;
		}
		
		
		/*
		============================================================================
		Action performing functions
		============================================================================
		*/
		protected override bool PerformCheck()
		{
			return this.user != null && !this.user.Dead && 
				this.ability.CanUse(this.user, false) && 
				(this.ability.GetActiveLevel().targetSettings.NoneTarget() || this.target.Count > 0);
		}
		
		protected override void ActionStartSetup()
		{
			if(ORK.BattleTexts.showInfo)
			{
				if(AbilityActionType.Ability.Equals(this.ability.Type))
				{
					ORK.BattleTexts.abilityInfo.Show(this.user, this.ability.GetName());
				}
				else if(AbilityActionType.BaseAttack.Equals(this.ability.Type))
				{
					ORK.BattleTexts.attackInfo.Show(this.user, this.ability.GetName());
				}
				else if(AbilityActionType.CounterAttack.Equals(this.ability.Type))
				{
					ORK.BattleTexts.counterInfo.Show(this.user, this.ability.GetName());
				}
			}
			
			ActiveAbility activeLevel = this.ability.GetActiveLevel();
			
			if(ORK.ConsoleSettings.displayActions)
			{
				if(this.ability.Setting.ownConsoleAction)
				{
					this.ability.Setting.consoleAction.Print(this.user, this.target, this.ability);
				}
				else
				{
					ORK.ConsoleSettings.actionAbility.Print(this.user, this.target, this.ability);
				}
			}
			
			if(this.target == null || this.target.Count == 0)
			{
				activeLevel.UseCosts(this.user);
				this.userConsumeDone = true;
			}
			if(activeLevel.animate)
			{
				activeLevel.GetAnimations(ref this.events, this.user);
			}
		}

		public override void Calculate(List<Combatant> ts, float damageFactor, bool animate)
		{
			this.results = new ActionResults();
			
			// get affected range targets for this calculation
			ts = this.ability.GetActiveLevel().targetSettings.GetAffectRange(this.user, ts);
			
			if(ORK.BattleSettings.camera.blockEventCams)
			{
				if(ts.Count == 1 && ts[0] != null && ts[0].GameObject != null)
				{
					ORK.BattleSettings.camera.SetLatestDamage(ts[0].GameObject.transform);
				}
				else if(ts.Count > 1)
				{
					ORK.BattleSettings.camera.SetLatestDamage(ORK.Battle.GetGroupCenter(ts).transform);
				}
			}
			
			if(this.user != null && !this.user.Dead && 
				ts.Count > 0 && ts[0] != null)
			{
				this.CheckBestiary(ts);
				
				this.ability.Setting.Use(this.user, ts, animate, this, 
					!AbilityActionType.CounterAttack.Equals(this.ability.Type), 
					!this.userConsumeDone, this.ability.GetLevel(), damageFactor, this.damageMultiplier);
				
				// use level up only once
				if(!this.userConsumeDone)
				{
					// ability
					if(this.user.Abilities.CanGetUseExperience(this.ability))
					{
						this.ability.UsesExperience(this.user, 1);
					}
					// weapons
					if(AbilityActionType.BaseAttack.Equals(this.ability.Type))
					{
						for(int i=0; i<ORK.EquipmentParts.Count; i++)
						{
							if(this.user.Equipment[i].Equipped)
							{
								this.user.Equipment[i].Equipment.UsesExperience(this.user, 1);
							}
						}
					}
				}
				this.userConsumeDone = true;
			}
		}

		protected override void ActionEndSetup()
		{
			// set last ability
			this.user.LastAbilityID = this.ability.ID;
			
			// update base attack index
			if(AbilityActionType.BaseAttack.Equals(this.ability.Type))
			{
				this.user.NextBaseAttack();
			}
			
			// set reuse and delay
			ActiveAbility lvl = this.ability.GetActiveLevel();
			if(lvl != null)
			{
				lvl.SetReuseAfter(this.user, this.ability.ID);
				lvl.SetDelayTime(this.user);
			}
		}
	}
}
