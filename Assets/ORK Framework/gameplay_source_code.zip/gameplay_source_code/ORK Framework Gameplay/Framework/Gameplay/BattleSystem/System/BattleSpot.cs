
using UnityEngine;

namespace ORKFramework
{
	[System.Serializable]
	public class BattleSpot : BaseData
	{
		[ORKEditorHelp("Spot Coordinates", "The position of the spot in local space of the battle arena.\n" +
			"Defined in X, Y and Z coordinates.", "")]
		public Vector3 spot = Vector3.zero;
		
		
		// random
		[ORKEditorHelp("Add Random", "Add a random offset to the cooridnates of this spot.", "")]
		public bool addRandom = false;
		
		[ORKEditorInfo(labelText="Random Offset")]
		[ORKEditorLayout("addRandom", true, endCheckGroup=true, autoInit=true)]
		public RandomVector3 random;
		
		
		// rotation
		[ORKEditorHelp("Set Rotation", "Set the rotation of this spot.", "")]
		[ORKEditorInfo(separator=true, labelText="Rotation Settings")]
		public bool setRotation = false;
		
		[ORKEditorHelp("Rotation", "The rotation of this spot.", "")]
		[ORKEditorLayout("setRotation", true, endCheckGroup=true)]
		public Vector3 rotation = Vector3.zero;
		
		
		// scale
		[ORKEditorHelp("Set Scale", "Set the local scale of this spot.", "")]
		[ORKEditorInfo(separator=true, labelText="Scale Settings")]
		public bool setScale = false;
		
		[ORKEditorHelp("Scale", "The local scale of this spot.", "")]
		[ORKEditorLayout("setScale", true, endCheckGroup=true)]
		public Vector3 scale = Vector3.one;
		
		public BattleSpot()
		{
			
		}
		
		public void SetSpot(Transform arenaTransform, Transform spotTransform)
		{
			if(this.addRandom)
			{
				spotTransform.position = arenaTransform.TransformPoint(this.spot + this.random.GetValue());
			}
			else
			{
				spotTransform.position = arenaTransform.TransformPoint(this.spot);
			}
			
			if(this.setRotation)
			{
				spotTransform.eulerAngles = this.rotation;
			}
			
			if(this.setScale)
			{
				spotTransform.localScale = this.scale;
			}
		}
	}
}
