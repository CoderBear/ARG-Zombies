
namespace ORKFramework
{
	public class BaseBMItem : BMItem
	{
		private BMItemType type = BMItemType.End;
		
		public BaseBMItem(ChoiceContent content, BMItemType type)
		{
			this.content = content;
			this.type = type;
		}
		
		public override bool ActiveCheck(Combatant owner)
		{
			bool tmp = this.content.Active;
			if(BMItemType.Defend.Equals(this.type))
			{
				this.content.Active = !owner.Status.BlockDefend && 
					owner.CanUse(ORK.BattleSystem.activeTime.defendEndTurn, ORK.BattleSystem.activeTime.defendTimebarUse);
			}
			else if(BMItemType.Escape.Equals(this.type))
			{
				this.content.Active = ORK.Battle.CanEscape && !owner.Status.BlockEscape && 
					owner.CanUse(ORK.BattleSystem.activeTime.escapeEndTurn, ORK.BattleSystem.activeTime.escapeTimebarUse);
			}
			else if(BMItemType.Auto.Equals(this.type))
			{
				this.content.Active = !owner.Status.StopMove;
			}
			return tmp != this.content.Active;
		}

		public override void Selected(Combatant owner)
		{
			if(BMItemType.Defend.Equals(this.type))
			{
				owner.BattleMenu.AddAction(new DefendAction(owner));
			}
			else if(BMItemType.Escape.Equals(this.type))
			{
				owner.BattleMenu.AddAction(new EscapeAction(owner));
			}
			else if(BMItemType.End.Equals(this.type))
			{
				owner.EndTurn();
			}
			else if(BMItemType.Auto.Equals(this.type))
			{
				owner.BattleMenu.AddAction(owner.Actions.GetAIBehaviourAction(
					ORK.Game.Combatants.Get(owner, true, Range.Battle, Consider.No, Consider.Ignore, Consider.Ignore), 
					ORK.Game.Combatants.Get(owner, true, Range.Battle, Consider.Yes, Consider.Ignore, Consider.Ignore)));
			}
		}
	}
}
