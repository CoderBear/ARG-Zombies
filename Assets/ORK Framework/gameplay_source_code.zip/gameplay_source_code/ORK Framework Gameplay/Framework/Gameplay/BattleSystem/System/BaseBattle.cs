
using UnityEngine;
using System.Collections.Generic;
using System.Collections;

namespace ORKFramework
{
	public abstract class BaseBattle : BaseData
	{
		// control block settings
		// block player control settings
		[ORKEditorHelp("Block Player Control", "Select when the player control will be blocked:\n" +
			"- None: The control wont be blocked.\n" +
			"- Battle: During the whole battle (i.e. from before the start event till after the end event).\n" +
			"- All Actions: While performing an action (all combatants).\n" +
			"- Player Actions: While performing an action of the player combatant.", "")]
		[ORKEditorInfo("Control Block Settings", "Define if and when the player and " +
			"camera control will be blocked during battle.", "", 
			labelText="Player Control Block")]
		public BattleControlBlock playerControl = BattleControlBlock.None;
		
		[ORKEditorHelp("Block in Battle Menu", "Block the player control while displaying a battle menu.", "")]
		public bool playerBattleMenu = false;
		
		
		// block camera control settings
		[ORKEditorHelp("Block Camera Control", "Select when the camera control will be blocked:\n" +
			"- None: The control wont be blocked.\n" +
			"- Battle: During the whole battle (i.e. from before the start event till after the end event).\n" +
			"- All Actions: While performing an action (all combatants).\n" +
			"- Player Actions: While performing an action of the player combatant.", "")]
		[ORKEditorInfo(separator=true, labelText="Camera Control Block")]
		public BattleControlBlock cameraControl = BattleControlBlock.None;
		
		[ORKEditorHelp("Block in Battle Menu", "Block the camera control while displaying a battle menu.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool cameraBattleMenu = false;
		
		
		// move AI settings
		[ORKEditorHelp("Allow Move AI", "Combatants will use their move AI while fighting.\n" +
			"If disabled, move AI's wont work while a battle is running.", "")]
		[ORKEditorInfo("Move AI Settings", "Set if combatants can use their move AI while in a battle ofthis system type.", "")]
		public bool allowMoveAI = false;
		
		[ORKEditorHelp("Block In Battle", "The move AI of combatants that are participating in battle will be blocked.\n" +
			"If disabled, the move AI of all combatants can be used.", "")]
		[ORKEditorLayout("allowMoveAI", true)]
		public bool blockInBattleMoveAI = false;
		
		[ORKEditorLayout(endCheckGroup=true)]
		[ORKEditorInfo(endFoldout=true)]
		public Range moveAIRange = new Range(50);
		
		
		// start events
		[ORKEditorHelp("Start Event", "Select the ORK battle start event asset used to start battles.\n" +
			"If none is selected, the battle will start right away and place all combatants at their battle spots.\n" +
			"This setting can be overridden by the battle setup in scenes.", "")]
		[ORKEditorInfo("Default Start/End Events", "Define the default battle start and battle end events.\n" +
			"The default events can be overridden in Battle components.", "")]
		public ORKBattleStartEvent startEvent;
		
		// end events
		[ORKEditorHelp("Victory Event", "Select the ORK battle end event asset used to end battles when the player group won.\n" +
			"If none is selected, the battle will end right away and collect all battle gains (without displaying them).\n" +
			"This setting can be overridden by the battle setup in scenes.", "")]
		public ORKBattleEndEvent victoryEvent;
		
		[ORKEditorHelp("Escape Event", "Select the ORK battle end event asset used to end battles when the player group escaped.\n" +
			"If none is selected, the battle will end right away and collect all battle gains (without displaying them).\n" +
			"This setting can be overridden by the battle setup in scenes.", "")]
		public ORKBattleEndEvent escapeEvent;
		
		[ORKEditorHelp("Defeat Event", "Select the ORK battle end event asset used to end battles when the player group has been defeated.\n" +
			"If none is selected, the battle will end right away and collect all battle gains (without displaying them), no game over will be called.\n" +
			"This setting can be overridden by the battle setup in scenes.", "")]
		public ORKBattleEndEvent defeatEvent;
		
		[ORKEditorHelp("Leave Arena Event", "Select the ORK battle end event asset used to end battles when the player has left the battle arena.\n" +
			"If none is selected, the battle will end right away and collect all battle gains (without displaying them).\n" +
			"This setting can be overridden by the battle setup in scenes.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public ORKBattleEndEvent leaveArenaEvent;
		
		
		// leave area settings
		[ORKEditorHelp("Use Leave Arena", "", "")]
		[ORKEditorInfo("Leave Arena Settings", "The battle can optionally end if the player leaves the battle arena.\n" +
			"If used, the player has to move outside a defined range of the battle arena " +
			"(i.e. the game object with the 'Battle' component attached) to trigger the 'Leave Arena' battle end.\n" +
			"Leaving the area will count as escaping in statistics." +
			"Not used in 'Real Time Battle Area' battles.", "")]
		public bool useLeaveArena = false;
		
		[ORKEditorLayout("useLeaveArena", true, endCheckGroup=true)]
		[ORKEditorInfo(endFoldout=true)]
		public Range leaveArenaRange = new Range(20);
		
		
		// battle gains settings
		[ORKEditorHelp("Stack Loot", "The loot (items, equipment and money) will be stacked.\n" +
			"If disabled, the individual items will be added as they're defind by the combatant/loot.", "")]
		[ORKEditorInfo("Battle Gains Collection", "Select if battle gains (loot, experience) are collected immediately " +
			"after an enemy has been defeated or at the end of the battle.\n" +
			"When collecting immediately, items and money can also be dropped into the game world.", "")]
		public bool gainsStack = true;
		
		[ORKEditorHelp("Collect Immediately", "Battle gains are collected immediately after an enemy has been defeated.\n" +
			"If disabled, the battle gains are collected at the end of the battle (in a 'Battle End Event').", "")]
		public bool gainsCollectImmediately = false;
		
		[ORKEditorHelp("Show Gains", "Show the battle gains and level up texts when collecting immediately.\n" +
			"The display options are defined in the battle end settings.", "")]
		[ORKEditorLayout("gainsCollectImmediately", true)]
		public bool gainsShowText = true;
		
		[ORKEditorHelp("Auto Close", "Automatically close the battle gains after a defined time.", "")]
		[ORKEditorLayout("gainsShowText", true)]
		public bool gainsAutoClose = false;
		
		[ORKEditorHelp("Close After (s)", "The time in seconds until the gains dialogue closes automatially.\n" +
			"This time is used for each page of the battle gains.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("gainsAutoClose", true)]
		public float gainsAutoCloseTime = 3;
		
		[ORKEditorHelp("Block Accept Button", "The accept button is blocked - " +
			"the gains dialogue will only close after it's time ran up.", "")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public bool gainsAutoCloseBlockAccept = false;
		
		[ORKEditorHelp("Drop Items", "Items gained from defeated enemies will be dropped into the " +
			"game world instead of added to the group inventory.", "")]
		public bool gainsDropItems = false;
		
		[ORKEditorHelp("Drop Money", "Money gained from defeated enemies will be dropped into the " +
			"game world instead of added to the group inventory.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool gainsDropMoney = false;
		
		
		// bonus settings
		[ORKEditorInfo(separatorForce=true)]
		public BattleBonuses bonuses = new BattleBonuses();
		
		public virtual bool IsDynamicCombat()
		{
			return true;
		}
		
		public virtual bool CanCounter
		{
			get{ return true;}
		}
		
		public virtual bool DeathImmediately
		{
			get{ return false;}
		}
		
		public virtual bool EndImmediately
		{
			get{ return false;}
		}
		
		public virtual bool IsMenuBackAllowed
		{
			get{ return false;}
		}
		
		public virtual bool MenuBlockAutoAttack
		{
			get{ return true;}
		}
		
		public virtual bool CanAutoAttack
		{
			get{ return false;}
		}
		
		public virtual bool DefeatOnPlayerDeath
		{
			get{ return false;}
		}
		
		public virtual bool DefendFirst
		{
			get{ return false;}
		}
		
		
		/*
		============================================================================
		Battle menu functions
		============================================================================
		*/
		public virtual void BattleMenuCanceled(Combatant user)
		{
			
		}
		
		public virtual bool CombatantClicked(Combatant combatant)
		{
			return false;
		}
		
		
		/*
		============================================================================
		Start functions
		============================================================================
		*/
		public virtual void StartBattle(bool changed)
		{
			
		}
		
		public virtual void RemoveFromOrder(Combatant combatant)
		{
			
		}
		
		public virtual void OrderChange(Combatant combatant, int change)
		{
			
		}
		
		public virtual void CombatantChanged(Combatant oldCombatant, Combatant newCombatant)
		{
			
		}
		
		
		/*
		============================================================================
		Tick functions
		============================================================================
		*/
		public virtual void Tick()
		{
			
		}
		
		public virtual bool DoCombatantTick()
		{
			return true;
		}
		
		public virtual void BattleMenuFinished()
		{
			
		}
		
		
		/*
		============================================================================
		Action handling functions
		============================================================================
		*/
		public virtual void ActionAdded(BaseAction action)
		{
			
		}
		
		public virtual void ActionUnshifted(BaseAction action)
		{
			
		}
		
		protected void PerformNextAction()
		{
			ORK.StartCoroutine(this.PerformNextAction2());
		}
		
		protected IEnumerator PerformNextAction2()
		{
			yield return null;
			this.PerformNextAction3();
		}
		
		protected abstract void PerformNextAction3();
		
		public void PerformAction(BaseAction action)
		{
			if(action != null)
			{
				action.PerformAction();
				this.PerformingAction(action);
			}
			else
			{
				this.ActionFinished(null);
			}
		}
		
		public virtual void PerformingAction(BaseAction action)
		{
			
		}
		
		public virtual void ActionFinished(BaseAction action)
		{
			
		}
		
		public virtual void ActiveActionRemoved()
		{
			
		}
		
		
		/*
		============================================================================
		Battle end functions
		============================================================================
		*/
		public virtual void EndBattle()
		{
			
		}
	}
}

