
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Change Faction", "Changes the faction of a combatant's group.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent))]
	[ORKNodeInfo("Faction Steps")]
	public class ChangeFactionStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor who's group faction will change.\n" +
			"If the actor doesn't have a combatant, nothing happens.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Faction", "Select the faction the combatant's group will change to.", "")]
		[ORKEditorInfo(ORKDataType.Faction)]
		public int id2 = 0;
		
		public ChangeFactionStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null && list[i].Group.FactionID >= 0)
				{
					list[i].Group.FactionID = this.id2;
				}
			}
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Change Faction Sympathy", "Changes the sympathy of a faction for another faction.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Faction Steps")]
	public class ChangeFactionSympathyStep : BaseEventStep
	{
		// change faction
		[ORKEditorHelp("Use Actor", "Change the sympathy of an actor's (combatant) faction.", "")]
		[ORKEditorInfo(labelText="Change Faction")]
		public bool useActor = false;
		
		[ORKEditorHelp("Actor", "Select the actor who's faction will change sympathy values.\n" +
			"If the actor doesn't have a combatant, nothing happens.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("useActor", true)]
		public int id = 0;
		
		[ORKEditorHelp("Faction", "Select the faction that will be changed.", "")]
		[ORKEditorInfo(ORKDataType.Faction)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id2 = 0;
		
		
		// sympathy change
		[ORKEditorHelp("Use Actor", "Change the sympathy for an actor's (combatant) faction.", "")]
		[ORKEditorInfo(labelText="Change Sympathy For", separator=true)]
		public bool useActor2 = false;
		
		[ORKEditorHelp("Actor", "Select the actor who's faction will be used.\n" +
			"If the actor doesn't have a combatant, nothing happens.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("useActor2", true)]
		public int id3 = 0;
		
		[ORKEditorHelp("Faction", "Select the faction that will be used.", "")]
		[ORKEditorInfo(ORKDataType.Faction)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id4 = 0;
		
		
		// change by
		[ORKEditorInfo(labelText="Change By", separator=true)]
		public EventFloat value = new EventFloat();
		
		[ORKEditorHelp("Operator", "Decides how the sympathy value will be changed.\n" +
			"- Add: The value will be added to the current sympathy value.\n" +
			"- Sub: The value will be subtracted from the current sympathy value.\n" +
			"- Set: The sympathy value will be set to the value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		public SimpleOperator op = SimpleOperator.Add;
		
		public ChangeFactionSympathyStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<int> factions = new List<int>();
			List<int> sympathy = new List<int>();
			
			// change factions
			if(this.useActor)
			{
				List<Combatant> list = baseEvent.GetActorCombatant(this.id);
				for(int i=0; i<list.Count; i++)
				{
					// no player allowed
					if(list[i] != null && list[i].Group.FactionID >= 0 && 
						!factions.Contains(list[i].Group.FactionID))
					{
						factions.Add(list[i].Group.FactionID);
					}
				}
			}
			else
			{
				factions.Add(this.id2);
			}
			
			// sympathy factions
			if(this.useActor2)
			{
				List<Combatant> list = baseEvent.GetActorCombatant(this.id3);
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null && !sympathy.Contains(list[i].Group.FactionID))
					{
						sympathy.Add(list[i].Group.FactionID);
					}
				}
			}
			else
			{
				sympathy.Add(this.id4);
			}
			
			for(int i=0; i<factions.Count; i++)
			{
				for(int j=0; j<sympathy.Count; j++)
				{
					ORK.Game.Faction.ChangeSympathy(factions[i], sympathy[j], 
						this.value.GetValue(baseEvent), this.op);
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.op.ToString() + " " + this.value.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Check Faction", "Checks the faction of a combatant.\n" +
		"If the faction equals a defined faction, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Faction Steps", "Check Steps")]
	public class CheckFactionStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Actor", "Select the actor who's faction will be checked.\n" +
			"If the actor doesn't have a combatant, the check fails.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Faction", "Select the faction that will be checked for.", "")]
		[ORKEditorInfo(ORKDataType.Faction)]
		public int id2 = 0;
		
		public CheckFactionStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			Combatant c = null;
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					c = list[i];
					break;
				}
			}
			if(c != null && c.Group.FactionID == this.id2)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.Factions.GetName(this.id2);
		}
	}
	
	[ORKEditorHelp("Check Faction Sympathy", "Checks the sympathy a faction has for another faction.\n" +
		"If the check is valid, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Faction Steps", "Check Steps")]
	public class CheckFactionSympathyStep : BaseEventCheckStep
	{
		// change faction
		[ORKEditorHelp("Use Actor", "Checks the sympathy of an actor's (combatant) faction.", "")]
		[ORKEditorInfo(labelText="Check Faction")]
		public bool useActor = false;
		
		[ORKEditorHelp("Actor", "Select the actor who's faction will be checked.\n" +
			"If the actor doesn't have a combatant, the check fails.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("useActor", true)]
		public int id = 0;
		
		[ORKEditorHelp("Faction", "Select the faction that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.Faction)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id2 = 0;
		
		
		// sympathy change
		[ORKEditorHelp("Use Actor", "Check the sympathy for an actor's (combatant) faction.", "")]
		[ORKEditorInfo(labelText="Check Sympathy For", separator=true)]
		public bool useActor2 = false;
		
		[ORKEditorHelp("Actor", "Select the actor who's faction will be checked for.\n" +
			"If the actor doesn't have a combatant, the check fails.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("useActor2", true)]
		public int id3 = 0;
		
		[ORKEditorHelp("Faction", "Select the faction that will be checked for.", "")]
		[ORKEditorInfo(ORKDataType.Faction)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id4 = 0;
		
		
		// check by
		[ORKEditorHelp("Check", "Check if the sympathy value is equal, not equal, less or greater than the defined value.\n" +
			"Range inclusive checks if the value is between two defind values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		public VariableValueCheck check = VariableValueCheck.IsEqual;
		
		[ORKEditorInfo(labelText="Check Value", separator=true)]
		public EventFloat value = new EventFloat();
		
		[ORKEditorInfo(labelText="Check Value 2", separator=true)]
		[ORKEditorLayout(new string[] {"check", "check"}, 
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive}, 
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public EventFloat value2;
		
		public CheckFactionSympathyStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			// get faction ID
			int factionID = -1;
			if(this.useActor)
			{
				List<Combatant> list = baseEvent.GetActorCombatant(this.id);
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null)
					{
						factionID = list[i].Group.FactionID;
						break;
					}
				}
			}
			else
			{
				factionID = this.id2;
			}
			
			// get sympathy ID
			int factionID2 = -1;
			if(this.useActor2)
			{
				List<Combatant> list = baseEvent.GetActorCombatant(this.id3);
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null)
					{
						factionID2 = list[i].Group.FactionID;
						break;
					}
				}
			}
			else
			{
				factionID2 = this.id4;
			}
			
			// check
			if(factionID >= 0 && factionID2 >= 0)
			{
				if(ValueHelper.CheckVariableValue(ORK.Game.Faction.GetSympathy(factionID, factionID2), 
					this.value.GetValue(baseEvent), 
					this.value2 != null ? this.value.GetValue(baseEvent) : 0, this.check))
				{
					baseEvent.StepFinished(this.next);
				}
				else
				{
					baseEvent.StepFinished(this.nextFail);
				}
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.ToString() + " " + this.value.GetInfoText();
		}
	}
}
