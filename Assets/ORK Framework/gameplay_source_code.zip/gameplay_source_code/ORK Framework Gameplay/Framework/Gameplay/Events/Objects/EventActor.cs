
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public class EventActor : BaseData
	{
		[ORKEditorHelp("Type", "Select the type of the event actor:\n" +
			"- Object: The actor is an object of the scene, or the event object itself.\n" +
			"- Player: The actor is the player.\n" +
			"- Member: The actor is a member of the player group.\n" +
			"- Camera: The actor is the camera used by the event.\n" +
			"- Starting Object: The actor is the game object that started the event.", "")]
		public ActorType type = ActorType.Object;
		
		
		// scene object
		[ORKEditorHelp("Event Object", "The actor uses the game object of this event.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", ActorType.Object)]
		public bool isEventObject = false;
		
		[ORKEditorHelp("Find Object", "The actor will search for an object in the scene.", "")]
		[ORKEditorLayout("isEventObject", false)]
		public bool isFindObject = false;
		
		[ORKEditorLayout("isFindObject", true, endCheckGroup=true, endGroups=3, autoInit=true)]
		public FindObjectSetting findObject;
		
		
		// member
		[ORKEditorHelp("Member Index", "The index of the member in the player group.\n" +
			"If the index is higher than the number of group members, the first member (player) is used.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", ActorType.Member)]
		[ORKEditorLimit(0, false)]
		public int memberIndex = 0;
		
		[ORKEditorHelp("Only Battle Group", "Only members of the battle group are used.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool onlyBattle = false;
		
		
		// root and child
		[ORKEditorHelp("Use Root", "The object's root will be used.\n" +
			"If also using 'Child Object', the child object will be searched from the object's root.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useRoot = false;
		
		[ORKEditorHelp("Child Object", "A child object of the game object is used as actor object.\n" +
			"Leave empty if you don't want to use a child object.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string childName = "";
		
		
		// name
		[ORKEditorHelp("Use Scene Object", "Use the content of a scene object for this actor, if available.\n" +
			"If the actor's object has a scene object component or a combatant component, the name of the scene object or combatant will be used.", "")]
		[ORKEditorInfo(separator=true, labelText="Name Settings")]
		public bool useSceneName = false;
		
		[ORKEditorHelp("Set Name", "Set the name of this actor.\n" +
			"If disabled and the actor is the PLAYER or a MEMBER of the player group, the name of the combatant will be used.\n" +
			"If the actor is a scene object (OBJECT type), this setting needs to be enabled to use the actor name in dialogues.", "")]
		public bool setName = false;
		
		[ORKEditorHelp("Name", "The name of the actor.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("setName", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] actorName;
		
		
		// portraits
		[ORKEditorInfo(separator=true, labelText="Portrait Settings")]
		[ORKEditorArray(false, "Add Portrait", "Adds a portrait.", "", 
			"Remove", "Removes this portrait.", "", 
			foldout=true, foldoutText=new string[] {"Portrait", 
			"This portrait is available in dialogue event steps.", ""})]
		public PortraitWithType[] portrait = new PortraitWithType[0];
		
		
		// ingame
		private List<GameObject> gameObjects = new List<GameObject>();
		
		private bool searched = false;
		
		public EventActor()
		{
			
		}
		
		public EventActor(ActorType t)
		{
			this.type = t;
			if(ActorType.Object.Equals(this.type))
			{
				this.isEventObject = true;
			}
		}
		
		public void Clear()
		{
			this.gameObjects = new List<GameObject>();
			this.searched = false;
		}
		
		
		/*
		============================================================================
		Object functions
		============================================================================
		*/
		public void SetObject(GameObject obj)
		{
			if(obj != null)
			{
				this.gameObjects.Add(obj);
			}
		}
		
		public void FindObject(GameObject user)
		{
			if(this.isFindObject && this.findObject != null)
			{
				this.gameObjects = this.findObject.Find(user);
			}
			this.searched = true;
		}
		
		public List<GameObject> GetObject(BaseEvent baseEvent)
		{
			List<GameObject> list = new List<GameObject>();
			
			if(ActorType.Object.Equals(this.type))
			{
				if(this.gameObjects.Count == 0 && !this.searched)
				{
					this.FindObject(baseEvent.GameObject);
				}
				if(this.gameObjects.Count > 0)
				{
					list.AddRange(this.gameObjects);
				}
			}
			else if(ActorType.Player.Equals(this.type))
			{
				list.Add(ORK.Game.GetPlayer());
			}
			else if(ActorType.Member.Equals(this.type))
			{
				Combatant c = null;
				if(this.onlyBattle)
				{
					c = ORK.Game.ActiveGroup.BattleMemberAt(this.memberIndex);
				}
				else
				{
					c = ORK.Game.ActiveGroup.MemberAt(this.memberIndex);
				}
				if(c != null && c.GameObject != null)
				{
					list.Add(c.GameObject);
				}
			}
			else if(ActorType.Camera.Equals(this.type) && baseEvent.GetCamera() != null)
			{
				list.Add(baseEvent.GetCamera().gameObject);
			}
			else
			{
				list.AddRange(this.gameObjects);
			}
			
			// root
			if(this.useRoot)
			{
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null)
					{
						list[i] = list[i].transform.root.gameObject;
					}
				}
			}
			
			// child objects
			if(this.childName != "")
			{
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null)
					{
						list[i] = TransformHelper.GetChild(this.childName, list[i].transform).gameObject;
					}
				}
			}
			
			return list;
		}
		
		public List<Combatant> GetCombatant(BaseEvent baseEvent)
		{
			List<Combatant> list = new List<Combatant>();
			
			if(ActorType.Object.Equals(this.type))
			{
				if(this.gameObjects.Count == 0 && !this.searched)
				{
					this.FindObject(baseEvent.GameObject);
				}
				if(this.gameObjects.Count > 0)
				{
					list.AddRange(ComponentHelper.GetCombatants(this.gameObjects));
				}
			}
			else if(ActorType.Player.Equals(this.type))
			{
				if(ORK.Game.ActiveGroup.Leader != null)
				{
					list.Add(ORK.Game.ActiveGroup.Leader);
				}
			}
			else if(ActorType.Member.Equals(this.type))
			{
				Combatant c = null;
				if(this.onlyBattle)
				{
					c = ORK.Game.ActiveGroup.BattleMemberAt(this.memberIndex);
				}
				else
				{
					c = ORK.Game.ActiveGroup.MemberAt(this.memberIndex);
				}
				if(c != null)
				{
					list.Add(c);
				}
			}
			else if(ActorType.Camera.Equals(this.type) && baseEvent.GetCamera() != null)
			{
				Combatant c = ComponentHelper.GetCombatant(baseEvent.GetCamera().gameObject);
				if(c != null)
				{
					list.Add(c);
				}
			}
			else
			{
				list.AddRange(ComponentHelper.GetCombatants(this.gameObjects));
			}
			
			return list;
		}
		
		
		
		/*
		============================================================================
		Get functions
		============================================================================
		*/
		public string GetName()
		{
			if(this.useSceneName)
			{
				IContent content = ComponentHelper.GetFirstContent(this.gameObjects);
				if(content != null)
				{
					return content.GetName();
				}
			}
			if(this.setName)
			{
				return this.actorName[ORK.Game.Language];
			}
			else
			{
				Combatant c = null;
				if(ActorType.Object.Equals(this.type))
				{
					c = ComponentHelper.GetFirstCombatant(this.gameObjects);
				}
				else if(ActorType.Player.Equals(this.type))
				{
					c = ORK.Game.ActiveGroup.Leader;
				}
				else if(ActorType.Member.Equals(this.type))
				{
					if(this.onlyBattle)
					{
						c = ORK.Game.ActiveGroup.BattleMemberAt(this.memberIndex);
					}
					else
					{
						c = ORK.Game.ActiveGroup.MemberAt(this.memberIndex);
					}
				}
				if(c != null)
				{
					return c.GetName();
				}
			}
			return "";
		}
		
		public Portrait GetPortrait(int typeID)
		{
			// check portrait list
			for(int i=0; i<this.portrait.Length; i++)
			{
				if(this.portrait[i].typeID == typeID)
				{
					return this.portrait[i];
				}
			}
			
			// get combatant portrait
			Combatant c = null;
			if(ActorType.Object.Equals(this.type))
			{
				c = ComponentHelper.GetFirstCombatant(this.gameObjects);
			}
			else if(ActorType.Player.Equals(this.type))
			{
				c = ORK.Game.ActiveGroup.Leader;
			}
			else if(ActorType.Member.Equals(this.type))
			{
				if(this.onlyBattle)
				{
					c = ORK.Game.ActiveGroup.BattleMemberAt(this.memberIndex);
				}
				else
				{
					c = ORK.Game.ActiveGroup.MemberAt(this.memberIndex);
				}
			}
			if(c != null)
			{
				return c.GetPortrait(typeID);
			}
			return null;
		}
	}
}
