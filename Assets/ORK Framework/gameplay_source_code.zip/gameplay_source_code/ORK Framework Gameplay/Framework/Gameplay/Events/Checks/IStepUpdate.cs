
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public interface IStepUpdate
	{
		bool Tick(float delta, BaseEvent baseEvent, ref int nextStep);
	}
}
