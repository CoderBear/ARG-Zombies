
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Calculate", "Calculates the actual battle action outcome " +
		"(i.e. the attack, ability or item use, etc.) and the damage done " +
		"(damage, refresh, miss or status effect texts are displayed).\n" +
		"This step can automatically animate the target according to what happened in the battle action " +
		"(e.g. play the damage animation defined for the combatant).\n" +
		"Don't use this step if you want to use DamageDealer and DamageZone " +
		"components to handle a battle actions outcome.\n" +
		"You can use multiple Calculate steps to create multi-damage attacks " +
		"(i.e. attacks/abilities with more then one damage).\n" +
		"The next step that will be executed can optionally depend on the outcome of the calculation - " +
		"'Next' is executed on a standard hit or if no other criteria matched.\n" +
		"When using 'Critical', 'Miss' and 'Block' next steps, the one with the highest count (e.g. 2 criticals > 1 miss) is used.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle Steps")]
	public class CalculateStep : BaseEventStep
	{
		// animation
		[ORKEditorHelp("Animate Target", "Automatically play an animation according to the result of the " +
			"battle action calculation (e.g. damage, evade, etc.).\n" +
			"The animation that will be played is defined in the combatant's animation settings.", "")]
		public bool animate = true;
		
		[ORKEditorHelp("Set Damage Factor", "The outcome of the calculation will be multiplied by a defined value, e.g.:\n" +
			"- A damage factor of 1 means normal damage.\n" +
			"- A damage factor of 2 means double damage.\n" +
			"- A damage factor of 0.5 means half damage.", "")]
		[ORKEditorInfo(separator=true, labelText="Damage Factor")]
		public bool setFactor = false;
		
		[ORKEditorLayout("setFactor", true, endCheckGroup=true, autoInit=true)]
		public EventFloat dmgFactor;
		
		
		// critical next step
		[ORKEditorHelp("Use 'Critical' Next", "Enables using a different 'Next' step " +
			"when the calculation results in a critical hit.", "")]
		[ORKEditorInfo(separator=true, labelText="Additional 'Next' Steps")]
		public bool useCritical = false;
		
		[ORKEditorInfo(hide=true)]
		public int nextCritical = -1;
		
		
		// miss next step
		[ORKEditorHelp("Use 'Miss' Next", "Enables using a different 'Next' step " +
			"when the calculation results in a miss.", "")]
		public bool useMiss = false;
		
		[ORKEditorInfo(hide=true)]
		public int nextMiss = -1;
		
		// block next step
		[ORKEditorHelp("Use 'Block' Next", "Enables using a different 'Next' step " +
			"when the calculation results in a block.", "")]
		public bool useBlock = false;
		
		[ORKEditorInfo(hide=true)]
		public int nextBlock = -1;
		
		public CalculateStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			int tmpNext = this.next;
			
			if(baseEvent is BattleEvent)
			{
				BattleEvent evt = baseEvent as BattleEvent;
				evt.calcNeeded = false;
				
				if(evt.Action.HasTargets())
				{
					float dmgFactor = 1;
					if(this.setFactor)
					{
						dmgFactor = this.dmgFactor.GetValue(baseEvent);
					}
					
					evt.Action.Calculate(evt.Action.target, dmgFactor, this.animate);
				}
				
				if(evt.Action.results != null)
				{
					BattleActionResult result = evt.Action.results.GetResult();
					if(BattleActionResult.Critical.Equals(result) && this.useCritical)
					{
						tmpNext = this.nextCritical;
					}
					else if(BattleActionResult.Miss.Equals(result) && this.useMiss)
					{
						tmpNext = this.nextMiss;
					}
					else if(BattleActionResult.Block.Equals(result) && this.useBlock)
					{
						tmpNext = this.nextBlock;
					}
				}
			}
			
			baseEvent.StepFinished(tmpNext);
		}
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Next";
			}
			else if(index == 1)
			{
				if(this.useCritical)
				{
					return "Critical";
				}
				else if(this.useMiss)
				{
					return "Miss";
				}
				else
				{
					return "Block";
				}
			}
			else if(index == 2)
			{
				if(this.useCritical && this.useMiss)
				{
					return "Miss";
				}
				else
				{
					return "Block";
				}
			}
			else if(index == 3)
			{
				return "Block";
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			int count = 1;
			if(this.useCritical)
			{
				count++;
			}
			if(this.useMiss)
			{
				count++;
			}
			if(this.useBlock)
			{
				count++;
			}
			return count;
		}
		
		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index == 1)
			{
				if(this.useCritical)
				{
					return this.nextCritical;
				}
				else if(this.useMiss)
				{
					return this.nextMiss;
				}
				else
				{
					return this.nextBlock;
				}
			}
			else if(index == 2)
			{
				if(this.useCritical && this.useMiss)
				{
					return this.nextMiss;
				}
				else
				{
					return this.nextBlock;
				}
			}
			else if(index == 3)
			{
				return this.nextBlock;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index == 1)
			{
				if(this.useCritical)
				{
					this.nextCritical = next;
				}
				else if(this.useMiss)
				{
					this.nextMiss = next;
				}
				else
				{
					this.nextBlock = next;
				}
			}
			else if(index == 2)
			{
				if(this.useCritical && this.useMiss)
				{
					this.nextMiss = next;
				}
				else
				{
					this.nextBlock = next;
				}
			}
			else if(index == 3)
			{
				this.nextBlock = next;
			}
		}
	}
	
	[ORKEditorHelp("Damage Multiplier", "Set the damage multiplier of the battle action this battle event belongs to.\n" +
		"The damage multiplier is used to manipulate the outcome of every damage calculation (e.g. Calculate step), e.g.:\n" +
		"- A damage multiplier of 1 means normal damage.\n" +
		"- A damage multiplier of 2 means double damage.\n" +
		"- A damage multiplier of 0.5 means half damage.\n" +
		"You can use this step to e.g. increase the damage of an attack when a " +
		"button was pressed (Wait for Button step).", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle Steps")]
	public class DamageMultiplierStep : BaseEventStep
	{
		[ORKEditorHelp("Multiply By", "The damage multiplier will be set to this number, e.g.:\n" +
			"- A damage multiplier of 1 means normal damage.\n" +
			"- A damage multiplier of 2 means double damage.\n" +
			"- A damage multiplier of 0.5 means half damage.", "")]
		public float mult = 1;
		
		public DamageMultiplierStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent is BattleEvent)
			{
				((BattleEvent)baseEvent).Action.damageMultiplier = this.mult;
			}
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Activate Damage Dealer", "Activates/deactivates DamageDealer components of the user of the " +
		"battle animation (or spawned prefabs).\n" +
		"DamageDealers can't do damage without being activated.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle Steps")]
	public class ActivateDamageDealerStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Activate/Deactivate On")]
		public EventObjectSetting onObject = new EventObjectSetting();
		
		
		// activation
		[ORKEditorHelp("Activate", "The DamageDealer components will be set active (i.e. they will do damage).\n" +
			"If disabled, the DamageDealer components will be set inactive (i.e. they wont do damage).", "")]
		[ORKEditorInfo(separator=true)]
		public bool activate = true;
		
		
		// tags
		[ORKEditorHelp("Use Action Tags", "Use the tags of the battle action " +
			"(i.e. the tags defined in an ability's or item's 'Damage Dealer Settings').", "")]
		[ORKEditorInfo(separator=true, labelText="Activation Tags")]
		public bool useActionTags = true;
		
		[ORKEditorHelp("Tag", "Define the tag that will be used to activate/deactivate the damage dealer.\n" +
			"Damage dealers that match one of the defined tags will be activated/deactivated, " +
			"ignoring if they're set up for this ability/item or not.", "")]
		[ORKEditorInfo(hideName=true)]
		[ORKEditorArray(false, "Add Tag", "Adds a tag.\n" +
			"Damage dealers that match one of the defined tags will be activated/deactivated, " +
			"ignoring if they're set up for this ability/item or not.", "", 
			"Remove", "Removes this tag.", "", isHorizontal=true)]
		public string[] activationTags = new string[0];
		
		
		// audio settings
		[ORKEditorHelp("Add Audio", "An audio clip is played on the game object hit by the damage dealer (when doing damage).", "")]
		[ORKEditorInfo(separator=true, labelText="Audio Settings")]
		[ORKEditorLayout("activate", true)]
		public bool addAudio = false;
		
		[ORKEditorHelp("Use Action Audio", "Use the audio settings of the battle action " +
			"(i.e. the audio settings defined in an ability's or item's 'Damage Dealer Settings').", "")]
		[ORKEditorLayout("addAudio", true)]
		public bool useActionAudio = false;
		
		[ORKEditorHelp("Use Sound Type", "The target combatant's defined sound of a selected sound type will be used.", "")]
		[ORKEditorLayout("useActionAudio", false)]
		public bool useSoundType = false;
		
		[ORKEditorHelp("Sound Type", "Select the sound type that will be played.", "")]
		[ORKEditorInfo(ORKDataType.SoundType)]
		[ORKEditorLayout("useSoundType", true)]
		public int soundTypeID = 0;
		
		[ORKEditorHelp("Use Target", "Use the target combatant's audio clip.\n" +
			"If disabled, the user combatant's audio clip is used.", "")]
		public bool targetSound = false;
		
		[ORKEditorHelp("Audio Clip", "Select the audio clip that will be played.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=3)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id3 = 0;
		
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public PlayAudioSettings audio;
		
		
		// prefab settings
		[ORKEditorHelp("Add Prefab", "A prefab is spawned on the position it hit an object when doing damage.\n" +
			"This prefab can't be used by the battle event.", "")]
		[ORKEditorInfo(separator=true, labelText="Prefab Settings")]
		public bool addPrefab = false;
		
		[ORKEditorHelp("Use Action Prefab", "Use the prefab settings of the battle action " +
			"(i.e. the prefab settings defined in an ability's or item's 'Damage Dealer Settings').", "")]
		[ORKEditorLayout("addAudio", true)]
		public bool useActionPrefab = false;
		
		[ORKEditorHelp("Prefab", "Select the prefab that will be used.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=2)]
		[ORKEditorLayout("useActionPrefab", false)]
		public int id4 = 0;
		
		[ORKEditorHelp("Stop Particles", "Particles emitting from the prefab will stop emitting.", "")]
		public bool stopParticles = false;
		
		[ORKEditorHelp("Stop After (s)", "The time in seconds before emitting particles will stop.", "")]
		[ORKEditorLayout("stopParticles", true, endCheckGroup=true)]
		public float stopAfter = 1;
		
		[ORKEditorHelp("Destroy After (s)", "The spawned prefab will be destroyed after the set amout of time in seconds.\n" +
			"Set to 0 if you don't want to destroy it after time.", "")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public float after = 0;
		
		public ActivateDamageDealerStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent is BattleEvent)
			{
				BattleEvent evt = baseEvent as BattleEvent;
				
				List<GameObject> list = this.onObject.GetObject(baseEvent);
				
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null)
					{
						DamageDealer[] damage = list[i].GetComponentsInChildren<DamageDealer>();
						for(int j=0; j<damage.Length; j++)
						{
							if(this.activate)
							{
								DamageDealerActivation ddActivation = evt.Action.GetDamageDealerActivation();
								
								damage[j].SetAction(evt.Action);
								
								if(this.addAudio)
								{
									if(this.useActionAudio)
									{
										if(ddActivation != null)
										{
											ddActivation.AddAudio(damage[j], evt.Action.user);
										}
									}
									else if(this.useSoundType)
									{
										if(this.targetSound)
										{
											damage[j].SetAudioType(this.soundTypeID, this.audio);
										}
										else
										{
											damage[j].SetAudioClip(
												evt.Action.user.Animations.GetAudioClip(this.soundTypeID), this.audio);
										}
									}
									else
									{
										damage[j].SetAudioClip(evt.GetAudioClip(this.id3), this.audio);
									}
								}
								
								if(this.addPrefab)
								{
									if(this.useActionPrefab)
									{
										if(ddActivation != null)
										{
											ddActivation.AddPrefab(damage[j]);
										}
									}
									else
									{
										
										damage[j].SetPrefab(evt.GetPrefab(this.id4), this.after, this.stopParticles ? this.stopAfter : -1);
									}
								}
							}
							else
							{
								damage[j].SetAction(null);
							}
							
							if(this.useActionTags)
							{
								string[] tags = evt.Action.GetActivationTags();
								if(tags.Length > 0)
								{
									List<string> tmp = new List<string>(tags);
									tmp.AddRange(this.activationTags);
									damage[j].SetDamageActive(this.activate, tmp.ToArray());
								}
								else
								{
									damage[j].SetDamageActive(this.activate, this.activationTags);
								}
							}
							else
							{
								damage[j].SetDamageActive(this.activate, this.activationTags);
							}
						}
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Restore Control", "Restores game control in real time battles.\n" +
		"Use this step when you set the battle actions to block control but want to restore control before an animation finished.\n" +
		"This step is only executed when the player is the user of the battle action.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle Steps")]
	public class RestoreControlStep : BaseEventStep
	{
		public RestoreControlStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent is BattleEvent)
			{
				if(ORK.Battle.IsRealTime() && 
					ORK.Game.PlayerHandler.IsPlayer(((BattleEvent)baseEvent).Action.user))
				{
					ORK.Control.RestoreControl();
				}
			}
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Change Battle Type", "Changes the type of the running battle.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle Steps")]
	public class ChangeBattleTypeStep : BaseEventStep
	{
		[ORKEditorHelp("Type", "Select the type the battle system will change to:\n" +
			"- Turn Based: Turn based battle.\n" +
			"- Active Time: Active time battle.\n" +
			"- Real Time: Real time battle.\n" +
			"- Phase: Phase battle.", "")]
		[ORKEditorInfo(isEnumToolbar=true)]
		public BattleSystemType type = BattleSystemType.TurnBased;
		
		[ORKEditorHelp("Clear Unused Actions", "All battle actions that haven't started will be removed from the running battle.", "")]
		public bool clear = false;
		
		[ORKEditorHelp("Stop Running Actions", "All battle actions that are currently performing will be stopped.", "")]
		public bool stop = false;
		
		public ChangeBattleTypeStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			ORK.Battle.ChangeType(this.type, this.clear, this.stop);
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Clear Battle Actions", "All battle actions that haven't started will be removed from the running battle.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle Steps")]
	public class ClearBattleActionsStep : BaseEventStep
	{
		public ClearBattleActionsStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			ORK.Battle.Actions.ClearStack();
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Stop Battle Actions", "All battle actions that are currently performing will be stopped.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle Steps")]
	public class StopBattleActionsStep : BaseEventStep
	{
		public StopBattleActionsStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			ORK.Battle.Actions.StopActiveActions();
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Look At Enemies", "All combatants participating in the battle will look at their enemies.\n" +
		"Note that only combatant's that are already in the scene will look at their enemies.", "")]
	[ORKEventStep(typeof(BattleStartEvent), typeof(BattleEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Battle Steps")]
	public class LookAtEnemiesStep : BaseEventStep
	{
		public LookAtEnemiesStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			ORK.Battle.SetLooks(null);
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Spawn Combatants", "Spawns combatants participating in this battle at their battle spots.\n" +
			"Note that only combatants that aren't already in the scene will be spawned.", "")]
	[ORKEventStep(typeof(BattleStartEvent))]
	[ORKNodeInfo("Battle Steps")]
	public class SpawnCombatantsStep : BaseEventStep
	{
		[ORKEditorHelp("Spawn All", "All combatants participating in this battle will be spawned at their battle spots.\n" +
			"Note that only combatants that aren't already in the scene will be spawned.", "")]
		public bool all = true;
		
		[ORKEditorHelp("Group", "Select the combatant group that will be spawned.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("all", false, endCheckGroup=true)]
		public int id = 0;
		
		public SpawnCombatantsStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.all)
			{
				this.Spawn(baseEvent, 0);
				this.Spawn(baseEvent, 1);
				this.Spawn(baseEvent, 2);
			}
			else
			{
				this.Spawn(baseEvent, this.id);
			}
			baseEvent.StepFinished(this.next);
		}
		
		private void Spawn(BaseEvent baseEvent, int index)
		{
			List<Combatant> combatants = baseEvent.GetActorCombatant(index);
			for(int i=0; i<combatants.Count; i++)
			{
				if(combatants[i] != null && combatants[i].GameObject == null && 
					combatants[i].BattleSpot != null)
				{
					combatants[i].Spawn(
						combatants[i].BattleSpot.transform.position, 
						ORK.BattleSpots.useYRotation, combatants[i].BattleSpot.transform.eulerAngles.y, 
						ORK.BattleSpots.useScale, combatants[i].BattleSpot.transform.localScale);
					
					if(combatants[i] == ORK.Game.ActiveGroup.Leader)
					{
						ORK.GameControls.AddPlayerComponents(combatants[i]);
					}
				}
			}
		}
	}
	
	[ORKEditorHelp("Place At Spots", "Place combatants participating in this battle at their battle spots.", "")]
	[ORKEventStep(typeof(BattleStartEvent), typeof(BattleEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Battle Steps")]
	public class PlaceAtSpotsStep : BaseEventStep
	{
		[ORKEditorHelp("Place All", "All combatants participating in this battle will be placed at their battle spots.\n" +
			"Note that only combatants that are already in the scene will be placed.", "")]
		public bool all = true;
		
		[ORKEditorHelp("Group", "Select the combatant group that will be spawned.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("all", false, endCheckGroup=true)]
		public int id = 0;
		
		public PlaceAtSpotsStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent is BattleEvent)
			{
				if(this.all)
				{
					this.Place(baseEvent.GetActorCombatant(0));
					this.Place(baseEvent.GetActorCombatant(1));
				}
				else
				{
					this.Place(baseEvent.GetActorCombatant(this.id));
				}
			}
			else
			{
				if(this.all)
				{
					this.Place(baseEvent.GetActorCombatant(0));
					this.Place(baseEvent.GetActorCombatant(1));
					this.Place(baseEvent.GetActorCombatant(2));
				}
				else
				{
					this.Place(baseEvent.GetActorCombatant(this.id));
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		private void Place(List<Combatant> combatants)
		{
			for(int i=0; i<combatants.Count; i++)
			{
				if(combatants[i] != null && combatants[i].GameObject != null && 
					combatants[i].BattleSpot != null)
				{
					combatants[i].PlaceAt(
						combatants[i].BattleSpot.transform.position, 
						ORK.BattleSpots.useYRotation, combatants[i].BattleSpot.transform.eulerAngles.y, 
						ORK.BattleSpots.useScale, combatants[i].BattleSpot.transform.localScale);
				}
			}
		}
	}
	
	[ORKEditorHelp("Destroy Combatants", "Destroy combatants participating in this battle.", "")]
	[ORKEventStep(typeof(BattleEndEvent))]
	[ORKNodeInfo("Battle Steps")]
	public class DestroyCombatantsStep : BaseEventStep
	{
		[ORKEditorHelp("Destroy Player", "The player combatant (or group) will also be destroyed.\n" +
			"If disabled, the player combatant or group wont be destroyed - " +
			"depending on the 'group spawn' settings defined in the game settings.", "")]
		public bool player = false;
		
		[ORKEditorHelp("Destroy All", "All combatants participating in this battle will be destroyed.", "")]
		public bool all = true;
		
		[ORKEditorHelp("Group", "Select the combatant group that will be destroyed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("all", false, endCheckGroup=true)]
		public int id = 0;
		
		public DestroyCombatantsStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.all)
			{
				if(this.player || !ORK.GameSettings.spawnGroup)
				{
					this.Destroy((BattleEndEvent)baseEvent, 0);
				}
				this.Destroy(baseEvent, 1);
				this.Destroy(baseEvent, 2);
			}
			else
			{
				this.Destroy(baseEvent, this.id);
			}
			baseEvent.StepFinished(this.next);
		}
		
		private void Destroy(BaseEvent baseEvent, int index)
		{
			List<Combatant> combatants = baseEvent.GetActorCombatant(index);
			for(int i=0; i<combatants.Count; i++)
			{
				if(combatants[i] != null && combatants[i].GameObject != null && 
					(this.player || combatants[i] != ORK.Game.ActiveGroup.Leader))
				{
					combatants[i].DestroyPrefab();
				}
			}
		}
	}
	
	[ORKEditorHelp("Collect Battle Gains", "Collect the battle gains (loot, experience) and optionally display the gains and level up texts.", "")]
	[ORKEventStep(typeof(BattleEndEvent))]
	[ORKNodeInfo("Battle Steps")]
	public class CollectBattleGainsStep : BaseEventStep
	{
		[ORKEditorHelp("Show Gains", "Show the battle gains and level up texts.\n" +
			"The display options are defined in the battle end settings.", "")]
		public bool display = false;
		
		[ORKEditorHelp("Auto Close", "Automatically close the battle gains after a defined time.", "")]
		[ORKEditorLayout("display", true)]
		public bool autoClose = false;
		
		[ORKEditorHelp("Close After (s)", "The time in seconds until the gains dialogue closes automatially.\n" +
			"This time is used for each page of the battle gains.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("autoClose", true)]
		public float closeTime = 3;
		
		[ORKEditorHelp("Block Accept Button", "The accept button is blocked - " +
			"the gains dialogue will only close after it's time ran up.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool blockAccept = false;
		
		[ORKEditorHelp("Wait", "Wait for the battle gains dialogue to be closed.", "")]
		[ORKEditorLayout(endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool wait = true;
		
		public CollectBattleGainsStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(ORK.Battle.HasGains())
			{
				ORK.Battle.CollectGains(this.display, 
					this.autoClose ? this.closeTime : -1, this.blockAccept, 
					this.wait ? baseEvent : null, 
					this.next);
				
				if(!this.display || !this.wait)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.wait ? "Wait" : "";
		}
	}
	
	[ORKEditorHelp("Clear Battle Gains", "All gains of this battle (loot, experience) that haven't been collected will be removed.", "")]
	[ORKEventStep(typeof(BattleEndEvent))]
	[ORKNodeInfo("Battle Steps")]
	public class ClearBattleGainsStep : BaseEventStep
	{
		public ClearBattleGainsStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			ORK.Battle.ClearGains();
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Set Battle Scene ID", "Set the scene ID of the battle component this battle uses.", "")]
	[ORKEventStep(typeof(BattleStartEvent), typeof(BattleEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Battle Steps")]
	public class SetBattleSceneIDStep : BaseEventStep
	{
		public SetBattleSceneIDStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent.Starter is BattleComponent)
			{
				((BattleComponent)baseEvent.Starter).SetSceneID();
				
			}
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Check Battle Advantage", "Checks the battle advantage of the battle.\n" +
		"Depending on the battle advantage either 'None', 'Player' or 'Enemy' will be executed next.", "")]
	[ORKEventStep(typeof(BattleStartEvent), typeof(BattleEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Battle Steps", "Check Steps")]
	public class CheckBattleAdvantageStep : BaseEventStep
	{
		[ORKEditorInfo(hide=true)]
		public int nextPlayer = -1;
		
		[ORKEditorInfo(hide=true)]
		public int nextEnemy = -1;
		
		public CheckBattleAdvantageStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(GroupAdvantageType.None.Equals(ORK.Battle.Advantage))
			{
				baseEvent.StepFinished(this.next);
			}
			else if(GroupAdvantageType.Player.Equals(ORK.Battle.Advantage))
			{
				baseEvent.StepFinished(this.nextPlayer);
			}
			else if(GroupAdvantageType.Enemy.Equals(ORK.Battle.Advantage))
			{
				baseEvent.StepFinished(this.nextEnemy);
			}
		}
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "None";
			}
			else if(index == 1)
			{
				return "Player";
			}
			else if(index == 2)
			{
				return "Enemy";
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			return 3;
		}
		
		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index == 1)
			{
				return this.nextPlayer;
			}
			else if(index == 2)
			{
				return this.nextEnemy;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index == 1)
			{
				this.nextPlayer = next;
			}
			else if(index == 2)
			{
				this.nextEnemy = next;
			}
		}
	}
	
	[ORKEditorHelp("Join Battle", "A combatant joins the battle.\n" +
		"The combatant is spawned at the first free battle spot of its group.", "")]
	[ORKEventStep(typeof(BattleEvent), typeof(BattleStartEvent))]
	[ORKNodeInfo("Battle Steps")]
	public class JoinBattleStep : BaseEventStep
	{
		[ORKEditorHelp("Group", "Select the combatant group the combatant will join.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorInfo(separator=true, labelText="Combatant")]
		public CombatantGroupMember member = new CombatantGroupMember();
		
		public JoinBattleStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> combatants = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<combatants.Count; i++)
			{
				if(combatants[i] != null)
				{
					ORK.Battle.Join(member.Create(combatants[i].Group));
					break;
				}
			}
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Leave Battle", "A combatant leaves the battle.\n" +
		"The combatant's game object is destroyed.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle Steps")]
	public class LeaveBattleStep : BaseEventStep
	{
		[ORKEditorHelp("Group", "Select the combatant that will leave the battle.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		public LeaveBattleStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> combatants = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<combatants.Count; i++)
			{
				if(combatants[i] != null)
				{
					ORK.Battle.RemoveCombatant(combatants[i], false);
				}
			}
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Change Action Targets", "A combatant is added or removed as a target of the action, " +
		"or all targets can be removed.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle Steps")]
	public class AddTargetToActionStep : BaseEventStep
	{
		[ORKEditorHelp("Change Type", "Select how the targets will be changed:\n" +
			"- Add: A combatant will be added as a target.\n" +
			"- Remove: A combatant will be removed as a target.\n" +
			"- Clear: All targets will be removed.", "")]
		public ListChangeType changeType = ListChangeType.Add;
		
		[ORKEditorInfo(separator=true, labelText="Target Object")]
		[ORKEditorLayout("changeType", ListChangeType.Clear, 
			elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public EventObjectSetting targetObject;
		
		public AddTargetToActionStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent is BattleEvent)
			{
				BattleEvent battleEvent = baseEvent as BattleEvent;
				
				if(ListChangeType.Clear.Equals(this.changeType))
				{
					battleEvent.Action.target.Clear();
				}
				else
				{
					List<Combatant> list = this.targetObject.GetCombatant(baseEvent);
					for(int i=0; i<list.Count; i++)
					{
						if(ListChangeType.Add.Equals(this.changeType))
						{
							battleEvent.Action.target.Add(list[i]);
						}
						else if(ListChangeType.Remove.Equals(this.changeType))
						{
							battleEvent.Action.target.Remove(list[i]);
						}
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.changeType.ToString();
		}
	}
	
	[ORKEditorHelp("Use Ability Calculation", "Uses an ability (without animation) - " +
		"the user/target changes will be calculated.\n" +
		"The user doesn't need to know the ability or ability level.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle Steps")]
	public class UseAbilityCalculationStep : BaseEventStep
	{
		// ability
		[ORKEditorHelp("Ability", "Select the ability that will be used.", "")]
		[ORKEditorInfo(ORKDataType.Ability, labelText="Ability Settings")]
		public int abilityID = 0;
		
		[ORKEditorHelp("Ability Level", "The level of the ability that will be used.", "")]
		[ORKEditorLimit(1, false)]
		public int abilityLevel = 1;
		
		[ORKEditorHelp("Consume Costs", "The use costs of the ability will be consumed.", "")]
		public bool useCosts = false;
		
		[ORKEditorHelp("Animate Target", "Automatically play an animation according to the result of the " +
			"calculation (e.g. damage, evade, etc.).\n" +
			"The animation that will be played is defined in the combatant's animation settings.", "")]
		public bool animate = true;
		
		[ORKEditorHelp("Do Counters", "Targets can counter the ability (if set up accordingly).", "")]
		public bool doCounters = true;
		
		[ORKEditorHelp("Set Damage Factor", "The outcome of the calculation will be multiplied by a defined value, e.g.:\n" +
			"- A damage factor of 1 means normal damage.\n" +
			"- A damage factor of 2 means double damage.\n" +
			"- A damage factor of 0.5 means half damage.", "")]
		[ORKEditorInfo(separator=true, labelText="Damage Factor")]
		public bool setFactor = false;
		
		[ORKEditorLayout("setFactor", true, endCheckGroup=true, autoInit=true)]
		public EventFloat dmgFactor;
		
		
		// user
		[ORKEditorInfo(separator=true, labelText="User")]
		public EventObjectSetting userObject = new EventObjectSetting();
		
		
		//target
		[ORKEditorInfo(separator=true, labelText="Target")]
		public EventObjectSetting targetObject = new EventObjectSetting();
		
		public UseAbilityCalculationStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent is BattleEvent)
			{
				BattleEvent battleEvent = baseEvent as BattleEvent;
				
				List<Combatant> user = this.userObject.GetCombatant(baseEvent);
				List<Combatant> target = this.targetObject.GetCombatant(baseEvent);
				
				for(int i=0; i<user.Count; i++)
				{
					ORK.Abilities.Get(this.abilityID).Use(user[i], target, this.animate, 
						battleEvent.Action, this.doCounters, this.useCosts, this.abilityLevel, 
						this.setFactor ? this.dmgFactor.GetValue(baseEvent) : 1, 
						battleEvent.Action.damageMultiplier);
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.Abilities.GetName(this.abilityID);
		}
	}
	
	[ORKEditorHelp("Use Item Calculation", "Uses an item (without animation) - " +
		"the user/target changes will be calculated.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle Steps")]
	public class UseItemCalculationStep : BaseEventStep
	{
		// ability
		[ORKEditorHelp("Item", "Select the item that will be used.", "")]
		[ORKEditorInfo(ORKDataType.Item, labelText="Item Settings")]
		public int itemID = 0;
		
		[ORKEditorHelp("Consume Item", "If the user has the item in his inventory, " +
			"it will be consumed (when set up accordingly).", "")]
		public bool consume = false;
		
		[ORKEditorHelp("Animate Target", "Automatically play an animation according to the result of the " +
			"calculation (e.g. damage, evade, etc.).\n" +
			"The animation that will be played is defined in the combatant's animation settings.", "")]
		public bool animate = true;
		
		[ORKEditorHelp("Set Damage Factor", "The outcome of the calculation will be multiplied by a defined value, e.g.:\n" +
			"- A damage factor of 1 means normal damage.\n" +
			"- A damage factor of 2 means double damage.\n" +
			"- A damage factor of 0.5 means half damage.", "")]
		[ORKEditorInfo(separator=true, labelText="Damage Factor")]
		public bool setFactor = false;
		
		[ORKEditorLayout("setFactor", true, endCheckGroup=true, autoInit=true)]
		public EventFloat dmgFactor;
		
		
		// user
		[ORKEditorInfo(separator=true, labelText="User")]
		public EventObjectSetting userObject = new EventObjectSetting();
		
		
		//target
		[ORKEditorInfo(separator=true, labelText="Target")]
		public EventObjectSetting targetObject = new EventObjectSetting();
		
		public UseItemCalculationStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent is BattleEvent)
			{
				BattleEvent battleEvent = baseEvent as BattleEvent;
				
				List<Combatant> user = this.userObject.GetCombatant(baseEvent);
				List<Combatant> target = this.targetObject.GetCombatant(baseEvent);
				
				for(int i=0; i<user.Count; i++)
				{
					ORK.Items.Get(this.itemID).Use(user[i], target, 
						this.animate, this.consume, battleEvent.Action, 
						this.setFactor ? this.dmgFactor.GetValue(baseEvent) : 1, 
						battleEvent.Action.damageMultiplier);
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.Items.GetName(this.itemID);
		}
	}
	
	[ORKEditorHelp("End Phase", "The phase will end after this action finishes - " +
		"combatants who didn't chose an action yet will not be able to do so.\n" +
		"Only used in 'Phase' battles.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle Steps")]
	public class EndPhaseStep : BaseEventStep
	{
		public EndPhaseStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent is BattleEvent && ORK.Battle.IsPhase())
			{
				ORK.BattleSystem.phase.ClearCurrentFaction();
			}
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Check Turn", "Checks a combatant's turn.\n" +
		"If the check is valid, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Battle Steps", "Check Steps")]
	public class CheckTurnStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Check Type", "Checks if the turn is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the turn is between two defind values, including the values.\n" +
			"Range exclusive checks if the turn is between two defined values, excluding the values.\n" +
			"Approximately checks if the turn is similar to the defined value.", "")]
		public VariableValueCheck check = VariableValueCheck.IsEqual;
		
		[ORKEditorInfo(separator=true, labelText="Turn Value")]
		public EventFloat turn = new EventFloat();
		
		[ORKEditorInfo(separator=true, labelText="Turn Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"}, 
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive}, 
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public EventFloat turn2;
		
		
		// object
		[ORKEditorHelp("Needed", "Either all or only one combatant's turn check must be valid.", "")]
		[ORKEditorInfo(separator=true, labelText="Check Object", 
			isEnumToolbar=true, toolbarWidth=75)]
		public Needed needed = Needed.One;
		
		public EventObjectSetting checkObject = new EventObjectSetting();
		
		public CheckTurnStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.DoCheck(ComponentHelper.GetCombatants(this.checkObject.GetObject(baseEvent)), 
				this.turn.GetValue(baseEvent), 
				this.turn2 != null ? this.turn2.GetValue(baseEvent) : 0))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		private bool DoCheck(List<Combatant> list, float value, float value2)
		{
			if(list.Count > 0)
			{
				for(int i=0; i<list.Count; i++)
				{
					if(ValueHelper.CheckVariableValue(
						list[i].Turn, value, value2, this.check))
					{
						if(Needed.One.Equals(needed))
						{
							return true;
						}
					}
					else if(Needed.All.Equals(needed))
					{
						return false;
					}
				}
				if(Needed.All.Equals(needed))
				{
					return true;
				}
			}
			return false;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.checkObject.GetInfoText() + ": " +
				this.check.ToString() + " " + this.turn.GetInfoText() + 
				(this.turn2 != null ? " ~ " + this.turn2.GetInfoText() : "");
		}
	}
	
	[ORKEditorHelp("Set Attacked By", "Mark that a combatant has been attacked by another combatant.\n" +
		"This can influence various things, e.g. victory gains, faction sympathy changes, etc.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle Steps")]
	public class SetAttackedByStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Target Object", label=new string[] {
			"This object will be marked as attacked by the attacker object."
		})]
		public EventObjectSetting target = new EventObjectSetting();
		
		[ORKEditorInfo(separator=true, labelText="Attacker Object", label=new string[] {
			"This object will be used to mark the target object."
		})]
		public EventObjectSetting attacker = new EventObjectSetting();
		
		public SetAttackedByStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> targetList = this.target.GetCombatant(baseEvent);
			List<Combatant> attackerList = this.attacker.GetCombatant(baseEvent);
			
			for(int i=0; i<targetList.Count; i++)
			{
				if(targetList[i] != null)
				{
					for(int j=0; j<attackerList.Count; j++)
					{
						if(attackerList[j] != null)
						{
							targetList[i].SetAttackedBy(attackerList[j], true);
						}
					}
				}
			}
			
			baseEvent.StepFinished(this.next);
		}
	}
}
