
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Change Equipment", "Changes the equipment of a combatant.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Equipment Steps")]
	public class ChangeEquipmentStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will change equipment.\n" +
			"If the actor doesn't have a combatant, no one will change equipment.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Unequip All", "All equipment of the combatant will be unequipped.", "")]
		public bool all = false;
		
		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be changed.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		[ORKEditorLayout("all", false)]
		public int id2 = 0;
		
		[ORKEditorHelp("Equip", "Select how the equipment part will be changed:\n" +
			"- None: The equipment part will be unequipped.\n" +
			"- Weapon: A weapon will be equipped.\n" +
			"- Armor: An armor will be equipped.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public EquipSet equip = EquipSet.None;
		
		[ORKEditorHelp("Equipment", "Select the equipment that will be equipped.", "")]
		[ORKEditorInfo(isPopup=true, itemFieldName="equip")]
		[ORKEditorLayout("equip", EquipSet.None, elseCheckGroup=true, endCheckGroup=true)]
		public int id3 = 0;
		
		[ORKEditorHelp("Level", "Select the level of the equipment.\n" +
			"If the level exceeds the maximum level of the equipment, the maximum level is used.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout(endCheckGroup=true)]
		public int lvl = 1;
		
		public ChangeEquipmentStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.all)
					{
						list[i].Equipment.UnequipAll(list[i].Inventory);
					}
					else
					{
						if(EquipSet.None.Equals(this.equip))
						{
							list[i].Equipment.Unequip(this.id2, list[i].Inventory, true);
						}
						else
						{
							list[i].Equipment.Equip(this.id2, 
								new EquipShortcut(this.equip, this.id3, this.lvl, 1), 
								null, true);
						}
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Check Equipment", "Checks the equipment of a combatant.\n" +
		"If the check is true, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Equipment Steps", "Check Steps")]
	public class CheckEquipmentStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be checked.\n" +
			"If the actor doesn't have a combatant, next step fail will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		public int id2 = 0;
		
		[ORKEditorHelp("Equip", "Select how the equipment part will be checked:\n" +
			"- None: The equipment part has to be unequipped.\n" +
			"- Weapon: A weapon has to be equipped.\n" +
			"- Armor: An armor has to be equipped.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public EquipSet equip = EquipSet.None;
		
		[ORKEditorHelp("Check Equipment Part", "Checks the equipment part to be " +
			"equipped with a weapon or equipped with an armor - doesn't check for a specific equipment.\n" +
			"If disabled, you'll have to define the weapon/armor that should be checked for.", "")]
		[ORKEditorLayout("equip", EquipSet.None, elseCheckGroup=true)]
		public bool checkPart = false;
		
		[ORKEditorHelp("Equipment", "Select the equipment that will be checked for.", "")]
		[ORKEditorInfo(isPopup=true, itemFieldName="equip")]
		[ORKEditorLayout("checkPart", false, endCheckGroup=true, endGroups=2)]
		public int id3 = 0;
		
		public CheckEquipmentStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			bool check = false;
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if((EquipSet.None.Equals(this.equip) && !list[i].Equipment[this.id2].Equipped) ||
						(!EquipSet.None.Equals(this.equip) && list[i].Equipment[this.id2].Equipped && 
							list[i].Equipment[this.id2].Equipment.Type.Equals(this.equip) && 
							(this.checkPart || list[i].Equipment[this.id2].Equipment.ID == this.id3)))
					{
						check = true;
						break;
					}
				}
			}
			if(check)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.EquipmentParts.GetName(this.id2);
		}
	}
	
	[ORKEditorHelp("Equipment Fork", "Checks a selected equipment part of a combatant.\n" +
		"If an equipment condition is valid, it's next step will be executed.\n" +
		"If no condition is valid, 'Failed' will be executed.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Equipment Steps", "Check Steps")]
	public class EquipmentForkStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be checked.\n" +
			"If the actor doesn't have a combatant, next step fail will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		public int id2 = 0;
		
		
		// checks
		[ORKEditorArray(false, "Add Check", "Adds a new equipment condition.", "", 
			"Remove", "Removes the equipment condition.", "", isMove=true, isCopy=true, 
			noRemoveCount=1, foldout=true, foldoutText=new string[] {
				"Equipment Condition", "Define the game variable condition that must be valid.", ""
		})]
		public EquipmentConditionNextNode[] condition = new EquipmentConditionNextNode[] {new EquipmentConditionNextNode()};
		
		public EquipmentForkStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			int check = this.next;
			
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				bool found = false;
				if(list[i] != null)
				{
					for(int j=0; j<this.condition.Length; j++)
					{
						if((EquipSet.None.Equals(this.condition[j].equip) && 
								!list[i].Equipment[this.id2].Equipped) ||
							(!EquipSet.None.Equals(this.condition[j].equip) && 
								list[i].Equipment[this.id2].Equipped && 
								list[i].Equipment[this.id2].Equipment.Type.Equals(this.condition[j].equip) && 
								list[i].Equipment[this.id2].Equipment.ID == this.condition[j].id))
						{
							check = this.condition[j].next;
							found = true;
							break;
						}
					}
				}
				if(found)
				{
					break;
				}
			}
			
			baseEvent.StepFinished(check);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.EquipmentParts.GetName(this.id2);
		}
		
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return "Condition " + (index - 1) + ": " + this.condition[index - 1].GetInfoText();
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			return this.condition.Length + 1;
		}
		
		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.condition[index - 1].next;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.condition[index - 1].next = next;
			}
		}
	}
	
	[ORKEditorHelp("Lock Equipment Part", "Locks or unlocks an equipment part of a combatant.\n" +
		"Locked equipment parts can't change equipment.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Equipment Steps")]
	public class LockEquipmentPartStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will lock/unlock an equipment part.\n" +
			"If the actor doesn't have a combatant, no one will lock/unlock an equipment part.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Lock All", "All equipment parts of the combatant will be locked/unlocked.", "")]
		public bool all = false;
		
		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be locked/unlocked.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		[ORKEditorLayout("all", false, endCheckGroup=true)]
		public int id2 = 0;
		
		[ORKEditorHelp("Lock/Unlock", "If enabled, the equipment part will be locked.\n" +
			"If disabled, the equipment part will be unlocked.", "")]
		public bool lockPart = true;
		
		public LockEquipmentPartStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.all)
					{
						list[i].Equipment.LockAll(this.lockPart);
					}
					else
					{
						list[i].Equipment[this.id2].Locked = this.lockPart;
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.all ? "All" : ORK.EquipmentParts.GetName(this.id2);
		}
	}
	
	[ORKEditorHelp("Check Part Locked", "Checks if an equipment part of a combatant is locked.\n" +
		"If the equipment part is locked, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Equipment Steps", "Check Steps")]
	public class CheckPartLockedStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be checked.\n" +
			"If the actor doesn't have a combatant, next step fail will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		public int id2 = 0;
		
		public CheckPartLockedStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			bool check = false;
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(list[i].Equipment[this.id2].Locked)
					{
						check = true;
						break;
					}
				}
			}
			if(check)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.EquipmentParts.GetName(this.id2);
		}
	}
	
	[ORKEditorHelp("Check Part Available", "Checks if an equipment part of a combatant is available.\n" +
		"An equipment part is available when a combatant can equip a weapon or armor on it (ignoring locked state) - " +
		"i.e. the equipment part either comes from combatant/class settings or " +
		"was made available by events, items, abilities, equipment or status effects." +
		"If the equipment part is available, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Equipment Steps", "Check Steps")]
	public class CheckPartAvailableStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be checked.\n" +
			"If the actor doesn't have a combatant, next step fail will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		public int id2 = 0;
		
		public CheckPartAvailableStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			bool check = false;
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(list[i].Equipment[this.id2].Available)
					{
						check = true;
						break;
					}
				}
			}
			if(check)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.EquipmentParts.GetName(this.id2);
		}
	}
	
	[ORKEditorHelp("Change Equipment Part", "Adds or removes an equipment part to/from a combatant.\n" +
		"This can be used to add extra equipment parts that aren't available due to combatant/class settings.\n" +
		"When removing, only previously added equipment parts can be removed - " +
		"to remove an equipment part granted by combatant/class settings, use the 'Change Blocked Part' step.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Equipment Steps")]
	public class ChangeEquipmentPartStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will change equipment parts.\n" +
			"If the actor doesn't have a combatant, no one will change equipment parts.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be changed.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		public int id2 = 0;
		
		[ORKEditorHelp("Change", "Select if an equipment part is added or removed.", "")]
		public SimpleChangeType change = SimpleChangeType.Add;
		
		public ChangeEquipmentPartStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(SimpleChangeType.Add.Equals(this.change))
					{
						list[i].Equipment.AddEquipmentPart(this.id2);
					}
					else if(SimpleChangeType.Remove.Equals(this.change))
					{
						list[i].Equipment.RemoveEquipmentPart(this.id2);
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.change.ToString() + " " + ORK.EquipmentParts.GetName(this.id2);
		}
	}
	
	[ORKEditorHelp("Change Blocked Part", "Adds or removes a blocked equipment part to/from a combatant.\n" +
		"A blocked part isn't available to the combatant and will automatically unequip its equipment.\n" +
		"This can be used to remove equipment parts granted by combatant/class settings.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Equipment Steps")]
	public class ChangeBlockedPartStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will change blocked equipment parts.\n" +
			"If the actor doesn't have a combatant, no one will change blocked equipment parts.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Equipment Part", "Select the equipment part that will be changed.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		public int id2 = 0;
		
		[ORKEditorHelp("Change", "Select if a blocked equipment part is added or removed.", "")]
		public SimpleChangeType change = SimpleChangeType.Add;
		
		public ChangeBlockedPartStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(SimpleChangeType.Add.Equals(this.change))
					{
						list[i].Equipment.AddBlockedEquipmentPart(this.id2);
					}
					else if(SimpleChangeType.Remove.Equals(this.change))
					{
						list[i].Equipment.RemoveBlockedEquipmentPart(this.id2);
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.change.ToString() + " " + ORK.EquipmentParts.GetName(this.id2);
		}
	}
}
