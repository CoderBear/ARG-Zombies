
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public class EventFloat : BaseData
	{
		[ORKEditorHelp("Value Type", "Select which kind of value will be used:\n" +
			"- Value: A defined value.\n" +
			"- Game Variable: The value of a game variable (float).\n" +
			"- Player Prefs: The value of a PlayerPrefs int or float variable.\n" +
			"- Formula: The result of a formula.\n" +
			"- Game Time: The current game time in seconds (time since 'New Game').\n" +
			"- Time Of Day: The current real time since midnight in seconds.\n" +
			"- Date And Time: The current real date and time in seconds (since 1-1-1970).", "")]
		public NumberValueType type = NumberValueType.Value;
		
		
		// variable
		[ORKEditorHelp("Variable Origin", "Select the origin of the variable:\n" +
			"- Local: Local variables are only used in a running event and don't interfere with global variables. " +
			"The variable will be gone once the event ends.\n" +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.", "")]
		[ORKEditorLayout("type", NumberValueType.GameVariable)]
		public VariableOrigin origin = VariableOrigin.Global;
		
		// object variables
		[ORKEditorHelp("Use Object", "Use the 'Object Variables' component of game objects to change the object variables.\n" +
			"The changes will be made on every 'Object Variables' component that is found. " +
			"If no component is found, no variables will be changed.\n" +
			"If disabled, you need to define the object ID used to change the object variables.", "")]
		[ORKEditorLayout("origin", VariableOrigin.Object)]
		public bool useObject = true;
		
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting fromObject;
		
		[ORKEditorHelp("Object ID", "Define the object ID of the object variables.\n" +
			"If the object ID doesn't exist yet, it will be created.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=3)]
		public string objectID = "";
		
		// variable and player prefs
		[ORKEditorHelp("Variable Key", "The key (name) of the game variable (float) or PlayerPrefs that contains the value.", "")]
		[ORKEditorInfo(expandWidth=true, isVariableField=true)]
		[ORKEditorLayout(new string[] {"type", "type"}, 
			new System.Object[] {NumberValueType.GameVariable, NumberValueType.PlayerPrefs}, 
			needed=Needed.One, endCheckGroup=true)]
		public string name = "";
		
		[ORKEditorHelp("Is Int", "The value will be taken from an Integer PlayerPrefs (using GetInt).\n" +
			"If disabled, the value will be taken from a Float PlayerPrefs (using GetFloat).", "")]
		[ORKEditorLayout("type", NumberValueType.PlayerPrefs, endCheckGroup=true)]
		public bool isInt = false;
		
		
		// formula
		[ORKEditorHelp("User Actor", "Select the actor used as user when calculating the formula.\n" +
			"If the actor isn't a combatant, the value will be 0.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("type", NumberValueType.Formula)]
		public int id = 0;
		
		[ORKEditorHelp("Target Actor", "Select the actor used as target when calculating the formula.\n" +
			"If the actor isn't a combatant, the value will be 0.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id2 = 0;
		
		[ORKEditorHelp("Formula", "Select the formula used for calculation.", "")]
		[ORKEditorInfo(ORKDataType.Formula)]
		public int id3 = 0;
		
		[ORKEditorHelp("Initial Value", "The initial value passed to the formula.\n" +
			"The formula will use the initial value as it's base and start the calculation with that value.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public float initialValue = 0;
		
		
		// game time offset
		[ORKEditorHelp("Time Offset (s)", "The offset time in seconds that will be added to the current game time.", "")]
		[ORKEditorLayout(new string[] {"type", "type", "type"}, 
			new System.Object[] {NumberValueType.GameTime, NumberValueType.TimeOfDay, NumberValueType.DateAndTime}, 
			needed=Needed.One, endCheckGroup=true)]
		public float offset = 0;
		
		[ORKEditorHelp("Is UTC", "The date and time are in UTC format.\n" +
			"If disabled, the local date and time is used.", "")]
		[ORKEditorLayout("type", NumberValueType.DateAndTime, endCheckGroup=true)]
		public bool isUTC = false;
		
		
		// value
		[ORKEditorHelp("Value", "Define the value that will be used.", "")]
		[ORKEditorLayout("type", NumberValueType.Value)]
		public float value = 0;
		
		
		// rounding
		[ORKEditorHelp("Rounding", "Rounds the value of the formula or game variable (float).\n" +
			"- None: No rounding.\n" +
			"- Ceil: The value will be rounded up (e.g. 14.2 will become 15).\n" +
			"- Floor: The value will be rounded down (e.g. 14.8 will become 14).\n" +
			"- Round: The value will be rounded to the nearest integer (e.g. 14.2 will become 14, 14.8 will become 15).", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public Rounding rounding = Rounding.None;
		
		public EventFloat()
		{
			
		}
		
		public EventFloat(float value)
		{
			this.value = value;
		}
		
		public float GetValue(BaseEvent baseEvent)
		{
			if(NumberValueType.Value.Equals(this.type))
			{
				return this.value;
			}
			else if(NumberValueType.GameVariable.Equals(this.type))
			{
				if(VariableOrigin.Local.Equals(this.origin))
				{
					return ValueHelper.GetRounded(baseEvent.Variables.GetFloat(this.name), this.rounding);
				}
				else if(VariableOrigin.Global.Equals(this.origin))
				{
					return ValueHelper.GetRounded(ORK.Game.Variables.GetFloat(this.name), this.rounding);
				}
				else if(VariableOrigin.Object.Equals(this.origin))
				{
					if(this.useObject)
					{
						List<GameObject> list = this.fromObject.GetObject(baseEvent);
						for(int i=0; i<list.Count; i++)
						{
							if(list[i] != null)
							{
								ObjectVariablesComponent[] comps = list[i].
									GetComponentsInChildren<ObjectVariablesComponent>();
								if(comps.Length > 0)
								{
									return ValueHelper.GetRounded(comps[0].GetHandler().
										GetFloat(this.name), this.rounding);
								}
							}
						}
					}
					else
					{
						return ValueHelper.GetRounded(ORK.Game.Scene.GetObjectVariables(this.objectID).
							GetFloat(this.name), this.rounding);
					}
				}
			}
			else if(NumberValueType.PlayerPrefs.Equals(this.type))
			{
				if(this.isInt)
				{
					return ValueHelper.GetRounded(PlayerPrefs.GetInt(this.name), this.rounding);
				}
				else
				{
					return ValueHelper.GetRounded(PlayerPrefs.GetFloat(this.name), this.rounding);
				}
			}
			else if(NumberValueType.Formula.Equals(this.type))
			{
				Combatant user = ComponentHelper.GetFirstCombatant(baseEvent.GetActorObject(this.id));
				Combatant target = ComponentHelper.GetFirstCombatant(baseEvent.GetActorObject(this.id2));
				if(user != null && target != null)
				{
					return ValueHelper.GetRounded(ORK.Formulas.Get(this.id3).Calculate(this.initialValue, user, target), this.rounding);
				}
			}
			else if(NumberValueType.GameTime.Equals(this.type))
			{
				return ValueHelper.GetRounded(ORK.Game.GameTime + this.offset, this.rounding);
			}
			else if(NumberValueType.TimeOfDay.Equals(this.type))
			{
				return ValueHelper.GetRounded((float)(System.DateTime.Now.TimeOfDay.TotalSeconds) + this.offset, this.rounding);
			}
			else if(NumberValueType.DateAndTime.Equals(this.type))
			{
				return ValueHelper.GetRounded(
					(float)((System.DateTime.Now - new System.DateTime(1970, 1, 1, 0, 0, 0)).TotalSeconds) + 
					this.offset, this.rounding);
			}
			return 0;
		}
		
		
		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			if(NumberValueType.Value.Equals(this.type))
			{
				return this.value.ToString();
			}
			else if(NumberValueType.GameVariable.Equals(this.type))
			{
				return this.name + " (" + this.origin + ")";
			}
			else if(NumberValueType.Formula.Equals(this.type))
			{
				return ORK.Formulas.GetName(this.id3);
			}
			else if(NumberValueType.GameTime.Equals(this.type))
			{
				return "Game time + " + this.offset;
			}
			else if(NumberValueType.TimeOfDay.Equals(this.type))
			{
				return "Real time since midnight + " + this.offset;
			}
			else if(NumberValueType.DateAndTime.Equals(this.type))
			{
				return "Real date/time + " + this.offset;
			}
			else
			{
				return this.name;
			}
		}
	}
}
