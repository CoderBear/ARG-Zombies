
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleAnimation : BaseData
	{
		[ORKEditorHelp("Battle Event", "Select the battle event that will be performed.", "")]
		public ORKBattleEvent evt;
		
		[ORKEditorHelp("Chance", "The chance this battle event will be performed.", "")]
		public float chance = 100;
		
		
		// system types
		[ORKEditorHelp("Field", "The battle event will be performed in the field (i.e. outside of battles).", "")]
		[ORKEditorInfo(separator=true, labelText="Perform In")]
		public bool field = false;
		
		[ORKEditorHelp("Turn Based", "The battle event will be performed in 'Turn Based' battles.", "")]
		public bool turnBased = true;
		
		[ORKEditorHelp("Active Time", "The battle event will be performed in 'Active Time' battles.", "")]
		public bool activeTime = true;
		
		[ORKEditorHelp("Real Time", "The battle event will be performed in 'Real Time' battles.", "")]
		public bool realTime = true;
		
		[ORKEditorHelp("Phase", "The battle event will be performed in 'Phase' battles.", "")]
		public bool phase = true;
		
		
		// override prefabs
		[ORKEditorHelp("Set Prefabs", "Override the battle event's prefabs.\n" +
			"This allows ", "")]
		[ORKEditorInfo(separator=true, labelText="Prefabs Settings")]
		public bool setPrefabs = false;
		
		[ORKEditorArray(false, "Add Prefab", "Adds a prefab to this animation.\n" +
			"The prefabs will override the battle animation's prefabs.\n" +
			"Keep in mind that you need to add prefabs in the battle event as well, " +
			"or you wont be able to select them in the event steps.", "", 
			"Remove", "Removes this prefab from the event.", "", isCopy=true, isMove=true, noRemoveCount=1, 
			foldout=true, foldoutText=new string[] {"Prefab", "This prefab can be used in the event steps.", ""})]
		[ORKEditorLayout("setPrefabs", true, endCheckGroup=true, autoInit=true, autoSize=1)]
		public EventPrefab[] prefab;
		
		
		// override audio clips
		[ORKEditorHelp("Set Audio Clips", "Override the battle event's audio clips.\n" +
			"This allows ", "")]
		[ORKEditorInfo(separator=true, labelText="Audio Clip Settings")]
		public bool setAudioClips = false;
		
		[ORKEditorArray(false, "Add Audio Clip", "Adds an audio clip to this animation.\n" +
			"The audio clips will override the battle animation's audio clips.\n" +
			"Keep in mind that you need to add audio clips in the battle event as well, " +
			"or you wont be able to select them in the event steps.", "", 
			"Remove", "Removes this audio clip from the event.", "", isCopy=true, isMove=true, noRemoveCount=1, 
			foldout=true, foldoutText=new string[] {"Audio Clip", "This audio clip can be used in the event steps.", ""})]
		[ORKEditorLayout("setAudioClips", true, endCheckGroup=true, autoInit=true, autoSize=1)]
		public EventAudio[] audioClip;
		
		public BattleAnimation()
		{
			
		}
		
		public void GetEvent(ref List<BattleEvent> list, Combatant user)
		{
			if(this.evt != null && 
				ORK.GameSettings.CheckRandom(this.chance) && 
			// in field
				((!user.InBattle && this.field) || 
			// in battle
				(user.InBattle && 
				((this.turnBased && ORK.Battle.IsTurnBased()) || 
				(this.activeTime && ORK.Battle.IsActiveTime()) || 
				(this.realTime && ORK.Battle.IsRealTime()) || 
				(this.phase && ORK.Battle.IsPhase())))))
			{
				BattleEvent be = new BattleEvent();
				be.SetData(this.evt.GetData().ToDataObject());
				
				if(this.setPrefabs)
				{
					be.SetPrefabs(this.prefab);
				}
				if(this.setAudioClips)
				{
					be.SetAudioClips(this.audioClip);
				}
				
				list.Add(be);
			}
		}
	}
}
