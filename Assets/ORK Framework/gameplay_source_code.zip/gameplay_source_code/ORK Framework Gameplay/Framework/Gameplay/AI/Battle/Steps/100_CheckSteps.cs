
using ORKFramework;
using ORKFramework.AI;
using ORKFramework.Behaviours;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.AI.Steps
{
	[ORKEditorHelp("Check Chance", "Which step will be executed next is decided by chance.\n" +
		"The chance is checked against a random number between two values (default 0 and 100, " +
		"you can change this in the game settings). When using a formula, the user of the battle AI is used as user and target.\n" +
		"If the random number is less or equal to the defined chance, 'Success' is executed, else 'Failed'.", "")]
	[ORKNodeInfo("Check Steps")]
	public class CheckChanceStep : BaseAICheckStep
	{
		[ORKEditorInfo(labelText="Chance")]
		public AIFloat chance = new AIFloat();
		
		public CheckChanceStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			if(ORK.GameSettings.CheckRandom(this.chance.GetValue(user, user)))
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.chance.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Chance Fork", "Which step will be executed next is decided by chance.\n" +
		"he chance is checked against a random number between two values (default 0 and 100, " +
		"you can change this in the game settings). " +
		"When using a formula, the user of the battle AI is used as user and target.\n" +
		"The next step of the first defined value range, that includes the chance, will be executed.\n" +
		"If no range contains the chance, 'Failed' will be executed.", "")]
	[ORKNodeInfo("Check Steps")]
	public class ChanceForkStep : BaseAIStep
	{
		[ORKEditorArray(false, "Add Range", "Adds a range for the chance check.", "", 
			"Remove", "Removes this range.", "", isCopy=true, isMove=true, noRemoveCount=1, 
			foldout=true, foldoutText=new string[] {
				"Range", "Define the minimum and maximum value of the range.\n" +
				"If the random chance value is within the range (i.e. minimum <= chance <= maximum), " +
				"this range's next step will be executed.", ""
		})]
		public ChanceAINextNode[] range = new ChanceAINextNode[] {new ChanceAINextNode()};
		
		public ChanceForkStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			currentStep = this.next;
			
			float chance = ORK.GameSettings.GetRandom();
			
			for(int i=0; i<this.range.Length; i++)
			{
				if(this.range[i].Contains(chance, user, user))
				{
					currentStep = this.range[i].next;
					break;
				}
			}
			
			return null;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return (index - 1).ToString() + ": " + 
					this.range[index - 1].GetInfoText();
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			return this.range.Length + 1;
		}
		
		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.range[index - 1].next;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.range[index - 1].next = next;
			}
		}
	}
	
	[ORKEditorHelp("Check Difficulty", "Checks the game's currently selected difficulty.\n" +
		"If the check is true, 'Success' will be executed next, else 'Failed'.", "")]
	[ORKNodeInfo("Check Steps")]
	public class CheckDifficultyStep : BaseAICheckStep
	{
		[ORKEditorHelp("Difficulty", "Select the difficulty that will be checked for.", "")]
		[ORKEditorInfo(ORKDataType.Difficulty)]
		public int id = 0;
		
		[ORKEditorHelp("Check Type", "Checks if the game's difficulty is equal, not equal, less or greater than the selected difficulty.\n" +
			"The difficulty (level) is determined by the ID of the difficulty, e.g. ID 0 is less than ID 1, ID 3 is greater than ID 2.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public ValueCheck check = ValueCheck.IsEqual;
		
		public CheckDifficultyStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			if(ValueHelper.CheckValue(ORK.Game.Difficulty, this.id, this.check))
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check + " " + ORK.Difficulties.GetName(this.id);
		}
	}
	
	[ORKEditorHelp("Check Object Variables", "Checks a combatant's object variables " +
		"(requires an 'Object Variables' component attached to the combatant's game object).\n" +
		"If the check is true, 'Success' will be executed, else 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Check Steps", "Variable Steps")]
	public class CheckObjectVariablesStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings.\n" +
			"- Clear: The targets will be removed from the list.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;
		
		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public TargetType targetType = TargetType.Ally;
		
		
		// variables
		[ORKEditorInfo(separator=true)]
		public VariableCondition condition = new VariableCondition();
		
		public CheckObjectVariablesStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			bool any = false;
			if(FoundTargets.Clear.Equals(this.foundType))
			{
				foundTargets.Clear();
			}
			else if(FoundTargets.Check.Equals(this.foundType))
			{
				List<Combatant> tmp = new List<Combatant>(foundTargets);
				foundTargets.Clear();
				this.Check(ref any, tmp, foundTargets);
			}
			
			// check all possible targets
			this.Check(ref any, this.GetTargetList(this.targetType, user, allies, enemies), foundTargets);
			
			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}
		
		private void Check(ref bool any, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check object variables of all possible targets, add to found targets
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null && list[i].GameObject != null)
				{
					ObjectVariablesComponent comp = ComponentHelper.GetInChildren<ObjectVariablesComponent>(list[i].GameObject);
					if(comp != null && this.condition.CheckVariables(comp.GetHandler()))
					{
						any = true;
						if(!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetType + ", " + this.foundType + " found";
		}
	}
	
	[ORKEditorHelp("Check Game Variables", "Checks game variable conditions.\n" +
		"If the check is true, 'Success' will be executed, else 'Failed'.\n" +
		"Doesn't influence the target list.", "")]
	[ORKNodeInfo("Check Steps", "Variable Steps")]
	public class CheckGameVariablesStep : BaseAICheckStep
	{
		// variables
		public VariableCondition condition = new VariableCondition();
		
		public CheckGameVariablesStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			if(this.condition.CheckVariables())
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}
	}
	
	[ORKEditorHelp("Game Variable Fork", "Checks a single game variable for certain values.\n" +
		"If a variable condition is valid, it's next step will be executed.\n" +
		"If no variable condition is valid, 'Failed' will be executed.", "")]
	[ORKNodeInfo("Check Steps")]
	public class GameVariableForkStep : BaseAIStep
	{
		// variable
		[ORKEditorInfo(labelText="Variable Key")]
		public StringValue key = new StringValue();
		
		[ORKEditorArray(false, "Add Condition", "Adds a new game variable condition.", "", 
			"Remove", "Removes the game variable condition.", "", isMove=true, isCopy=true, 
			noRemoveCount=1, foldout=true, foldoutText=new string[] {
				"Variable Condition", "Define the game variable condition that must be valid.", ""
		})]
		public CheckVariableAINextNode[] condition = new CheckVariableAINextNode[] {new CheckVariableAINextNode()};
		
		public GameVariableForkStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			currentStep = this.next;
			
			string varKey = this.key.GetValue();
			
			for(int i=0; i<this.condition.Length; i++)
			{
				if(this.condition[i].Check(varKey, ORK.Game.Variables))
				{
					currentStep = this.condition[i].next;
					break;
				}
			}
			
			return null;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.key.GetInfoText();
		}
		
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return "Condition " + (index - 1) + ": " + this.condition[index - 1].GetInfoText();
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			return this.condition.Length + 1;
		}
		
		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.condition[index - 1].next;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.condition[index - 1].next = next;
			}
		}
	}
	
	[ORKEditorHelp("Check Target Count", "Checks the number of found targets.\n" +
		"If the check is true, 'Success' will be executed, else 'Failed'.\n" +
		"Doesn't influence the target list.", "")]
	[ORKNodeInfo("Check Steps")]
	public class CheckTargetCountStep : BaseAICheckStep
	{
		[ORKEditorHelp("Check Type", "Checks if the number of found targets is equal, not equal, " +
			"less or greater than a defined value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public ValueCheck check = ValueCheck.IsEqual;
		
		[ORKEditorInfo(separator=true, labelText="Target Count")]
		[ORKEditorLabel("Formula uses the user as both user and target.")]
		public AIFloat value = new AIFloat();
		
		public CheckTargetCountStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			if(ValueHelper.CheckValue(foundTargets.Count, this.value.GetValue(user, user), this.check))
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}
	}
}
