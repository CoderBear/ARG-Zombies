
using UnityEngine;
using ORKFramework;
using ORKFramework.Display;
using ORKFramework.Menu.Parts;
using System.Collections.Generic;

namespace ORKFramework.Menu
{
	public class CombatantPage : BaseData
	{
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used GUI box.", "")]
		public bool useTitle = false;
		
		[ORKEditorHelp("Title", "The title of the combatant box.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {"%n = combatant name"})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitle", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] title;
		
		
		// status elements
		[ORKEditorHelp("Use HUD", "Use the status elements defined in a HUD.\n" +
			"Only the status elements of the HUD will be used, the rest of the HUD's settings are ignored.", "")]
		public bool useHUD = false;
		
		[ORKEditorHelp("HUD", "Select the HUD that will be used.\n" +
			"Only 'Combatant' type HUDs are allowed. Using any other HUD or a " +
			"'Combatant' type HUD without status elements result in an empty box.", "")]
		[ORKEditorInfo(ORKDataType.HUD, "type", HUDType.Combatant, true)]
		[ORKEditorLayout("useHUD", true)]
		public int hudID = 0;
		
		[ORKEditorArray(false, "Add Status Element", "Adds a status element to the combatant information.\n" +
			"Status elements display information about the combatants - each combatant is represented by a button, " +
			"each button displays the status elements defined here.", "", 
			"Remove", "Removes this status element.", "", isMove=true, isCopy=true, 
			foldout=true, foldoutText=new string[] {"Status Element", 
				"Set the position, size, content and background image of this element.\n" +
				"The coordinates X=0, Y=0 are located at the upper left corner of the button representing a combatant.", ""})]
		[ORKEditorInfo(instanceCallback="button:CombatantPageToCombatantHUD")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public HUDStatus[] statusElement;
		
		public CombatantPage()
		{
			
		}
		
		public GUIBoxContent GetCombatantPage(IChoice parent, Combatant combatant, MenuCombatantScope scope, bool isButton)
		{
			ChoiceContent[] choice = null;
			string tmpTitle = "";
			
			if(combatant != null)
			{
				// get combatants
				List<Combatant> list = new List<Combatant>();
				if(MenuCombatantScope.Current.Equals(scope))
				{
					list.Add(combatant);
				}
				else if(MenuCombatantScope.Battle.Equals(scope))
				{
					list.AddRange(combatant.Group.GetBattle());
				}
				else if(MenuCombatantScope.Group.Equals(scope))
				{
					list.AddRange(combatant.Group.GetGroup());
				}
				
				// create choice list
				choice = new ChoiceContent[list.Count];
				for(int i=0; i<choice.Length; i++)
				{
					choice[i] = new ChoiceContent();
					choice[i].combatant = list[i];
					choice[i].isButton = isButton;
				}
				
				if(this.useTitle)
				{
					tmpTitle = this.title[ORK.Game.Language];
					if(list.Count > 0 && list[0] != null)
					{
						tmpTitle = tmpTitle.Replace("%n", list[0].GetName());
					}
				}
			}
			return new DialogueContent("", tmpTitle, choice, parent, 0, null, 
				this.useHUD ? ORK.HUDs.Get(this.hudID).combatantElement : this.statusElement);
		}
		
		public GUIBoxContent GetBestiaryPage(IChoice parent, Combatant combatant, int portraitType)
		{
			return new BestiaryHUDContent(combatant, 
				this.useTitle ? 
					this.title[ORK.Game.Language].
						Replace("%n", combatant != null ? combatant.Setting.GetName() : "") : 
					"", 
				portraitType, parent, 
				this.useHUD ? ORK.HUDs.Get(this.hudID).combatantElement : this.statusElement);
		}
		
		public void UpdateBestiaryPage(BestiaryHUDContent content, IChoice parent, Combatant combatant, int portraitType)
		{
			content.Update(combatant, 
				this.useTitle ? 
					this.title[ORK.Game.Language].
						Replace("%n", combatant != null ? combatant.Setting.GetName() : "") : 
					"", 
				portraitType, parent, 
				this.useHUD ? ORK.HUDs.Get(this.hudID).combatantElement : this.statusElement);
		}
	}
}
