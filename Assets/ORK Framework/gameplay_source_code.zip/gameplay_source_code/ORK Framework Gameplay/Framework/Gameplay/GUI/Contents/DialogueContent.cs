
using UnityEngine;
using UnityEngine.UI;
using ORKFramework;
using ORKFramework.Display;
using ORKFramework.Behaviours;
using ORKFramework.Menu.Parts;
using System.Collections.Generic;

namespace ORKFramework
{
	public class DialogueContent : GUIBoxContent
	{
		// content
		public string text = "";
		
		public MultiContent content;

		public ChoiceContent[] choice;
		
		private List<ChoiceContent> oldChoice;
		
		public HUDStatus[] statusInformation;
		
		private bool markUpdate = false;
		
		
		// text typing
		private int typingIndex = 0;
		
		private bool isTyping = false;
		
		private float typingInterval = 0;
		
		private float typingAudioInterval = 0;
		
		
		// set portrait
		private Portrait setPortrait;
		
		public PortraitPosition setPortraitPosition;
		
		// displayed portrait
		private Portrait portrait;
		
		private PortraitPosition portraitPosition;
		
		
		// choice
		private int maxCol = 0;

		private int colCount = 0;
		
		private float choiceTimeout = 0;
		
		
		// tabs
		private ChoiceContent[] tabs;
		
		private int tabsSelection = 0;
		
		private Rect tabsContentBounds;
		
		private Rect tabsBounds;
		
		private bool tabsScrollButtons = false;
		
		private int tabsScrollOffset = 0;
		
		private ChoiceContent tabsLeftArrow;
		
		private ChoiceContent tabsRightArrow;
		
		public DialogueContent(string text, string name, ChoiceContent[] choice, IChoice ci) : this(text, name, choice, ci, 0, null, null)
		{
			
		}
		
		public DialogueContent(string text, string name, ChoiceContent[] choice, IChoice ci, 
			int startSelection) : this(text, name, choice, ci, startSelection, null, null)
		{
			
		}
		
		public DialogueContent(string text, string name, ChoiceContent[] choice, IChoice ci, 
			int startSelection, Portrait speakerPortrait) : this(text, name, choice, ci, startSelection, speakerPortrait, null)
		{
			
		}
		
		public DialogueContent(string text, string name, ChoiceContent[] choice, IChoice ci, 
			int startSelection, Portrait speakerPortrait, HUDStatus[] statusInformation)
		{
			this.text = text;
			this.SetName(name);
			this.choice = choice;
			this.controlInterface = ci;
			this.selection = startSelection;
			this.setPortrait = speakerPortrait;
			this.statusInformation = statusInformation;
			
			if(this.choice != null && this.selection >= this.choice.Length)
			{
				this.selection = this.choice.Length - 1;
			}
		}
		
		public void Update(string text, string name, ChoiceContent[] choice, int startSelection, 
			Portrait speakerPortrait, HUDStatus[] statusInformation)
		{
			if(ORK.GUI.IsNewUI && this.choice != null)
			{
				if(this.oldChoice == null)
				{
					this.oldChoice = new List<ChoiceContent>();
				}
				this.oldChoice.AddRange(this.choice);
			}
			
			this.text = text;
			this.SetName(name);
			this.choice = choice;
			this.setPortrait = speakerPortrait;
			this.statusInformation = statusInformation;
			this.selection = startSelection;
			
			
			if(this.choice != null && this.selection >= this.choice.Length)
			{
				this.selection = this.choice.Length - 1;
			}
			
			this.newContent = true;
		}
		
		
		/*
		============================================================================
		Control functions
		============================================================================
		*/
		public override void Tick()
		{
			base.Tick();
			if(this.box != null)
			{
				if(this.markUpdate)
				{
					this.markUpdate = false;
					this.newContent = true;
				}
				else
				{
					if(this.isTyping && this.box.Settings.useTextTyping && 
						ORK.Game.TextSpeed > 0)
					{
						// index
						if(this.typingInterval <= 0)
						{
							this.typingIndex += this.box.Settings.typingIncrease;
							this.typingInterval = this.box.Settings.typingInterval / ORK.Game.TextSpeed;
							
							if(ORK.GUI.IsNewUI && this.content != null)
							{
								this.content.DoNewUITyping(ref this.isTyping, ref this.typingIndex, 
									ref this.typingInterval, ref this.typingAudioInterval);
							}
						}
						else
						{
							this.typingInterval -= ORK.Core.GUITimeDelta;
						}
						// audio
						if(this.box.Settings.typingClip != null)
						{
							if(this.typingAudioInterval <= 0)
							{
								ORK.Audio.PlayOneShot(this.box.Settings.typingClip, 
									this.box.Settings.typingVolume * ORK.Game.SoundVolume);
								this.typingAudioInterval = this.box.Settings.typingAudioInterval / ORK.Game.TextSpeed;
							}
							else
							{
								this.typingAudioInterval -= ORK.Core.GUITimeDelta;
							}
						}
					}
					
					// choice icon fade
					if(this.choice != null && this.selection >= 0 && 
						this.selection < this.choice.Length && 
						!this.box.disableChoice && this.box.Controlable)
					{
						this.box.ChoiceIcon.Tick(ORK.Core.GUITimeDelta, 
							ref this.iconFadingBack, ref this.iconFadePos, ref this.iconTime);
						
						if(this.choiceIconObject != null)
						{
							this.box.ChoiceIcon.SetObjectPosition(this.choiceIconObject, 
								this.iconFadePos, this.choice[this.selection].buttonBounds, 
								this.contentBounds, this.scroll.y, this.box.Focused);
						}
					}
					else if(this.choiceIconObject != null)
					{
						this.choiceIconObject.gameObject.SetActive(false);
					}
					
					if(this.box.Controlable && 
						this.controlInterface != null && this.box.Focused && 
						!this.controlInterface.Tick(this.box))
					{
						if(!this.box.disableChoice)
						{
							if(ORK.InputKeys.Get(ORK.GameControls.acceptKey).GetButton())
							{
								this.OkPressed();
							}
							else if(this.choice != null && this.choice.Length > 0 && 
								(Time.realtimeSinceStartup - this.choiceTimeout) > ORK.GameControls.cursorTimeout)
							{
								float v = 0;
								float h = 0;
								if(ColumnFill.Vertical.Equals(this.box.Settings.columnFill))
								{
									v = this.maxCol > 1 ? ORK.InputKeys.Get(ORK.GameControls.verticalAxis).GetAxis() : 0;
									h = this.colCount > 1 ? ORK.InputKeys.Get(ORK.GameControls.horizontalAxis).GetAxis() : 0;
								}
								else if(ColumnFill.Horizontal.Equals(this.box.Settings.columnFill))
								{
									v = this.colCount > 1 ? ORK.InputKeys.Get(ORK.GameControls.verticalAxis).GetAxis() : 0;
									h = this.maxCol > 1 ? ORK.InputKeys.Get(ORK.GameControls.horizontalAxis).GetAxis() : 0;
								}
								
								if(v < -0.3)
								{
									this.box.Audio.PlayCursorMove();
									this.ChangeSelectionVertical(1);
									this.choiceTimeout = Time.realtimeSinceStartup;
								}
								else if(v > 0.3)
								{
									this.box.Audio.PlayCursorMove();
									this.ChangeSelectionVertical(-1);
									this.choiceTimeout = Time.realtimeSinceStartup;
								}
								else if(h > 0.3)
								{
									this.box.Audio.PlayCursorMove();
									this.ChangeSelectionHorizontal(1);
									this.choiceTimeout = Time.realtimeSinceStartup;
								}
								else if(h < -0.3)
								{
									this.box.Audio.PlayCursorMove();
									this.ChangeSelectionHorizontal(-1);
									this.choiceTimeout = Time.realtimeSinceStartup;
								}
							}
						}
						
						if(ORK.InputKeys.Get(ORK.GameControls.cancelKey).GetButton())
						{
							this.CancelPressed();
						}
						else if(this.choice == null || this.choice.Length == 0 || this.box.disableChoice)
						{
							float v = ORK.InputKeys.Get(ORK.GameControls.verticalAxis).GetAxis();
							if(v < -0.3)
							{
								this.scroll.y += ORK.MenuSettings.scrollSpeed;
							}
							else if(v > 0.3)
							{
								this.scroll.y -= ORK.MenuSettings.scrollSpeed;
							}
						}
					}
				}
			}
		}
		
		public override void OkPressed()
		{
			ORK.InputKeys.ResetInputAxes();
			if(this.controlInterface != null)
			{
				if(this.choice == null || this.choice.Length == 0 || 
					this.choice[this.selection].Active)
				{
					this.box.Audio.PlayAccept();
					if(this.isTyping)
					{
						this.isTyping = false;
						
						if(ORK.GUI.IsNewUI && this.content != null)
						{
							this.content.NewUIFullTyped();
						}
					}
					else if(this.content.remainingText != "" && 
						(this.choice == null || this.choice.Length == 0))
					{
						this.text = this.content.remainingText;
						this.newContent = true;
					}
					else
					{
						this.controlInterface.ChoiceSelected(this.selection, this.box);
					}
				}
				else
				{
					this.box.Audio.PlayFail();
					this.controlInterface.SelectionChanged(this.selection, this.box);
				}
			}
		}
		
		public override void CancelPressed()
		{
			ORK.InputKeys.ResetInputAxes();
			if(this.controlInterface != null)
			{
				this.controlInterface.Canceled(this.box);
			}
		}
		
		public override void Closed()
		{
			if(this.statusInformation != null && this.choice != null)
			{
				for(int i=0; i<this.choice.Length; i++)
				{
					if(this.choice[i].combatant != null)
					{
						this.choice[i].combatant.UpdateHUD -= this.Recalculate;
					}
				}
				ORK.GUI.UpdateHUD -= this.Recalculate;
			}
			if(this.controlInterface != null)
			{
				this.controlInterface.Closed(this.box);
			}
		}
		
		
		/*
		============================================================================
		Selection functions
		============================================================================
		*/
		public override int Selection
		{
			get{ return this.selection;}
			set
			{
				if(this.selection != value)
				{
					if(this.choice != null && this.choice.Length > 0 && 
						value >= 0 && value < this.choice.Length)
					{
						if(this.choice[value].buttonBounds.y < this.scroll.y)
						{
							this.scroll.y = this.choice[value].buttonBounds.y;
						}
						else if((this.scroll.y + this.contentBounds.height) < 
							this.choice[value].buttonBounds.y + this.choice[value].buttonBounds.height)
						{
							this.scroll.y += (this.choice[value].buttonBounds.y + this.choice[value].buttonBounds.height) - 
								(this.scroll.y + this.contentBounds.height);
						}
						
						if(this.scrollRectTransform != null)
						{
							this.scrollRectTransform.anchoredPosition = this.scroll;
						}
					}
					this.UpdateSelectedPosition(false);
					this.selection = value;
					this.UpdateSelectedPosition(true);
					this.UpdatePortrait();
					
					// new UI > set choice selected
					if(ORK.GUI.IsNewUI && 
						ORK.GUI.EventSystem != null && 
						this.choice != null && 
						this.selection >= 0 && this.selection < this.choice.Length)
					{
						ORK.GUI.EventSystem.SetSelectedGameObject(this.choice[this.selection].gameObject);
					}
				}
				if(this.controlInterface != null)
				{
					this.controlInterface.SelectionChanged(this.selection, this.box);
				}
			}
		}
		
		private void UpdateSelectedPosition(bool add)
		{
			if(!ORK.GUI.IsNewUI && 
				this.box.Settings.selectedChoiceOffset != 0 && this.choice != null && 
				this.selection >= 0 && this.selection < this.choice.Length)
			{
				this.choice[this.selection].MoveX(add ? 
					this.box.Settings.selectedChoiceOffset : 
					-this.box.Settings.selectedChoiceOffset);
			}
		}
		
		private void ChangeSelectionHorizontal(int add)
		{
			if(ColumnFill.Vertical.Equals(this.box.Settings.columnFill))
			{
				this.ChangeSelection(add * this.maxCol);
			}
			else
			{
				this.ChangeSelection(add);
			}
		}
		
		private void ChangeSelectionVertical(int add)
		{
			if(ColumnFill.Vertical.Equals(this.box.Settings.columnFill))
			{
				this.ChangeSelection(add);
			}
			else
			{
				this.ChangeSelection(add * this.maxCol);
			}
		}
		
		private void ChangeSelection(int add)
		{
			if(this.maxCol > 0 && this.choice != null && this.choice.Length > 0)
			{
				int index = this.selection + add;
				
				if(add == 1 && this.maxCol > 1 && 
					index >= 0 && index < this.choice.Length && 
					index % this.maxCol == 0)
				{
					index -= this.maxCol;
				}
				else if(add == -1 && this.maxCol > 1 && 
					index >= 0 && index < this.choice.Length && 
					(index + 1) % this.maxCol == 0)
				{
					index += this.maxCol;
				}
				else if(add > 1 || add < -1)
				{
					if(index < 0)
					{
						index += this.maxCol * this.colCount;
					}
					else if(index >= this.choice.Length)
					{
						index -= this.maxCol * this.colCount;
					}
				}
				
				if(this.box.Settings.loop)
				{
					if(index < 0)
					{
						index = this.choice.Length - 1;
					}
					else if(index >= this.choice.Length)
					{
						index = 0;
					}
				}
				else
				{
					if(index < 0)
					{
						index = 0;
					}
					else if(index >= this.choice.Length)
					{
						index = this.choice.Length - 1;
					}
				}
				
				this.Selection = index;
			}
		}
		
		
		/*
		============================================================================
		Drag/drop functions
		============================================================================
		*/
		public override ChoiceContent GetDragOnPosition(Vector2 position)
		{
			if(this.box != null && this.box.Controlable)
			{
				this.box.SetFocus();
				
				if(this.box.Focused && this.choice != null)
				{
					position.x -= this.box.windowRect.x + this.box.Settings.boxPadding.x;
					position.y -= this.box.windowRect.y + this.box.Settings.boxPadding.y;
					for(int i=0; i<this.choice.Length; i++)
					{
						if((this.choice[i].Active || this.choice[i].dragInactive) && 
							(this.choice[i].isDragable || this.choice[i].isDoubleClick) && 
							this.choice[i].InButton(position, this.scroll.y))
						{
							if(this.choice[i].drag != null)
							{
								this.choice[i].drag.BoxOrigin = this.box;
							}
							return this.choice[i];
						}
					}
				}
			}
			return null;
		}
		
		public override bool CheckDrop(DragInfo drag, Vector2 position)
		{
			if(base.CheckDrop(drag, position))
			{
				if(this.controlInterface is IChoiceDrop)
				{
					if(this.choice != null)
					{
						position.x -= this.box.windowRect.x + this.box.Settings.boxPadding.x;
						position.y -= this.box.windowRect.y + this.box.Settings.boxPadding.y;
						
						for(int i=0; i<this.choice.Length; i++)
						{
							if(this.choice[i].Active && 
								this.choice[i].InButton(position, this.scroll.y))
							{
								((IChoiceDrop)this.controlInterface).ChoiceDropped(i, this.box, drag);
								return true;
							}
						}
					}
					((IChoiceDrop)this.controlInterface).ChoiceDropped(-1, this.box, drag);
				}
				return true;
			}
			return false;
		}
		
		public override IContent GetTooltip(Vector2 position)
		{
			if(this.box != null && this.choice != null && !this.box.FadingOut)
			{
				position.x -= this.box.windowRect.x + this.box.Settings.boxPadding.x;
				position.y -= this.box.windowRect.y + this.box.Settings.boxPadding.y;
				for(int i=0; i<this.choice.Length; i++)
				{
					if(this.choice[i].isTooltip && this.choice[i].drag != null && 
						this.choice[i].InButton(position, this.scroll.y))
					{
						return this.choice[i].drag.Shortcut;
					}
				}
			}
			return null;
		}
		
		public override void MouseOverSelection(Vector2 position)
		{
			if(this.box != null && this.choice != null && 
				this.controlInterface != null && !this.box.FadingOut && 
				this.InBox(position))
			{
				position.x -= this.box.windowRect.x + this.box.Settings.boxPadding.x;
				position.y -= this.box.windowRect.y + this.box.Settings.boxPadding.y;
				for(int i=0; i<this.choice.Length; i++)
				{
					if(this.Selection != i && 
						this.choice[i].InButton(position, this.scroll.y))
					{
						this.box.Audio.PlayCursorMove();
						this.Selection = i;
					}
				}
			}
		}
		
		public override bool CheckClick(Vector2 position)
		{
			if(this.box != null && this.choice != null && 
				this.controlInterface != null && !this.box.FadingOut && 
				this.InBox(position))
			{
				position.x -= this.box.windowRect.x + this.box.Settings.boxPadding.x;
				position.y -= this.box.windowRect.y + this.box.Settings.boxPadding.y;
				
				for(int i=0; i<this.choice.Length; i++)
				{
					if(this.choice[i].buttonBounds.Contains(position) && 
						this.choice[i].CheckClick(position))
					{
						return true;
					}
				}
				return true;
			}
			return false;
		}
		
		
		/*
		============================================================================
		Tabs functions
		============================================================================
		*/
		public override void SetTabs(ChoiceContent[] tabs)
		{
			this.tabs = tabs;
		}
		
		
		/*
		============================================================================
		Init functions
		============================================================================
		*/
		public override void Init(GUIBox box)
		{
			if(this.newContent || this.content == null)
			{
				this.box = box;
				
				// remove old notifications
				if(this.statusInformation != null && this.choice != null)
				{
					for(int i=0; i<this.choice.Length; i++)
					{
						if(this.choice[i].combatant != null)
						{
							this.choice[i].combatant.UpdateHUD -= this.Recalculate;
						}
					}
					ORK.GUI.UpdateHUD -= this.Recalculate;
				}
				
				this.CalculateContent(this.box.bounds.width - (this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), false);
				
				this.UpdatePortrait();
				
				this.newContent = false;
			}
		}
		
		private void UpdatePortrait()
		{
			Portrait tmpPortrait = this.portrait;
			
			if(this.choice != null && 
				this.selection >= 0 && this.selection < this.choice.Length && 
				this.choice[this.selection].portrait != null && 
				this.choice[this.selection].portrait.image != null)
			{
				this.portrait = this.choice[this.selection].portrait;
			}
			else if(this.setPortrait != null && this.setPortrait.image != null)
			{
				this.portrait = this.setPortrait;
			}
			else
			{
				this.portrait = null;
			}
			
			if(this.portrait != null && this.portrait.image != null)
			{
				this.portrait.image.wrapMode = TextureWrapMode.Clamp;
				
				if(this.setPortraitPosition != null)
				{
					this.portraitPosition = this.setPortraitPosition;
				}
				else if(this.portrait.ownPortraitPosition)
				{
					this.portraitPosition = this.portrait.portraitPosition;
				}
				else if(this.box.Settings.ownPortraitPosition)
				{
					this.portraitPosition = this.box.Settings.portraitPosition;
				}
				else
				{
					this.portraitPosition = ORK.MenuSettings.portraitPosition;
				}
			}
			
			// new UI
			if(tmpPortrait != this.portrait)
			{
				this.CreatePortraitObject(this.portrait, this.portraitPosition);
			}
		}
		
		private void CalculateContent(float baseWidth, bool recalced)
		{
			Rect textBounds = new Rect(0, 0, 
				(baseWidth - (this.box.Settings.textColumnSpacing * (this.box.Settings.textColumns - 1))) / this.box.Settings.textColumns, 
				this.box.bounds.height - (this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w));
			
			// init tabs
			if(this.tabs != null && this.tabs.Length > 0)
			{
				Rect textBounds2 = new Rect(0, 0, 
					baseWidth - (this.box.Settings.tabsPadding.x + this.box.Settings.tabsPadding.z), 
					this.box.bounds.height - (this.box.Settings.tabsPadding.y + this.box.Settings.tabsPadding.w));
				
				// init content and info
				Vector2 biggest = Vector2.zero;
				for(int i=0; i<this.tabs.Length; i++)
				{
					this.tabs[i].InitContent(textBounds2, false, this.box.Settings.tabsButtonSettings, null);
					this.tabs[i].SetToContentSize(this.box.Settings.tabsButtonSettings.padding);
					
					if(biggest.x < this.tabs[i].buttonBounds.width)
					{
						biggest.x = this.tabs[i].buttonBounds.width;
					}
					if(biggest.y < this.tabs[i].buttonBounds.height)
					{
						biggest.y = this.tabs[i].buttonBounds.height;
					}
				}
				
				// calculate positions
				float tabsWidth = 0;
				for(int i=0; i<this.tabs.Length; i++)
				{
					this.tabs[i].SetHeight(biggest.y);
					this.tabs[i].SetPosition(new Vector2(tabsWidth, 0));
					
					if(this.box.Settings.tabsSetWidth)
					{
						this.tabs[i].buttonBounds.width = this.box.Settings.tabsWidth;
					}
					else if(this.box.Settings.tabsAdjustWidth)
					{
						this.tabs[i].buttonBounds.width = biggest.x;
					}
					tabsWidth += this.tabs[i].buttonBounds.width + this.box.Settings.tabsSpacing;
				}
				
				this.tabsContentBounds = new Rect(this.box.Settings.tabsPadding.x, this.box.Settings.tabsPadding.y, tabsWidth, biggest.y);
				this.tabsBounds = new Rect(0, 0, tabsWidth, biggest.y);
				textBounds.height -= this.tabsContentBounds.height;
				
				if(textBounds2.width < this.tabsContentBounds.width)
				{
					this.tabsScrollButtons = true;
					if(this.tabsLeftArrow == null)
					{
						this.tabsLeftArrow = this.box.Settings.tabsLeftArrow[ORK.Game.Language].GetChoiceContent();
						this.tabsLeftArrow.InitContent(textBounds2, false, this.box.Settings.tabsButtonSettings, null);
						this.tabsLeftArrow.SetToContentSize(this.box.Settings.tabsButtonSettings.padding);
					}
					if(this.tabsRightArrow == null)
					{
						this.tabsRightArrow = this.box.Settings.tabsRightArrow[ORK.Game.Language].GetChoiceContent();
						this.tabsRightArrow.InitContent(textBounds2, false, this.box.Settings.tabsButtonSettings, null);
						this.tabsRightArrow.SetToContentSize(this.box.Settings.tabsButtonSettings.padding);
					}
					this.tabsContentBounds.width = textBounds2.width - (this.tabsLeftArrow.buttonBounds.width + this.tabsRightArrow.buttonBounds.width);
					
					if(ArrowButtonPosition.Left.Equals(this.box.Settings.tabsArrowPosition))
					{
						this.tabsContentBounds.x += this.tabsLeftArrow.buttonBounds.width + 
							this.tabsRightArrow.buttonBounds.width + this.box.Settings.tabsSpacing * 2;
						this.tabsLeftArrow.SetPosition(
							new Vector2(this.box.Settings.tabsPadding.x, 
								this.box.Settings.tabsPadding.y));
						this.tabsRightArrow.SetPosition(
							new Vector2(this.box.Settings.tabsPadding.x + this.tabsLeftArrow.buttonBounds.width + this.box.Settings.tabsSpacing, 
								this.box.Settings.tabsPadding.y));
					}
					else if(ArrowButtonPosition.LeftRight.Equals(this.box.Settings.tabsArrowPosition))
					{
						this.tabsContentBounds.x += this.tabsLeftArrow.buttonBounds.width + this.box.Settings.tabsSpacing;
						this.tabsLeftArrow.SetPosition(
							new Vector2(this.box.Settings.tabsPadding.x, 
								this.box.Settings.tabsPadding.y));
						this.tabsRightArrow.SetPosition(
							new Vector2(this.box.Settings.tabsPadding.x + this.tabsLeftArrow.buttonBounds.width + 
								this.tabsContentBounds.width + this.box.Settings.tabsSpacing, 
								this.box.Settings.tabsPadding.y));
					}
					else if(ArrowButtonPosition.Right.Equals(this.box.Settings.tabsArrowPosition))
					{
						this.tabsLeftArrow.SetPosition(
							new Vector2(this.box.Settings.tabsPadding.x + this.tabsContentBounds.width + this.box.Settings.tabsSpacing, 
								this.box.Settings.tabsPadding.y));
						this.tabsRightArrow.SetPosition(
							new Vector2(this.box.Settings.tabsPadding.x + this.tabsLeftArrow.buttonBounds.width + 
								this.tabsContentBounds.width + this.box.Settings.tabsSpacing * 2, 
								this.box.Settings.tabsPadding.y));
					}
					
					// correct scroll offset
					for(int i=0; i<this.tabsScrollOffset; i++)
					{
						this.tabsBounds.x -= this.tabs[i].buttonBounds.width;
					}
				}
				else
				{
					this.tabsScrollOffset = 0;
					this.tabsScrollButtons = false;
				}
				
				if(this.tabsSelection < 0)
				{
					this.tabsSelection = 0;
				}
				else if(this.tabsSelection >= this.tabs.Length)
				{
					this.tabsSelection = this.tabs.Length - 1;
				}
			}
			
			
			// content
			TextHelper.ReplaceSpecials(ref this.text);
			
			this.content = new MultiContent(this.text, null, null, 
				textBounds, this.box.Settings.lineSpacing, 
				this.box.Settings.alignment, this.box.Settings.vAlignment, 
				this.box.Settings.heightAdjustment, 
				(this.choice == null || this.choice.Length == 0) && this.box.Settings.oneline, 
				this.box.Settings.textFormat, this.box.Settings.textColumns, this.box.Settings.textColumnSpacing);
			
			this.typingIndex = 0;
			this.isTyping = this.box.Settings.useTextTyping && ORK.Game.TextSpeed > 0;
			if(this.isTyping)
			{
				this.typingInterval = this.box.Settings.typingInterval / ORK.Game.TextSpeed;
				this.typingAudioInterval = 0;
			}
			
			float contentHeight = this.content.size.y;
			textBounds.width = baseWidth;
			
			if(this.choice != null && this.choice.Length > 0)
			{
				if(this.content.size.y > 0)
				{
					textBounds.y = this.content.size.y + this.box.Settings.lineSpacing;
				}
				
				// init choice title for x pos calculation
				for(int i=0; i<this.choice.Length; i++)
				{
					this.choice[i].InitTitle(textBounds, 
						this.box.Settings.buttonSettings, this.box.Settings.choiceTitlePadding, 
						this.box.Settings.choiceSetTitleWidth ? this.box.Settings.choiceTitleWidth : -1, 
						this.box.Settings.alignmentTitle, this.box.Settings.vAlignmentTitle);
				}
				
				// choice start x pos after title
				float choiceStartX = 0;
				for(int i=0; i<this.choice.Length; i++)
				{
					if(this.choice[i].Title != null)
					{
						if(choiceStartX < this.choice[i].titleSize.x)
						{
							choiceStartX = this.choice[i].titleSize.x;
						}
					}
				}
				if(choiceStartX > 0)
				{
					// update title widths for good layout
					for(int i=0; i<this.choice.Length; i++)
					{
						this.choice[i].titleBounds.width = choiceStartX;
					}
					// add spacing
					choiceStartX += this.box.Settings.choiceSpacing.x;
				}
				
				// calculate columns
				if(ColumnFill.Vertical.Equals(this.box.Settings.columnFill))
				{
					this.maxCol = (int)Mathf.Ceil(((float)choice.Length) / 
						((float)this.box.Settings.choiceColumns));
					this.colCount = this.box.Settings.choiceColumns;
				}
				else
				{
					this.maxCol = this.box.Settings.choiceColumns;
					this.colCount = (int)Mathf.Ceil(((float)choice.Length) / 
						((float)this.box.Settings.choiceColumns));
				}
				
				int columnCount = this.box.Settings.choiceColumns;
				if(this.choice.Length == 1)
				{
					columnCount = 1;
				}
				if(this.box.Settings.choiceDefineWidth)
				{
					textBounds.width = this.box.Settings.choiceWidth;
				}
				else
				{
					textBounds.width = ((textBounds.width - 
						(this.box.Settings.choiceSpacing.x * (columnCount - 1))) / columnCount) - choiceStartX;
				}
				
				// init content and info
				float highest = 0;
				for(int i=0; i<this.choice.Length; i++)
				{
					this.choice[i].InitContent(textBounds, this.box.Settings.selectFirst, 
						this.box.Settings.buttonSettings, this.statusInformation);
					if(highest < this.choice[i].buttonBounds.height)
					{
						highest = this.choice[i].buttonBounds.height;
					}
				}
				
				// calculate positions
				int counter = 0;
				int col = 0;
				float lastHeight = 0;
				float storedYPos = textBounds.y;
				Vector2 newPos = new Vector2(textBounds.x, textBounds.y);
				
				for(int i=0; i<this.choice.Length; i++)
				{
					if(this.box.Settings.cAdjustHeight)
					{
						this.choice[i].SetHeight(highest);
					}
					
					float cOff = this.box.Settings.choiceDefineWidth ? this.box.Settings.choiceOffsetX : 0;
					
					if(counter >= this.maxCol)
					{
						col++;
						counter = 0;
						if(ColumnFill.Vertical.Equals(this.box.Settings.columnFill))
						{
							newPos.y = storedYPos;
							newPos.x = col * (textBounds.width + this.box.Settings.choiceSpacing.x + choiceStartX);
							lastHeight = 0;
						}
						else
						{
							newPos.x = choiceStartX + col * cOff;
							newPos.y += lastHeight + this.box.Settings.choiceSpacing.y;
							lastHeight = 0;
						}
					}
					else if(i > 0)
					{
						if(ColumnFill.Vertical.Equals(this.box.Settings.columnFill))
						{
							newPos.x += cOff;
							newPos.y += lastHeight + this.box.Settings.choiceSpacing.y;
							lastHeight = 0;
						}
						else
						{
							newPos.x += textBounds.width + this.box.Settings.choiceSpacing.x + choiceStartX;
						}
					}
					
					this.choice[i].SetPosition(newPos);
					
					if(lastHeight < this.choice[i].buttonBounds.height)
					{
						lastHeight = this.choice[i].buttonBounds.height;
					}
					
					counter++;
					
					if(contentHeight < this.choice[i].buttonBounds.y + this.choice[i].buttonBounds.height)
					{
						contentHeight = this.choice[i].buttonBounds.y + this.choice[i].buttonBounds.height;
					}
					
					// register change notification
					if(this.statusInformation != null && this.choice[i].combatant != null)
					{
						this.choice[i].combatant.UpdateHUD += this.Recalculate;
					}
				}
				if(this.statusInformation != null && this.choice != null)
				{
					ORK.GUI.UpdateHUD += this.Recalculate;
				}
				
				if(this.selection < 0)
				{
					this.selection = 0;
				}
				else if(this.selection >= this.choice.Length)
				{
					this.selection = this.choice.Length - 1;
				}
				this.UpdateSelectedPosition(true);
			}
			
			if(BoxHeightAdjustment.Auto.Equals(this.box.Settings.heightAdjustment) && 
				!this.box.forceSize)
			{
				this.box.bounds.height = contentHeight + this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w;
			}
			else if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				this.scrollRect = new Rect(this.box.Settings.boxPadding.x, this.box.Settings.boxPadding.y, 
					baseWidth, contentHeight);
			}
			
			this.contentBounds = new Rect(this.box.Settings.boxPadding.x, this.box.Settings.boxPadding.y, 
				this.box.bounds.width - (this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), 
				this.box.bounds.height - (this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w));
			
			if(!recalced && contentHeight > this.contentBounds.height && 
				BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				float scrollbarWidth = 0;
				if(ORK.GUI.IsNewUI)
				{
					if(this.box.Skins.scrollbarPrefab != null)
					{
						RectTransform rect = this.box.Skins.scrollbarPrefab.GetComponent<RectTransform>();
						if(rect != null)
						{
							scrollbarWidth = rect.sizeDelta.x;
						}
					}
				}
				else
				{
					scrollbarWidth = GUI.skin.verticalScrollbar.fixedWidth;
				}
				this.CalculateContent(baseWidth - (scrollbarWidth + this.box.Settings.scrollPadding), true);
			}
			else
			{
				if(this.choice == null || this.choice.Length == 0 || 
					this.controlInterface is CombatantMenuPart)
				{
					this.CalculateButtons();
				}
				
				if(TabsPosition.Bottom.Equals(this.box.Settings.tabsPosition))
				{
					this.tabsContentBounds.y = this.box.bounds.height - this.tabsContentBounds.height - this.box.Settings.tabsPadding.w;
					if(this.tabsScrollButtons)
					{
						this.tabsLeftArrow.buttonBounds.y = this.tabsContentBounds.y;
						this.tabsRightArrow.buttonBounds.y = this.tabsContentBounds.y;
					}
				}
			}
		}
		
		public override void CreateNewUI()
		{
			if(ORK.GUI.IsNewUI && 
				this.box.gameObject != null)
			{
				GameObject parent = this.UpdatePanel();
				
				// create
				int index = 0;
				if(this.labelObject == null)
				{
					this.labelObject = new List<RectTransform>();
				}
				else
				{
					for(int i=0; i<this.labelObject.Count; i++)
					{
						if(this.labelObject[i] == null)
						{
							this.labelObject.RemoveAt(i--);
						}
						else
						{
							this.labelObject[i].SetParent(null, false);
						}
					}
				}
				
				if(this.oldChoice != null)
				{
					for(int i=0; i<this.oldChoice.Count; i++)
					{
						if(this.oldChoice[i].gameObject != null)
						{
							GameObject.Destroy(this.oldChoice[i].gameObject);
						}
					}
					this.oldChoice = null;
				}
				
				// text
				if(this.isTyping && this.box.Settings.useTextTyping)
				{
					for(int i=0; i<this.content.label.Count; i++)
					{
						this.content.label[i].CreateObject(parent, this.labelObject, ref index);
						this.content.label[i].NewUITyping(0, false);
					}
				}
				else
				{
					for(int i=0; i<this.content.label.Count; i++)
					{
						this.content.label[i].CreateObject(parent, this.labelObject, ref index);
					}
				}
				
				// choices
				if(this.choice != null && this.choice.Length > 0)
				{
					for(int i=0; i<this.choice.Length; i++)
					{
						this.choice[i].CreateObject("Choice", this.box, i, 
							this.box.Skins.buttonPrefab, 
							parent, this.labelObject, ref index, this.ChoiceClicked);
					}
				}
				
				// tabs
				this.CreateTabsObjects(this.tabsContentBounds, this.tabsBounds, this.tabs, 
					this.tabsScrollButtons, this.tabsLeftArrow, this.tabsRightArrow, 
					this.tabsScrollOffset, this.labelObject, ref index, this.TabClicked);
				
				// update labels
				for(int i=0; i<this.labelObject.Count; i++)
				{
					// remove empty
					if(this.labelObject[i] == null)
					{
						this.labelObject.RemoveAt(i--);
					}
					// remove exceeding labels
					else if(i >= index)
					{
						GameObject.Destroy(this.labelObject[i].gameObject);
						this.labelObject.RemoveAt(i--);
					}
				}
				
				// choice icon
				if(this.choice != null && this.choice.Length > 0 && 
					this.box.ChoiceIcon.icon != null)
				{
					if(this.choiceIconObject == null)
					{
						this.choiceIconObject = this.box.ChoiceIcon.CreateObject(this.box.gameObject);
						this.box.ChoiceIcon.SetObjectPosition(this.choiceIconObject, 
							this.iconFadePos, this.choice[this.selection].buttonBounds, 
							this.contentBounds, this.scroll.y, this.box.Focused);
					}
				}
				else if(this.choiceIconObject != null)
				{
					GameObject.Destroy(this.choiceIconObject.gameObject);
				}
				
				// portrait
				this.CreatePortraitObject(this.portrait, this.portraitPosition);
			}
		}
		
		public void ChoiceClicked(int index)
		{
			if(this.choice != null && !this.box.disableChoice && 
				index >= 0 && index < this.choice.Length)
			{
				if(!this.choice[index].isDoubleClick && 
					(!this.choice[index].selectFirst || 
						this.selection == index))
				{
					this.Selection = index;
					this.OkPressed();
				}
				else
				{
					this.Selection = index;
				}
			}
		}
		
		public void TabClicked(int index)
		{
			if(this.tabs != null && !this.box.disableChoice)
			{
				if(index >= 0 && index < this.tabs.Length)
				{
					if(this.tabs[index].Active)
					{
						this.box.Audio.PlayAccept();
						if(this.tabsSelection != index)
						{
							this.tabsSelection = index;
							if(this.controlInterface is ITabChoice)
							{
								((ITabChoice)this.controlInterface).TabChanged(this.tabsSelection, this.box);
							}
						}
					}
					else
					{
						this.box.Audio.PlayFail();
					}
				}
				else if(this.tabsScrollButtons)
				{
					if(index == -1)
					{
						this.box.Audio.PlayCursorMove();
						this.tabsScrollOffset--;
						
						if(this.tabsRect != null)
						{
							this.tabsRect.anchoredPosition += new Vector2(
								this.tabs[this.tabsScrollOffset].buttonBounds.width, 0);
						}
					}
					else if(index == -2)
					{
						this.box.Audio.PlayCursorMove();
						
						if(this.tabsRect != null)
						{
							this.tabsRect.anchoredPosition -= new Vector2(
								this.tabs[this.tabsScrollOffset].buttonBounds.width, 0);
						}
						this.tabsScrollOffset++;
					}
					
					if(this.tabsLeftArrow != null)
					{
						this.tabsLeftArrow.Active = this.tabsScrollOffset > 0;
					}
					if(this.tabsRightArrow != null)
					{
						this.tabsRightArrow.Active = this.tabsScrollOffset < this.tabs.Length - 1;
					}
				}
			}
		}
		
		public void Recalculate()
		{
			this.markUpdate = true;
		}
		
		
		/*
		============================================================================
		Show GUI functions
		============================================================================
		*/
		public override void ShowBefore()
		{
			if(this.box != null && this.portrait != null && this.portrait.image != null && 
				this.portraitPosition != null && PortraitBoxPosition.Behind.Equals(this.portraitPosition.boxPosition))
			{
				this.portraitPosition.Show(this.portrait, this.box.windowRect);
			}
		}
		
		public override void ShowAfter()
		{
			if(this.box != null && this.portrait != null && this.portrait.image != null && 
				this.portraitPosition != null && PortraitBoxPosition.InFront.Equals(this.portraitPosition.boxPosition))
			{
				this.portraitPosition.Show(this.portrait, this.box.windowRect);
			}
		}

		public override void ShowWindow()
		{
			if(this.box != null)
			{
				bool fireOk = false;
				
				if(this.box.doFlash)
				{
					GUI.color = this.box.flashColor;
				}
				else
				{
					GUI.color = this.box.color;
				}
				
				if(this.box.controlable && this.box.focusable && !this.box.Focused)
				{
					this.box.InactiveColor.SetColors();
				}
				
				// within box potrait
				if(this.portrait != null && this.portrait.image != null && 
					this.portraitPosition != null && PortraitBoxPosition.Within.Equals(this.portraitPosition.boxPosition))
				{
					this.portraitPosition.Show(this.portrait, this.box.windowRect);
				}
				
				GUIStyle textStyle = new GUIStyle(GUI.skin.label);
				textStyle.wordWrap = false;
				
				if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
				{
					GUI.skin.horizontalScrollbar = GUIStyle.none;
					this.scroll = GUI.BeginScrollView(this.contentBounds, this.scroll, this.scrollRect);
					GUI.BeginGroup(this.scrollRect);
				}
				else
				{
					GUI.BeginGroup(this.contentBounds);
				}
				
				
				// content typing
				if(this.isTyping)
				{
					this.content.DoTyping(ref this.isTyping, ref this.typingIndex, 
						ref this.typingInterval, ref this.typingAudioInterval, textStyle);
				}
				// no typing
				else
				{
					for(int i=0; i<this.content.label.Count; i++)
					{
						this.content.label[i].Show(textStyle);
					}
				}
				
				if(this.choice == null || this.choice.Length == 0)
				{
					GUI.EndGroup();
					if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
					{
						GUI.EndScrollView();
					}
				}
				// choices
				else
				{
					int lastSelection = this.selection;
					
					textStyle = new GUIStyle(GUI.skin.label);
					textStyle.wordWrap = false;
					
					for(int i=0; i<this.choice.Length; i++)
					{
						// title
						if(this.choice[i].titleLabel != null)
						{
							GUI.BeginGroup(this.choice[i].titleBounds);
							
							if(!this.box.Settings.buttonSettings.alignIcons && this.choice[i].Title.image != null)
							{
								textStyle.alignment = TextAnchor.MiddleLeft;
								GUI.Label(this.choice[i].tImgBounds, new GUIContent(this.choice[i].Title.image), textStyle);
								textStyle.alignment = TextAnchor.UpperLeft;
							}
							if(this.choice[i].titleLabel.label.Count > 0)
							{
								for(int j=0; j<this.choice[i].titleLabel.label.Count; j++)
								{
									this.choice[i].titleLabel.label[j].Show(textStyle);
								}
							}
							
							GUI.EndGroup();
						}
						
						// button and alpha
						if(!this.choice[i].Active && 
							GUI.color.a > this.box.Settings.choiceInactiveAlpha)
						{
							Color c = GUI.color;
							c.a = this.box.Settings.choiceInactiveAlpha;
							GUI.color = c;
						}
						
						// selected skin
						if(!this.box.disableChoice && this.selection == i && 
							this.box.Skins.selectSkin && this.choice[i].isButton)
						{
							GUI.skin = this.box.Skins.selectSkin;
						}
						
						if(this.choice[i].isButton)
						{
							if(this.box.Button(this.choice[i].buttonBounds, 
									this.box.Settings.buttonSettings.showButton, 
									i, i == this.choice.Length - 1) && 
								!this.box.disableChoice && 
								(this.box.inPause || !ORK.Game.Paused))
							{
								if(!this.choice[i].isDoubleClick && 
									(!this.choice[i].selectFirst || lastSelection == i))
								{
									this.Selection = i;
									fireOk = true;
								}
								else
								{
									this.Selection = i;
								}
							}
						}
						
						GUI.BeginGroup(this.choice[i].buttonBounds);
						
						if(this.choice[i].statusContent != null)
						{
							for(int j=0; j<this.choice[i].statusContent.Count; j++)
							{
								this.box.SetGUIColor(this.choice[i].statusContent[j].setting.noFlash);
								if(!this.choice[i].Active && 
									GUI.color.a > this.box.Settings.choiceInactiveAlpha)
								{
									Color c = GUI.color;
									c.a = this.box.Settings.choiceInactiveAlpha;
									GUI.color = c;
								}
								this.choice[i].statusContent[j].Show(textStyle);
								this.box.SetGUIColor(false);
								if(!this.choice[i].Active && 
									GUI.color.a > this.box.Settings.choiceInactiveAlpha)
								{
									Color c = GUI.color;
									c.a = this.box.Settings.choiceInactiveAlpha;
									GUI.color = c;
								}
							}
						}
						
						// content
						if(!this.box.Settings.buttonSettings.alignIcons && this.choice[i].Content.image != null)
						{
							textStyle.alignment = TextAnchor.MiddleLeft;
							GUI.Label(this.choice[i].cImgBounds, new GUIContent(this.choice[i].Content.image), textStyle);
							textStyle.alignment = TextAnchor.UpperLeft;
						}
						if(this.choice[i].contentLabel != null && this.choice[i].contentLabel.label.Count > 0)
						{
							for(int j=0; j<this.choice[i].contentLabel.label.Count; j++)
							{
								this.choice[i].contentLabel.label[j].Show(textStyle);
							}
						}
						
						// info
						if(this.choice[i].infoLabel != null && this.choice[i].infoLabel.label.Count > 0)
						{
							for(int j=0; j<this.choice[i].infoLabel.label.Count; j++)
							{
								this.choice[i].infoLabel.label[j].Show(textStyle);
							}
						}
						
						if(this.selection == i && this.box.Skins.skin)
						{
							GUI.skin = this.box.Skins.skin;
						}
						
						// reset alpha
						GUI.color = this.box.color;
						
						GUI.EndGroup();
					}
					
					GUI.EndGroup();
					if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
					{
						GUI.EndScrollView();
					}
				}
				
				
				// tabs
				if(this.tabs != null && this.tabs.Length > 0)
				{
					textStyle = new GUIStyle(GUI.skin.label);
					textStyle.wordWrap = false;
					
					GUI.BeginGroup(this.tabsContentBounds);
					
					int lastSelection = this.tabsSelection;
					
					GUISkin tmpSkin = GUI.skin;
					if(this.box.Skins.tabsSkin)
					{
						GUI.skin = this.box.Skins.tabsSkin;
					}
					
					GUI.BeginGroup(this.tabsBounds);
					for(int i=0; i<this.tabs.Length; i++)
					{
						// button and alpha
						if(!this.tabs[i].Active && 
							GUI.color.a > this.box.Settings.tabsInactiveAlpha)
						{
							Color c = GUI.color;
							c.a = this.box.Settings.tabsInactiveAlpha;
							GUI.color = c;
						}
						
						// selected skin
						GUISkin tmpSkin2 = GUI.skin;
						if(!this.box.disableChoice && this.tabsSelection == i && 
							this.tabs[i].isButton)
						{
							if(this.box.Skins.tabsSelectSkin)
							{
								GUI.skin = this.box.Skins.tabsSelectSkin;
							}
							else if(this.box.Skins.selectSkin)
							{
								GUI.skin = this.box.Skins.selectSkin;
							}
						}
						
						if(this.tabs[i].isButton)
						{
							if(this.box.TabButton(this.tabs[i].buttonBounds) && 
								!this.box.disableChoice && 
								(this.box.inPause || !ORK.Game.Paused))
							{
								if(this.tabs[i].Active)
								{
									this.box.Audio.PlayAccept();
									this.tabsSelection = i;
									if(this.controlInterface is ITabChoice)
									{
										((ITabChoice)this.controlInterface).TabChanged(this.tabsSelection, this.box);
									}
								}
								else
								{
									this.box.Audio.PlayFail();
								}
							}
						}
						
						GUI.BeginGroup(this.tabs[i].buttonBounds);
						
						// content
						if(!this.box.Settings.buttonSettings.alignIcons && this.tabs[i].Content.image != null)
						{
							textStyle.alignment = TextAnchor.MiddleLeft;
							GUI.Label(this.tabs[i].cImgBounds, new GUIContent(this.tabs[i].Content.image), textStyle);
							textStyle.alignment = TextAnchor.UpperLeft;
						}
						if(this.tabs[i].contentLabel != null && this.tabs[i].contentLabel.label.Count > 0)
						{
							for(int j=0; j<this.tabs[i].contentLabel.label.Count; j++)
							{
								this.tabs[i].contentLabel.label[j].Show(textStyle);
							}
						}
						
						// info
						if(this.tabs[i].infoLabel != null && this.tabs[i].infoLabel.label.Count > 0)
						{
							for(int j=0; j<this.tabs[i].infoLabel.label.Count; j++)
							{
								this.tabs[i].infoLabel.label[j].Show(textStyle);
							}
						}
						
						GUI.skin = tmpSkin2;
						
						// reset alpha
						GUI.color = this.box.color;
						
						GUI.EndGroup();
					}
					GUI.EndGroup();
					GUI.EndGroup();
					
					if(this.tabsScrollButtons)
					{
						this.tabsLeftArrow.Active = this.tabsScrollOffset > 0;
						this.tabsRightArrow.Active = this.tabsScrollOffset < this.tabs.Length - 1;
						
						// left arrow
						Color tmpCol = GUI.color;
						if(!this.tabsLeftArrow.Active && 
							GUI.color.a > this.box.Settings.tabsInactiveAlpha)
						{
							Color c = GUI.color;
							c.a = this.box.Settings.tabsInactiveAlpha;
							GUI.color = c;
						}
						if(this.tabsLeftArrow.isButton)
						{
							if(this.box.TabButton(this.tabsLeftArrow.buttonBounds) && 
								this.tabsLeftArrow.Active && !this.box.disableChoice && 
								(this.box.inPause || !ORK.Game.Paused))
							{
								this.box.Audio.PlayCursorMove();
								this.tabsScrollOffset--;
								this.tabsBounds.x += this.tabs[this.tabsScrollOffset].buttonBounds.width;
							}
						}
						GUI.BeginGroup(this.tabsLeftArrow.buttonBounds);
						// content
						if(!this.box.Settings.buttonSettings.alignIcons && this.tabsLeftArrow.Content.image != null)
						{
							textStyle.alignment = TextAnchor.MiddleLeft;
							GUI.Label(this.tabsLeftArrow.cImgBounds, new GUIContent(this.tabsLeftArrow.Content.image), textStyle);
							textStyle.alignment = TextAnchor.UpperLeft;
						}
						if(this.tabsLeftArrow.contentLabel != null && this.tabsLeftArrow.contentLabel.label.Count > 0)
						{
							for(int j=0; j<this.tabsLeftArrow.contentLabel.label.Count; j++)
							{
								this.tabsLeftArrow.contentLabel.label[j].Show(textStyle);
							}
						}
						GUI.EndGroup();
						GUI.color = tmpCol;
						
						// right arrow
						if(!this.tabsRightArrow.Active && 
							GUI.color.a > this.box.Settings.tabsInactiveAlpha)
						{
							Color c = GUI.color;
							c.a = this.box.Settings.tabsInactiveAlpha;
							GUI.color = c;
						}
						if(this.tabsRightArrow.isButton)
						{
							if(this.box.TabButton(this.tabsRightArrow.buttonBounds) && 
								this.tabsRightArrow.Active && !this.box.disableChoice && 
								(this.box.inPause || !ORK.Game.Paused))
							{
								this.box.Audio.PlayCursorMove();
								this.tabsBounds.x -= this.tabs[this.tabsScrollOffset].buttonBounds.width;
								this.tabsScrollOffset++;
							}
						}
						GUI.BeginGroup(this.tabsRightArrow.buttonBounds);
						// content
						if(!this.box.Settings.buttonSettings.alignIcons && this.tabsRightArrow.Content.image != null)
						{
							textStyle.alignment = TextAnchor.MiddleLeft;
							GUI.Label(this.tabsRightArrow.cImgBounds, new GUIContent(this.tabsRightArrow.Content.image), textStyle);
							textStyle.alignment = TextAnchor.UpperLeft;
						}
						if(this.tabsRightArrow.contentLabel != null && this.tabsRightArrow.contentLabel.label.Count > 0)
						{
							for(int j=0; j<this.tabsRightArrow.contentLabel.label.Count; j++)
							{
								this.tabsRightArrow.contentLabel.label[j].Show(textStyle);
							}
						}
						GUI.EndGroup();
						GUI.color = tmpCol;
					}
					
					GUI.skin = tmpSkin;
				}
				
				if(fireOk)
				{
					this.OkPressed();
				}
			}
		}
		
		public override void ShowSelectionIcon()
		{
			if(this.box != null && !this.box.disableChoice && this.choice != null && 
				this.box.ChoiceIcon.icon != null && 
				(this.box.ChoiceIcon.showUnfocused || this.box.Focused) && 
				this.box.Controlable && 
				this.selection >= 0 && this.selection < this.choice.Length)
			{
				Rect selBounds = this.choice[this.selection].buttonBounds;
				selBounds.x += this.box.Settings.boxPadding.x;
				selBounds.y += this.box.Settings.boxPadding.y - this.scroll.y;
				
				if((selBounds.y >= this.contentBounds.y || 
						selBounds.y + selBounds.height >= this.contentBounds.y) && 
					(selBounds.y < this.contentBounds.y + this.contentBounds.height || 
						selBounds.y + selBounds.height < this.contentBounds.y + this.contentBounds.height))
				{
					selBounds.x += this.box.windowRect.x;
					selBounds.y += this.box.windowRect.y;
					this.DrawChoiceIcon(selBounds);
				}
			}
		}
	}
}
