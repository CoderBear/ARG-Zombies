
using System;

namespace ORKFramework
{
	public interface IChoiceDrop : IChoice
	{
		void ChoiceDropped(int index, GUIBox origin, DragInfo drag);
	}
}
