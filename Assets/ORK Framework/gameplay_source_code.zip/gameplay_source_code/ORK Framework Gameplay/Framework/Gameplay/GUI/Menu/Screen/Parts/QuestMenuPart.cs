
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Menu.Parts
{
	[ORKEditorHelp("Quest", "Displays quests added to the player's quest list.\n" +
			"The quests can be separated by quest type.", "")]
	public class QuestMenuPart : BaseMenuPart, IChoice, ITabChoice
	{
		// type settings
		// available types
		[ORKEditorHelp("All Quest Types", "All quest types will be available.\n" +
			"If disabled, you have to select the quest types that will be available.", "")]
		[ORKEditorInfo("Available Quest Types", "Define what quest types will be displayed in this menu screen.", "")]
		public bool allTypes = true;
		
		public TypeSorter typeSorter = new TypeSorter();
		
		[ORKEditorHelp("Quest Type", "Select the quest type that will be available.", "")]
		[ORKEditorInfo(ORKDataType.QuestType, endFoldout=true, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Quest Type", "Adds a quest type that will be available.", "", 
			"Remove", "Removes this quest type.", "", noRemoveCount=1, isHorizontal=true)]
		[ORKEditorLayout("allTypes", false, endCheckGroup=true, autoInit=true, autoSize=1)]
		public int[] availableTypeID;
		
		
		// type box settings
		[ORKEditorHelp("Show Type Box", "A type selection box is displayed.\n" +
			"If disabled, no type selection box is displayed, " +
			"but you can change the type using the change type keys.", "")]
		[ORKEditorInfo("Type Box Settings", "Define the content and layout of the quest type box.", "")]
		public bool showTypeBox = true;
		
		[ORKEditorHelp("Show Empty Types", "Empty quest types (without any added quests) will be displayed (with inactive buttons).\n" +
			"If disabled, only the quest types with added quests will be displayed.", "")]
		public bool showEmptyTypes = false;
		
		[ORKEditorHelp("Merge Types", "Merge all quest types into a single display.\n" +
			"If disabled, only a single quest type will be displayed at a time - " +
			"you can use the type change keys to circle through available types.", "")]
		[ORKEditorLayout("showTypeBox", false, setDefault=true, defaultValue=false)]
		public bool mergeTypes = false;
		
		[ORKEditorHelp("Type Tabs", "Show the quest types as tabs in the quest box.", "")]
		[ORKEditorLayout("mergeTypes", false, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool typeTabs = false;
		
		[ORKEditorHelp("Display Type>Quest", "Select the box display mode (Type to Quest):\n" +
			"- Same: Types and quests use the same GUI box.\n" +
			"- One: Only one box will be displayed at a time. Types and quests use different GUI boxes.\n" +
			"- Multi: Multiple boxes are displayed at the same time. Types and quests use different GUI boxes.\n" +
			"- Sequence: Same as 'Multi', but the quests will only be displayed when a type was selected.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout(elseCheckGroup=true, setDefault=true, defaultValue=MenuBoxDisplay.Multi)]
		public MenuBoxDisplay display = MenuBoxDisplay.Multi;
		
		[ORKEditorHelp("Type Box", "Select the GUI box used to display the quest types.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		[ORKEditorLayout("display", MenuBoxDisplay.Same, elseCheckGroup=true, endCheckGroup=true)]
		public int guiBoxID = 0;
		
		// back button
		[ORKEditorHelp("Add Back", "A back button will be added to the quest type list.", "")]
		[ORKEditorInfo(separator=true)]
		public bool addBackType = false;
		
		[ORKEditorHelp("First Element", "The back button will be the first element in the quest type list.\n" +
			"If disabled, the back button will be the last element.", "")]
		[ORKEditorLayout("addBackType", true, endCheckGroup=true)]
		public bool backFirstType = false;
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used type GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		[ORKEditorLayout(setDefault=true, defaultValue=false)]
		public bool useTypeTitle = false;
		
		[ORKEditorHelp("Title", "The title of the box.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTypeTitle", true, endCheckGroup=true, endGroups=2, autoInit=true, autoLangSize=true)]
		public string[] typeTitle;
		
		[ORKEditorInfo("Type Content Layout", "Define the layout of the quest type buttons.", "", 
			endFoldout=true, endFolds=2)]
		[ORKEditorLayout(new string[] {"showTypeBox", "typeTabs"}, new System.Object[] {true, true}, 
			needed=Needed.One, endCheckGroup=true)]
		public ContentLayout typeContentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.None);
		
		
		// quest box settings
		[ORKEditorHelp("Display Quest>Info", "Select the box display mode (Quest to Quest Information):\n" +
			"- Same: Quests and quest infos use the same GUI box.\n" +
			"- One: Only one box will be displayed at a time. Quests and quest infos use different GUI boxes.\n" +
			"- Multi: Multiple boxes are displayed at the same time. Quests and quest infos use different GUI boxes.\n" +
			"- Sequence: Same as 'Multi', but the quest infos will only be displayed when a quest was selected.", "")]
		[ORKEditorInfo("Quest Box Settings", "Define the content and layout of the quest box.", "", 
			isEnumToolbar=true, toolbarWidth=75)]
		public MenuBoxDisplay displayText = MenuBoxDisplay.Multi;
		
		[ORKEditorHelp("Quest Box", "Select the GUI box used to display the quests.\n" +
			"If 'Same' box display is selected, this box will also display the quest types.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		[ORKEditorLayout("displayText", MenuBoxDisplay.Same, elseCheckGroup=true, endCheckGroup=true)]
		public int guiBoxID2 = 0;
		
		[ORKEditorHelp("Show Portraits", "Display the portrait of a selected quest (if available).", "")]
		public bool showQuestPortraits = false;
		
		[ORKEditorInfo(separator=true)]
		public ContentSorter contentSorter = new ContentSorter();
		
		// quest status
		[ORKEditorHelp("Add Inactive", "Inactive quests will be added to the list.", "")]
		[ORKEditorInfo(separator=true)]
		public bool addInactive = true;
		
		[ORKEditorHelp("Add Active", "Active quests will be added to the list.", "")]
		public bool addActive = true;
		
		[ORKEditorHelp("Add Finished", "Finished quests will be added to the list.", "")]
		public bool addFinished = true;
		
		[ORKEditorHelp("Add Failed", "Failed quests will be added to the list.", "")]
		public bool addFailed = true;
		
		// back button
		[ORKEditorHelp("Add Back", "A back button will be added to the quest list.", "")]
		[ORKEditorInfo(separator=true)]
		public bool addBack = false;
		
		[ORKEditorHelp("First Element", "The back button will be the first element in the quest list.\n" +
			"If disabled, the back button will be the last element.", "")]
		[ORKEditorLayout("addBack", true, endCheckGroup=true)]
		public bool backFirst = false;
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used quest GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useTitle = false;
		
		[ORKEditorHelp("Title", "The title of the quest box.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {
			"%n = type name (only if 'Merge Types' isn't selected)"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitle", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] title;
		
		// layout
		[ORKEditorInfo("Quest Content Layout", "Define the layout of the quest buttons.", "", 
			endFoldout=true, endFolds=2)]
		public ContentLayout contentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.None);
		
		
		// info box settings
		[ORKEditorHelp("Info Box", "Select the GUI box used to display the a selected quest's information.\n" +
			"If 'Same' box display is selected, this box will also display the quests.", "")]
		[ORKEditorInfo("Info Box Settings", "Define the content and layout of the quest info box.", "", 
			isPopup=true, popupType=ORKDataType.GUIBox)]
		public int guiBoxID3 = 0;
		
		[ORKEditorHelp("Show Portrait", "Display the portrait of the quest (if available).", "")]
		public bool showInfoPortrait = false;
		
		// activation choice
		[ORKEditorHelp("Use Activation Choice", "Use a choice to activate/inactivate (or leave) the quest.\n" +
			"If disabled, the quest can't be activated/inactivated in this menu screen.", "")]
		[ORKEditorInfo(separator=true, labelText="Activation Choice Settings")]
		public bool useChoice = false;
		
		[ORKEditorHelp("Add Back", "A back button will be added to the choice.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("useChoice", true)]
		public bool addBackText = false;
		
		[ORKEditorHelp("First Element", "The back button will be the first element in the choice.\n" +
			"If disabled, the back button will be the last element.", "")]
		[ORKEditorLayout("addBackText", true, endCheckGroup=true)]
		public bool backFirstText = false;
		
		[ORKEditorInfo("Info Content Layout", "Define the layout of the info box buttons.", "", 
			endFoldout=true)]
		public ContentLayout textContentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.None);
		
		// activate button
		[ORKEditorInfo("Activate Button", "Define the name, description and icon of the button used to activate a quest.", "", 
			endFoldout=true)]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		[ORKEditorLayout(autoInit=true, autoLangSize=true)]
		public LanguageInfo[] activateButton;
		
		// inactivate button
		[ORKEditorInfo("Inactivate Button", "Define the name, description and icon of the button used to inactivate a quest.", "", 
			endFoldout=true, endFolds=2)]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public LanguageInfo[] inactivateButton;
		
		
		// switch type keys
		[ORKEditorHelp("Use Change Keys", "The quest type can be changed by input keys.", "")]
		[ORKEditorInfo("Type Change Keys", "The quest type can be changed by input keys.", "")]
		[ORKEditorLayout("mergeTypes", false, setDefault=true, defaultValue=false)]
		public bool useTypeKeys = false;
		
		[ORKEditorHelp("Next Type", "Select the key used to select the next quest type.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("useTypeKeys", true)]
		public int nextTypeKey = 0;
		
		[ORKEditorHelp("Previous Type", "Select the key used to select the previous quest type.", "")]
		[ORKEditorInfo(ORKDataType.InputKey, endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public int prevTypeKey = 0;
		
		
		// layout
		[ORKEditorHelp("Own Layout", "This quest menu overrides the default quest layout setting " +
			"(defined in the game settings) and the quest's individual layouts.", "")]
		[ORKEditorInfo("Quest Layout", "A quest menu can override the default quest layout setting (found in the game settings) " +
			"and a quest's individual layout.", "")]
		public bool ownLayout = false;
		
		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("ownLayout", true, endCheckGroup=true, autoInit=true)]
		public QuestLayout layout;
		
		
		// ingame
		private GUIBox box;
		
		private GUIBox box2;
		
		private GUIBox box3;
		
		private int tmpTypeID = 0;
		
		private int current = 0;
		
		private int current2 = 0;
		
		private int current3 = 0;
		
		private bool exitFlag = false;
		
		private int nextBox = 0;
		
		
		// quest types
		private ChoiceContent[] typeChoice;
		
		private int[] typeAction;
		
		private List<int> questTypes;
		
		
		// quests
		private ChoiceContent[] questChoice;
		
		private List<Quest> quests;
		
		
		// quest info
		private string infoTitle = "";
		
		private string infoContent = "";
		
		private Portrait infoPortrait;
		
		private ChoiceContent[] infoChoice;
		
		private int[] infoAction;
		
		public QuestMenuPart()
		{
			
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return this.box3 == origin;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return false;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return this.box3 == origin && this.quests != null && 
				this.current2 >= 0 && this.current2 < this.quests.Count && 
				this.quests[this.current2] != null;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return false;
		}
		
		public override bool Controlable
		{
			get{ return this.IsOpened;}
		}
		
		
		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public override bool IsOpened
		{
			get
			{
				return (this.box == null || this.box.FadedIn) && 
					(this.box2 == null || this.box2.FadedIn) && 
						(this.box3 == null || this.box3.FadedIn);
			}
		}
		
		public override bool IsClosed
		{
			get{ return this.box == null && this.box2 == null && this.box3 == null;}
		}
		
		public bool Tick(GUIBox origin)
		{
			if(this.useTypeKeys)
			{
				if(ORK.InputKeys.Get(this.nextTypeKey).GetButton())
				{
					this.ChangeTypeKey(1, origin);
					return true;
				}
				else if(ORK.InputKeys.Get(this.prevTypeKey).GetButton())
				{
					this.ChangeTypeKey(-1, origin);
					return true;
				}
				
			}
			return false;
		}
		
		private void ChangeTypeKey(int change, GUIBox origin)
		{
			origin.Audio.PlayCursorMove();
			if(this.showTypeBox)
			{
				int index = this.current + change;
				if(index < 0)
				{
					index = this.typeChoice.Length - 1;
				}
				else if(index >= this.typeChoice.Length)
				{
					index = 0;
				}
				
				if(this.box != null)
				{
					this.box.Content.Selection = index;
				}
				if(this.box2 == origin)
				{
					this.ShowQuests();
				}
			}
			else if(this.box2 == origin)
			{
				this.CreateTypeList();
				
				int index = 0;
				for(int i=0; i<this.questTypes.Count; i++)
				{
					if(this.questTypes[i] == this.tmpTypeID)
					{
						index = i;
						break;
					}
				}
				index += change;
				if(index < 0)
				{
					index = this.questTypes.Count - 1;
				}
				else if(index >= this.questTypes.Count)
				{
					index = 0;
				}
				this.tmpTypeID = this.questTypes[index];
				this.ShowQuests();
			}
		}
		
		
		/*
		============================================================================
		Choice creation functions
		============================================================================
		*/
		private void CreateTypeList()
		{
			if(this.allTypes)
			{
				if(this.showEmptyTypes)
				{
					this.questTypes = new List<int>();
					for(int i=0; i<ORK.QuestTypes.Count; i++)
					{
						this.questTypes.Add(i);
					}
				}
				else
				{
					this.questTypes = ORK.Game.Quests.GetTypes(
						this.addInactive, this.addActive, this.addFinished, this.addFailed);
				}
			}
			else
			{
				if(this.showEmptyTypes)
				{
					this.questTypes = new List<int>(this.availableTypeID);
				}
				else
				{
					this.questTypes = new List<int>();
					for(int i=0; i<this.availableTypeID.Length; i++)
					{
						if(ORK.Game.Quests.HasType(this.availableTypeID[i], 
							this.addInactive, this.addActive, this.addFinished, this.addFailed))
						{
							this.questTypes.Add(this.availableTypeID[i]);
						}
					}
				}
			}
			this.typeSorter.Sort(ref this.questTypes, ORKDataType.QuestType);
		}
		
		private void CreateTypeChoices()
		{
			this.typeChoice = null;
			this.typeAction = null;
			
			if(this.screen.Combatant != null)
			{
				this.CreateTypeList();
				
				List<ChoiceContent> cc = new List<ChoiceContent>();
				List<int> ca = new List<int>();
				
				// back first
				if(this.addBackType && this.backFirstType)
				{
					cc.Add(this.typeContentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
					ca.Add(-1);
				}
				
				// types
				for(int i=0; i<this.questTypes.Count; i++)
				{
					ChoiceContent content = this.typeContentLayout.GetChoiceContent(ORK.QuestTypes.Get(this.questTypes[i]));
					if(this.showEmptyTypes)
					{
						content.Active = ORK.Game.Quests.HasType(this.questTypes[i], 
							this.addInactive, this.addActive, this.addFinished, this.addFailed);
					}
					cc.Add(content);
					ca.Add(this.questTypes[i]);
				}
				
				// back last
				if(this.addBackType && !this.backFirstType)
				{
					cc.Add(this.typeContentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
					ca.Add(-1);
				}
				
				this.typeChoice = cc.ToArray();
				this.typeAction = ca.ToArray();
			}
		}
		
		private void CreateQuestChoices()
		{
			this.quests = null;
			this.questChoice = null;
			
			if(this.screen.Combatant != null)
			{
				if(!this.showTypeBox && !this.mergeTypes && this.typeTabs)
				{
					this.CreateTypeChoices();
				}
				
				// quests
				if((this.showTypeBox || (!this.mergeTypes && this.typeTabs)) && 
					this.current >= 0 && this.current < this.typeAction.Length && 
					this.typeAction[this.current] != -1)
				{
					this.quests = ORK.Game.Quests.GetQuestsByType(this.typeAction[this.current], 
						this.addInactive, this.addActive, this.addFinished, this.addFailed);
				}
				else if(!this.showTypeBox && this.mergeTypes)
				{
					this.quests = ORK.Game.Quests.GetQuestsByType(-1, 
						this.addInactive, this.addActive, this.addFinished, this.addFailed);
				}
				else
				{
					this.quests = ORK.Game.Quests.GetQuestsByType(this.tmpTypeID, 
						this.addInactive, this.addActive, this.addFinished, this.addFailed);
				}
				
				if(this.quests != null)
				{
					this.contentSorter.Sort(ref this.quests);
					
					List<ChoiceContent> cc = new List<ChoiceContent>();
					
					// back first
					if(this.addBack && this.backFirst)
					{
						cc.Add(this.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
						this.quests.Insert(0, null);
					}
					
					// quests
					for(int i=0; i<this.quests.Count; i++)
					{
						if(this.quests[i] != null)
						{
							ChoiceContent content = this.contentLayout.GetChoiceContent(this.quests[i]);
							if(this.showQuestPortraits && this.quests[i].Setting.usePortrait)
							{
								content.portrait = this.quests[i].Setting.portrait;
							}
							cc.Add(content);
						}
					}
					
					// back last
					if(this.addBack && !this.backFirst)
					{
						cc.Add(this.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
						this.quests.Add(null);
					}
					
					this.questChoice = cc.ToArray();
				}
			}
		}
		
		private void CreateText()
		{
			this.infoTitle = "";
			this.infoContent = "";
			this.infoPortrait = null;
			this.infoChoice = null;
			this.infoAction = null;
			
			if(this.quests != null && 
				this.current2 >= 0 && this.current2 < this.quests.Count && 
				this.quests[this.current2] != null)
			{
				if(this.ownLayout && this.layout != null)
				{
					this.layout.GetContent(this.screen.Combatant, 
						this.quests[this.current2], ref this.infoTitle, ref this.infoContent);
				}
				else if(this.quests[this.current2].Setting.ownLayout && 
					this.quests[this.current2].Setting.layout != null)
				{
					this.quests[this.current2].Setting.layout.GetContent(this.screen.Combatant, 
						this.quests[this.current2], ref this.infoTitle, ref this.infoContent);
				}
				else
				{
					ORK.GameSettings.questLayout.GetContent(this.screen.Combatant, 
						this.quests[this.current2], ref this.infoTitle, ref this.infoContent);
				}
				
				if(this.showInfoPortrait && this.quests[this.current2].Setting.usePortrait)
				{
					this.infoPortrait = this.quests[this.current2].Setting.portrait;
				}
				
				if(this.useChoice)
				{
					List<ChoiceContent> cc = new List<ChoiceContent>();
					List<int> ca = new List<int>();
					
					// back first
					if(this.addBackText && this.backFirstText)
					{
						cc.Add(this.textContentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
						ca.Add(-1);
					}
					
					// create
					if(this.quests[this.current2].IsActive())
					{
						cc.Add(this.textContentLayout.GetChoiceContent(this.inactivateButton));
						ca.Add(0);
					}
					else if(this.quests[this.current2].IsInactive())
					{
						cc.Add(this.textContentLayout.GetChoiceContent(this.activateButton));
						ca.Add(1);
					}
					
					// back last
					if(this.addBackText && !this.backFirstText)
					{
						cc.Add(this.textContentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
						ca.Add(-1);
					}
					
					this.infoChoice = cc.ToArray();
					this.infoAction = ca.ToArray();
				}
			}
		}
		
		
		/*
		============================================================================
		Screen functions
		============================================================================
		*/
		public override bool ShowFirstDescription()
		{
			if(this.box != null && this.typeChoice != null && 
				this.current >= 0 && this.current < this.typeChoice.Length)
			{
				this.screen.ShowDescription(
					this.typeChoice[this.current].description, 
					this.typeChoice[this.current].Content.text, 
					this.typeAction[this.current] != -1 ? 
						ORK.QuestTypes.Get(this.typeAction[this.current]) : null);
				return true;
			}
			if(this.box2 != null && this.questChoice != null && 
				this.current2 >= 0 && this.current2 < this.questChoice.Length)
			{
				this.screen.ShowDescription(
					this.questChoice[this.current2].description, 
					this.questChoice[this.current2].Content.text, 
					this.quests[this.current2]);
				return true;
			}
			return false;
		}
		
		public override bool FocusFirst()
		{
			if(this.box != null)
			{
				this.box.SetFocus();
				return true;
			}
			else if(this.box2 != null)
			{
				this.box2.SetFocus();
				return true;
			}
			else if(this.box3 != null)
			{
				this.box3.SetFocus();
				return true;
			}
			return false;
		}
		
		public override bool IsFocused()
		{
			return (this.box != null && this.box.Focused) || 
				(this.box2 != null && this.box2.Focused) || 
				(this.box3 != null && this.box3.Focused);
		}
		
		public override void Refresh()
		{
			if(this.box != null)
			{
				this.ShowTypes();
			}
			if(this.box2 != null)
			{
				this.ShowQuests();
			}
			if(this.box3 != null)
			{
				this.ShowTexts();
			}
		}
		
		public override void Show(MenuScreen s)
		{
			this.nextBox = 0;
			this.screen = s;
			this.CreateTypeList();
			this.tmpTypeID = this.questTypes.Count > 0 ? this.questTypes[0] : 0;
			
			// quests and quest info share the same box
			if(MenuBoxDisplay.Same.Equals(this.displayText))
			{
				this.guiBoxID2 = this.guiBoxID3;
			}
			// types and quests share the same box
			if(this.showTypeBox && 
				MenuBoxDisplay.Same.Equals(this.display))
			{
				this.guiBoxID = this.guiBoxID2;
			}
			
			this.screen.Combatant.Inventory.Changed += this.InventoryChanged;
			
			this.Show();
		}
		
		public override void ChangeCombatant(Combatant old)
		{
			old.Inventory.Changed -= this.InventoryChanged;
			this.screen.Combatant.Inventory.Changed += this.InventoryChanged;
			this.Refresh();
		}
		
		public override void CloseImmediate()
		{
			this.screen.Combatant.Inventory.Changed -= this.InventoryChanged;
			if(this.box != null)
			{
				this.box.SetOutDone();
				this.box = null;
			}
			if(this.box2 != null)
			{
				this.box2.SetOutDone();
				this.box2 = null;
			}
			if(this.box3 != null)
			{
				this.box3.SetOutDone();
				this.box3 = null;
			}
		}
		
		public override void Close()
		{
			this.screen.Combatant.Inventory.Changed -= this.InventoryChanged;
			this.exitFlag = true;
			if(this.box != null && !this.box.FadingOut && !this.box.FadedOut)
			{
				this.box.InitOut();
			}
			if(this.box2 != null && !this.box2.FadingOut && !this.box2.FadedOut)
			{
				this.box2.InitOut();
			}
			if(this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
			{
				this.box3.InitOut();
			}
		}
		
		public void InventoryChanged(Inventory inventory, 
			ItemDropType type, int id, int level, int quantity)
		{
			this.Refresh();
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show()
		{
			if(!this.screen.RememberSelection)
			{
				this.current = 0;
				this.current2 = 0;
				this.current3 = 0;
			}
			
			// type choice and quests
			if(this.showTypeBox)
			{
				this.ShowTypes();
				
				if(MenuBoxDisplay.Multi.Equals(this.display))
				{
					this.ShowQuests();
				}
				
				this.box.SetFocus();
				this.SelectionChanged(this.current, this.box);
			}
			// only quests
			else
			{
				this.ShowQuests();
				this.box2.SetFocus();
				this.SelectionChanged(this.current2, this.box2);
			}
		}
		
		public void FocusGained(GUIBox origin)
		{
			if(this.box == origin && 
				!this.box.FadingOut && !this.box.FadedOut)
			{
				if(MenuBoxDisplay.Sequence.Equals(this.display))
				{
					if(this.box2 != null && !this.box2.FadingOut && !this.box2.FadedOut)
					{
						this.box2.InitOut();
					}
					if(this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
					{
						this.box3.InitOut();
					}
				}
				
				// info box
				if(MenuBoxDisplay.Same.Equals(this.displayText) && 
					this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
				{
					this.box2 = this.box3;
					this.box3 = null;
					this.ShowQuests();
				}
				else if(MenuBoxDisplay.Sequence.Equals(this.displayText) && 
					this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
				{
					this.box3.InitOut();
				}
				else if(MenuBoxDisplay.One.Equals(this.displayText) && 
					this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
				{
					this.nextBox = 4;
					this.box3.InitOut();
				}
				
				if(!this.box.FadingOut && this.typeChoice != null && 
					this.current >= 0 && this.current < this.typeChoice.Length)
				{
					this.screen.ShowDescription(
						this.typeChoice[this.current].description, 
						this.typeChoice[this.current].Content.text, 
						this.typeAction[this.current] != -1 ? 
							ORK.QuestTypes.Get(this.typeAction[this.current]) : null);
				}
			}
			else if(this.box2 == origin && 
				!this.box2.FadingOut && !this.box2.FadedOut)
			{
				if(MenuBoxDisplay.Sequence.Equals(this.displayText) && 
					this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
				{
					this.box3.InitOut();
				}
				
				if(!this.box2.FadingOut && this.questChoice != null && 
					this.current2 >= 0 && this.current2 < this.questChoice.Length)
				{
					this.screen.ShowDescription(
						this.questChoice[this.current2].description, 
						this.questChoice[this.current2].Content.text, 
						this.quests[this.current2]);
				}
			}
		}
		
		public void FocusLost(GUIBox origin)
		{
			
		}
		
		private void ShowTypes()
		{
			this.CreateTypeChoices();
			
			if(this.box == null || this.box.FadingOut || this.box.FadedOut)
			{
				this.box = ORK.GUIBoxes.Create(this.guiBoxID);
				this.box.inPause = this.screen.pauseGame;
				this.box.InitIn();
			}
			
			ValueHelper.Limit(ref this.current, 0, this.typeChoice.Length - 1);
			
			if(this.box.Content == null)
			{
				this.box.Content = new DialogueContent("", 
					this.useTypeTitle ? this.typeTitle[ORK.Game.Language] : "", 
					this.typeChoice, this, this.current);
			}
			else
			{
				((DialogueContent)this.box.Content).Update("", 
					this.useTypeTitle ? this.typeTitle[ORK.Game.Language] : "", 
					this.typeChoice, this.current, null, null);
			}
			if(this.box.Focused)
			{
				this.SelectionChanged(this.current, this.box);
			}
		}
		
		private void ShowQuests()
		{
			this.CreateQuestChoices();
			
			if(this.box2 == null || this.box2.FadingOut || this.box2.FadedOut)
			{
				this.box2 = ORK.GUIBoxes.Create(this.guiBoxID2);
				this.box2.inPause = this.screen.pauseGame;
				this.box2.InitIn();
			}
			
			if(this.questChoice == null)
			{
				this.current2 = 0;
			}
			else
			{
				ValueHelper.Limit(ref this.current2, 0, this.questChoice.Length - 1);
			}
			
			if(this.box2.Content == null)
			{
				this.box2.Content = new DialogueContent("", this.GetTitle(), 
					this.questChoice, this, this.current2);
			}
			else
			{
				((DialogueContent)this.box2.Content).Update("", this.GetTitle(), 
					this.questChoice, this.current2, null, null);
			}
			
			if(!this.showTypeBox && !this.mergeTypes && this.typeTabs)
			{
				this.box2.Content.SetTabs(this.typeChoice);
			}
			
			if(MenuBoxDisplay.Multi.Equals(this.displayText))
			{
				this.ShowTexts();
			}
			if(this.box2.Focused)
			{
				this.SelectionChanged(this.current2, this.box2);
			}
		}
		
		private void ShowTexts()
		{
			this.CreateText();
			
			if(this.box3 == null || this.box3.FadingOut || this.box3.FadedOut)
			{
				this.box3 = ORK.GUIBoxes.Create(this.guiBoxID3);
				this.box3.inPause = this.screen.pauseGame;
				this.box3.InitIn();
			}
			
			if(this.box3.Content == null)
			{
				this.box3.Content = new DialogueContent(this.infoContent, this.infoTitle, 
					this.infoChoice, this, this.current3, this.infoPortrait);
			}
			else
			{
				((DialogueContent)this.box3.Content).Update(this.infoContent, this.infoTitle, 
					this.infoChoice, this.current3, this.infoPortrait, null);
			}
		}
		
		private string GetTitle()
		{
			if(this.useTitle)
			{
				if(this.showTypeBox && this.typeChoice != null && 
					this.current >= 0 && this.current < this.typeChoice.Length && 
					this.typeAction[this.current] != -1)
				{
					return this.title[ORK.Game.Language].Replace("%n", this.typeChoice[this.current].Content.text);
				}
				else if(!this.showTypeBox && !this.mergeTypes)
				{
					return this.title[ORK.Game.Language].Replace("%n", ORK.QuestTypes.GetName(this.tmpTypeID));
				}
				else
				{
					return this.title[ORK.Game.Language].Replace("%n", "");
				}
			}
			return "";
		}
		
		public void Closed(GUIBox origin)
		{
			if(this.exitFlag)
			{
				if(this.box == origin)
				{
					this.box = null;
				}
				else if(this.box2 == origin)
				{
					this.box2 = null;
				}
				else if(this.box3 == origin)
				{
					this.box3 = null;
				}
				if(this.box == null && this.box2 == null && this.box3 == null)
				{
					this.exitFlag = false;
				}
			}
			else
			{
				// type switch to quests
				if(this.box == origin)
				{
					this.box = null;
					if(MenuBoxDisplay.One.Equals(this.display))
					{
						this.ShowQuests();
						this.box2.SetFocus();
						this.SelectionChanged(this.current2, this.box2);
					}
				}
				// quests
				else if(this.box2 == origin)
				{
					this.box2 = null;
					if(this.nextBox == 3 && MenuBoxDisplay.One.Equals(this.displayText))
					{
						this.ShowTexts();
					}
					else if(this.nextBox != 3 && this.showTypeBox && 
						MenuBoxDisplay.One.Equals(this.display))
					{
						this.ShowTypes();
					}
				}
				// quest info
				else if(this.box3 == origin)
				{
					this.box3 = null;
					if(this.nextBox == 2 && 
						MenuBoxDisplay.One.Equals(this.displayText))
					{
						this.ShowQuests();
						this.box2.SetFocus();
						this.SelectionChanged(this.current2, this.box2);
					}
					else if(this.nextBox == 4 && 
						MenuBoxDisplay.One.Equals(this.displayText))
					{
						this.ShowQuests();
						if(this.box != null)
						{
							this.box.SetFocus();
						}
					}
				}
			}
		}
		
		public override void CombatantChoiceClosed(bool canceled)
		{
			this.Refresh();
		}
		
		
		/*
		============================================================================
		Selection functions
		============================================================================
		*/
		public void ChoiceSelected(int index, GUIBox origin)
		{
			// type
			if(this.box == origin && this.typeChoice != null && 
				index >= 0 && index < this.typeChoice.Length)
			{
				if(this.current != index)
				{
					this.SelectionChanged(index, origin);
				}
				
				this.current = index;
				
				if(this.typeAction[this.current] == -1)
				{
					this.Cancel(this.box);
				}
				else
				{
					this.nextBox = 2;
					if(MenuBoxDisplay.Same.Equals(this.display))
					{
						this.box2 = this.box;
						this.box = null;
						this.ShowQuests();
						this.box2.SetFocus();
						this.SelectionChanged(this.current2, this.box2);
					}
					else if(MenuBoxDisplay.One.Equals(this.display))
					{
						this.box.InitOut();
					}
					else if(MenuBoxDisplay.Multi.Equals(this.display))
					{
						this.box2.SetFocus();
					}
					else if(MenuBoxDisplay.Sequence.Equals(this.display))
					{
						this.ShowQuests();
						this.box2.SetFocus();
						this.SelectionChanged(this.current2, this.box2);
					}
				}
			}
			// quests
			else if(this.box2 == origin && this.questChoice != null && 
				index >= 0 && index < this.questChoice.Length)
			{
				this.current2 = index;
				if(this.quests[this.current2] == null)
				{
					this.Cancel(this.box2);
				}
				else
				{
					this.nextBox = 3;
					if(MenuBoxDisplay.Same.Equals(this.displayText))
					{
						this.box3 = this.box2;
						this.box2 = null;
						this.ShowTexts();
					}
					else if(MenuBoxDisplay.One.Equals(this.displayText))
					{
						this.box2.InitOut();
					}
					else if(MenuBoxDisplay.Multi.Equals(this.displayText))
					{
						this.box3.SetFocus();
					}
					else if(MenuBoxDisplay.Sequence.Equals(this.displayText))
					{
						this.ShowTexts();
					}
				}
			}
			// quest info
			else if(this.box3 == origin && this.quests != null && 
				this.current2 >= 0 && this.current2 < this.quests.Count && 
				this.quests[this.current2] != null)
			{
				this.current3 = index;
				
				if(this.useChoice)
				{
					// canceled
					if(this.addBackText && this.infoAction[this.current3] == -1)
					{
						this.Cancel(origin);
					}
					// inactivate
					else if(this.quests[this.current2].IsActive())
					{
						this.quests[this.current2].SetInactive(this.screen.Combatant, true, true);
						this.Refresh();
					}
					// activate
					else if(this.quests[this.current2].IsInactive())
					{
						this.quests[this.current2].SetActive(this.screen.Combatant, true, true);
						this.Refresh();
					}
				}
			}
		}
		
		public void SelectionChanged(int index, GUIBox origin)
		{
			// type
			if(this.box == origin)
			{
				if(this.typeChoice != null && 
					index >= 0 && index < this.typeChoice.Length)
				{
					this.screen.ShowDescription(
						this.typeChoice[index].description, 
						this.typeChoice[index].Content.text, 
						this.typeAction[index] != -1 ? 
							ORK.QuestTypes.Get(this.typeAction[index]) : null);
				}
				else
				{
					this.screen.ShowDescription("", "", null);
				}
				
				this.current = index;
				if(MenuBoxDisplay.Multi.Equals(this.display))
				{
					this.ShowQuests();
				}
			}
			// quests
			else if(this.box2 == origin)
			{
				if(this.questChoice != null && 
					index >= 0 && index < this.questChoice.Length)
				{
					this.screen.ShowDescription(
						this.questChoice[index].description, 
						this.questChoice[index].Content.text, 
						this.quests[index]);
				}
				else
				{
					this.screen.ShowDescription("", "", null);
				}
				this.current2 = index;
				if(MenuBoxDisplay.Multi.Equals(this.displayText))
				{
					this.ShowTexts();
				}
			}
			// quest info
			else if(this.box3 == origin)
			{
				this.current3 = index;
			}
		}
		
		public void TabChanged(int index, GUIBox box)
		{
			if(this.box2 == box)
			{
				this.current = index;
				this.ShowQuests();
			}
		}
		
		public void Canceled(GUIBox origin)
		{
			origin.Audio.PlayCancel();
			this.Cancel(origin);
		}
		
		private void Cancel(GUIBox origin)
		{
			// type
			if(this.box == origin)
			{
				this.screen.Close();
			}
			// quest
			else if(this.box2 == origin)
			{
				if(this.showTypeBox)
				{
					this.nextBox = 1;
					if(MenuBoxDisplay.Same.Equals(this.display))
					{
						this.box = this.box2;
						this.box2 = null;
						this.ShowTypes();
						
						if(this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
						{
							this.box3.InitOut();
						}
					}
					else if(MenuBoxDisplay.One.Equals(this.display))
					{
						this.box2.InitOut();
						
						if(this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
						{
							this.box3.InitOut();
						}
					}
					else if(MenuBoxDisplay.Multi.Equals(this.display))
					{
						this.box.SetFocus();
					}
					else if(MenuBoxDisplay.Sequence.Equals(this.display))
					{
						this.box2.InitOut();
						this.box.SetFocus();
					}
				}
				else
				{
					this.screen.Close();
				}
			}
			// quest info
			else if(this.box3 == origin)
			{
				this.nextBox = 2;
				if(MenuBoxDisplay.Same.Equals(this.displayText))
				{
					this.box2 = this.box3;
					this.box2.Content = new DialogueContent("", "", this.questChoice, this, this.current2);
					this.box3 = null;
				}
				else if(MenuBoxDisplay.One.Equals(this.displayText))
				{
					this.box3.InitOut();
				}
				else if(MenuBoxDisplay.Multi.Equals(this.displayText))
				{
					this.box2.SetFocus();
				}
				else if(MenuBoxDisplay.Sequence.Equals(this.displayText))
				{
					this.box3.InitOut();
					this.box2.SetFocus();
				}
			}
		}
	}
}
