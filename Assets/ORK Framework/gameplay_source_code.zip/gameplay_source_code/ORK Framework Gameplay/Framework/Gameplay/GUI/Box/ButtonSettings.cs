
using UnityEngine;

namespace ORKFramework
{
	public class ButtonSettings : BaseData
	{
		[ORKEditorHelp("Padding", "The padding between the borders of the button and the text - " +
			"left (x), top (y), right (z) and bottom (w).", "")]
		public Vector4 padding = new Vector4(10, 10, 10, 10);
		
		[ORKEditorHelp("Show Button", "A button is shown around the content of the choice.\n" +
			"The style of the button is determined by the selected GUISkin.", "")]
		[ORKEditorInfo(separator=true)]
		public bool showButton = true;
		
		[ORKEditorHelp("Is One Line", "Choices are forced to display only one line of text.", "")]
		public bool oneline = false;
		
		[ORKEditorHelp("Line Spacing", "The space between text lines.", "")]
		public float lineSpacing = 10;
		
		[ORKEditorHelp("Text Alignment", "Select how the text of the button will be aligned horizontally.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75, separator=true)]
		public TextAlignment alignment = TextAlignment.Left;
		
		[ORKEditorHelp("Line Alignment", "Select how text lines will be aligned vertically.\n" +
			"This is used to align text lines consisting of labels with different heights (e.g. text and icons).", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public VerticalTextAlignment vAlignment = VerticalTextAlignment.Bottom;
		
		[ORKEditorHelp("Info Text Alignment", "Select how the information of the button will be aligned horizontally " +
			"(e.g. ability cost, item quantity, etc.).", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public TextAlignment alignmentInfo = TextAlignment.Right;
		
		[ORKEditorHelp("Info Line Alignment", "Select how information text lines will be aligned vertically.\n" +
			"This is used to align text lines consisting of labels with different heights (e.g. text and icons).", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public VerticalTextAlignment vAlignmentInfo = VerticalTextAlignment.Bottom;
		
		[ORKEditorHelp("Align Icons", "Heading icons (e.g. from menu options) will be aligned with the content text.\n" +
			"If disabled, heading icons will always be displayed at the left side of the button.", "")]
		[ORKEditorInfo(separator=true, labelText="Icon Settings")]
		public bool alignIcons = true;
		
		[ORKEditorHelp("Icon Padding", "The padding between the heading icon and the text of the button. ", "")]
		public float iconPadding = 5;
		
		
		// text format
		[ORKEditorInfo("Text Format", "Define the appearance of the text, e.g. color, shadow, font size.", "")]
		public TextFormat textFormat = TextFormat.Default;
		
		[ORKEditorHelp("Own Info Format", "Use a different text format for the info text " +
			"(e.g. used for item quantity or use costs).", "")]
		[ORKEditorInfo(separator=true, labelText="Info Format")]
		public bool ownInfoFormat = false;
		
		[ORKEditorLayout("ownInfoFormat", true, endCheckGroup=true)]
		public TextFormat infoFormat = TextFormat.Default;
		
		[ORKEditorHelp("Own Title Format", "Use a different text format for the title text " +
			"(e.g. used for displaying equipment parts in equipment menus).", "")]
		[ORKEditorInfo(separator=true, labelText="Title Format")]
		public bool ownTitleFormat = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownTitleFormat", true, endCheckGroup=true)]
		public TextFormat titleFormat = TextFormat.Default;
		
		public ButtonSettings()
		{
			
		}
	}
}
