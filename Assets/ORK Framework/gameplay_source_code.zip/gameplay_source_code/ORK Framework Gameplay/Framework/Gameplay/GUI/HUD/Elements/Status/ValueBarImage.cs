
using UnityEngine;

namespace ORKFramework
{
	public class ValueBarImage : BaseData
	{
		[ORKEditorHelp("Percent", "Set until which filled percent this bar will be displayed.\n" +
			"You can use the percent setting to display the bar in different images/colors, " +
			"depending on the filling of the bar (e.g. red health bar if health is below 25 %).", "")]
		[ORKEditorLimit(0.0f, 100.0f)]
		public float percent = 100;
		
		[ORKEditorInfo(labelText="Bar Image")]
		public BarImage image = new BarImage();
		
		[ORKEditorHelp("Use Empty Bar", "The empty part of the bar will be filled with an image.", "")]
		[ORKEditorInfo(labelText="Empty Bar Image")]
		public bool useEmpty = false;
		
		[ORKEditorLayout("useEmpty", true, endCheckGroup=true, autoInit=true)]
		public BarImage emptyImage;
		
		public ValueBarImage()
		{
			
		}
	}
}
