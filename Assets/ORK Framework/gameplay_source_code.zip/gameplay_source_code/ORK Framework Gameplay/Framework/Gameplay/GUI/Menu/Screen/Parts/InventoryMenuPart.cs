
using UnityEngine;
using ORKFramework;
using ORKFramework.Menu;
using System.Collections.Generic;

namespace ORKFramework.Menu.Parts
{
	[ORKEditorHelp("Inventory", "Displays the inventory of a combatant.\n" +
			"The items, weapons and armors can be separated by item type.", "")]
	public class InventoryMenuPart : BaseMenuPart, IChoiceDrop, ITabChoice, IDragOrigin
	{
		[ORKEditorHelp("Close After Use", "Close this menu screen after using an item or equipping a weapon or armor.", "")]
		public bool closeAfter = false;
		
		[ORKEditorHelp("Don't Return", "Don't return to previously opened menu screens when " +
			"closing the screen after using an item or equipping a weapon or armor.", "")]
		[ORKEditorLayout("closeAfter", true, endCheckGroup=true)]
		public bool closeAfterNoReturn = false;
		
		[ORKEditorHelp("Use Screen Combatant", "Automatically use items (or equip weapons/armors) on the current menu user.", "")]
		public bool useScreenCom = false;
		
		[ORKEditorHelp("Animate Use", "Using an item will be animated, " +
			"i.e. it's animation battle events will be performed if set up for the current game mode.", "")]
		public bool animateUse = true;
		
		[ORKEditorHelp("Default Action", "Select the default action when an item is selected:\n" +
			"- Use: Uses the item, equips the weapon/armor.\n" +
			"- Give: Gives the item/equipment to another group member (only possible if 'Individual' inventory is used).\n" +
			"- Remove: Removes the item/equipment.\n" +
			"- Drop: Drops the item/equipment into the game world (which will remove it from the inventory).\n" +
			"- Back: Closes the sub menu without doing anything.\n" +
			"- Cancel: Closes the sub menu without doing anything.\n" +
			"- Level Up: Increases the level of the equipment with level up type 'Spend' (if enough experience is available).\n" +
			"- Assign Shortcut: Shows a menu to assign an item/equipment to a shortcut slot of the menu user.", "")]
		public SubMenuAction defaultAction = SubMenuAction.Use;
		
		// shortcut menu
		[ORKEditorInfo("Shortcut Menu", "Define the shortcut slots that will be available.", "", endFoldout=true)]
		[ORKEditorLayout("defaultAction", SubMenuAction.AssignShortcut, endCheckGroup=true, autoInit=true)]
		public AssignShortcutMenu shortcutMenu;
		
		
		
		// type settings
		// available types
		[ORKEditorHelp("All Item Types", "All item types will be available.\n" +
			"If disabled, you have to select the item types that will be available.", "")]
		[ORKEditorInfo("Available Item Types", "Define what item types will be displayed in this menu screen.", "")]
		public bool allTypes = true;
		
		public TypeSorter typeSorter = new TypeSorter();
		
		[ORKEditorHelp("Item Type", "Select the item type that will be available.", "")]
		[ORKEditorInfo(ORKDataType.ItemType, endFoldout=true, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Item Type", "Adds an item type that will be available.", "", 
			"Remove", "Removes this item type.", "", noRemoveCount=1, isHorizontal=true)]
		[ORKEditorLayout("allTypes", false, endCheckGroup=true, autoInit=true, autoSize=1)]
		public int[] availableTypeID;
		
		
		
		// type box settings
		[ORKEditorHelp("Show Type Box", "A type selection box is displayed.\n" +
			"If disabled, no type selection box is displayed, " +
			"but you can change the type using the change type keys.", "")]
		[ORKEditorInfo("Type Box Settings", "Define the content and layout of the item type box.", "")]
		public bool showTypeBox = true;
		
		[ORKEditorHelp("Show Empty Types", "Empty item types (without any items in the inventory) will be displayed (with inactive buttons).\n" +
			"If disabled, only the item types available in the combatant's inventory will be displayed.", "")]
		public bool showEmptyTypes = false;
		
		[ORKEditorHelp("Merge Types", "Merge all item types into a single display.\n" +
			"If disabled, only a single item type will be displayed at a time - " +
			"you can use the type change keys to circle through available types.", "")]
		[ORKEditorLayout("showTypeBox", false, setDefault=true, defaultValue=false)]
		public bool mergeTypes = false;
		
		[ORKEditorHelp("Type Tabs", "Show the item types as tabs in the item box.", "")]
		[ORKEditorLayout("mergeTypes", false, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool typeTabs = false;
		
		[ORKEditorHelp("Box Display", "Select the box display mode:\n" +
			"- Same: Types and items/equipment use the same GUI box.\n" +
			"- One: Only one box will be displayed at a time. Types and items/equipment use different GUI boxes.\n" +
			"- Multi: Multiple boxes are displayed at the same time. Types and items/equipment use different GUI boxes.\n" +
			"- Sequence: Same as 'Multi', but the items/equipment will only be displayed when a type was selected.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout(elseCheckGroup=true, setDefault=true, defaultValue=MenuBoxDisplay.Multi)]
		public MenuBoxDisplay display = MenuBoxDisplay.Multi;
		
		[ORKEditorHelp("Type Box", "Select the GUI box used to display the item types.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		[ORKEditorLayout("display", MenuBoxDisplay.Same, elseCheckGroup=true, endCheckGroup=true)]
		public int guiBoxID = 0;
		
		// back button
		[ORKEditorHelp("Add Back", "A back button will be added to the item type list.", "")]
		[ORKEditorInfo(separator=true)]
		public bool addBackType = false;
		
		[ORKEditorHelp("First Element", "The back button will be the first element in the item type list.\n" +
			"If disabled, the back button will be the last element.", "")]
		[ORKEditorLayout("addBackType", true, endCheckGroup=true)]
		public bool backFirstType = false;
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used type GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		[ORKEditorLayout(setDefault=true, defaultValue=false)]
		public bool useTypeTitle = false;
		
		[ORKEditorHelp("Title", "The title of the box.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTypeTitle", true, endCheckGroup=true, endGroups=2, autoInit=true, autoLangSize=true)]
		public string[] typeTitle;
		
		// layout
		[ORKEditorInfo("Type Content Layout", "Define the layout of the item type buttons.", "", 
			endFoldout=true, endFolds=2)]
		[ORKEditorLayout(new string[] {"showTypeBox", "typeTabs"}, new System.Object[] {true, true}, 
			needed=Needed.One, endCheckGroup=true)]
		public ContentLayout typeContentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.None);
		
		
		
		// item box settings
		[ORKEditorHelp("Item Box", "Select the GUI box used to display the items, money and equipment.\n" +
			"If 'Same' box display is selected, this box will also display the item types.", "")]
		[ORKEditorInfo("Item Box Settings", "Define the content and layout of the item box.", "", 
			isPopup=true, popupType=ORKDataType.GUIBox)]
		public int guiBoxID2 = 0;
		
		[ORKEditorHelp("Show Portraits", "Display the portrait of a selected item (if available).", "")]
		public bool showItemPortraits = false;
		
		[ORKEditorInfo(separator=true)]
		public ContentSorter contentSorter = new ContentSorter();
		
		[ORKEditorHelp("Add Money", "Money will be added to the list.", "")]
		[ORKEditorInfo(separator=true)]
		public bool addMoney = false;
		
		[ORKEditorHelp("Add Items", "Items will be added to the list.", "")]
		public bool addItems = true;
		
		[ORKEditorHelp("Add Weapons", "Weapons will be added to the list.", "")]
		public bool addWeapons = true;
		
		[ORKEditorHelp("Add Armors", "Armors will be added to the list.", "")]
		public bool addArmors = true;
		
		// back button
		[ORKEditorHelp("Add Back", "A back button will be added to the item/equipment list.", "")]
		[ORKEditorInfo(separator=true)]
		public bool addBack = false;
		
		[ORKEditorHelp("First Element", "The back button will be the first element in the item/equipment list.\n" +
			"If disabled, the back button will be the last element.", "")]
		[ORKEditorLayout("addBack", true, endCheckGroup=true)]
		public bool backFirst = false;
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used item/equipment GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useTitle = false;
		
		[ORKEditorHelp("Title", "The title of the item/equipment box.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {
			"%n = type name (only if 'Merge Types' isn't selected)"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitle", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] title;
		
		// layout
		[ORKEditorInfo("Item Content Layout", "Define the layout of the item buttons.", "", 
			endFoldout=true)]
		public ContentLayout contentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.Info);
		
		// drag/drop
		[ORKEditorHelp("Enable Dragging", "Items and equipment can be dragged.\n" +
			"Dragging an item on a combatant will use it on the combatant or give it to the combatant.\n" +
			"Dragging an equipment on a combatant will equip it on the combatant or give it to the combatant.", "")]
		[ORKEditorInfo("Drag and Drop", "Items and equipment can be used, dropped or equipped using dragging or double clicking.", "")]
		public bool enableDrag = false;
		
		[ORKEditorHelp("Enable Double Click", "Items and equipment can be double clicked.\n" +
			"Double clicking on an item and clicking on a combatant will use it on the combatant or give it to the combatant.\n" +
			"Double clicking on an equipment and clicking on a combatant will equip it on the combatant or give it to the combatant.", "")]
		public bool enableDoubleClick = false;
		
		[ORKEditorHelp("Enable Tooltip", "A tooltip HUD can be displayed when the mouse position is over a menu item.", "")]
		public bool enableTooltip = false;
		
		[ORKEditorHelp("Drag Inactive", "Inactive choices (i.e. items that can't be used) can be dragged/double clicked.\n" +
			"If disabled, inactive choices can't be dragged or double clicked.", "")]
		[ORKEditorLayout(new string[] {"enableDrag", "enableDoubleClick"}, 
			new System.Object[] {true, true}, needed=Needed.One, setDefault=true, defaultValue=false)]
		public bool dragInactive = false;
		
		// drop give
		[ORKEditorHelp("Give On Drop", "Items and equipment are given to a combatant, instead of using them on the combatant.", "")]
		[ORKEditorInfo(separator=true, labelText="Drop Give")]
		public bool dropGive = false;
		
		[ORKEditorLayout("dropGive", true, endCheckGroup=true, autoInit=true)]
		public QuantityCall giveQuantity;
		
		// world drop
		[ORKEditorHelp("Drop To World", "Items and equipment will be dropped into the game world if they aren't dropped on a combatant or interaction.", "")]
		[ORKEditorInfo(separator=true, labelText="World Drop")]
		public bool dropToWorld = false;
		
		[ORKEditorInfo(endFoldout=true, endFolds=2)]
		[ORKEditorLayout("dropToWorld", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public QuantityCall dropQuantity;
		
		
		
		// switch type keys
		[ORKEditorHelp("Use Change Keys", "The item type can be changed by input keys.", "")]
		[ORKEditorInfo("Type Change Keys", "The item type can be changed by input keys.", "")]
		[ORKEditorLayout("mergeTypes", false, setDefault=true, defaultValue=false)]
		public bool useTypeKeys = false;
		
		[ORKEditorHelp("Next Type", "Select the key used to select the next item type.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("useTypeKeys", true)]
		public int nextTypeKey = 0;
		
		[ORKEditorHelp("Previous Type", "Select the key used to select the previous item type.", "")]
		[ORKEditorInfo(ORKDataType.InputKey, endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public int prevTypeKey = 0;
		
		
		// sub menu
		[ORKEditorHelp("Use Sub Menu", "A sub menu can be displayed for a selected menu item (item, equipment), " +
			"the sub menu can display different choices (e.g. use/equip, remove, etc.).\n" +
			"The sub menu is called by using an input key, if you use the same key as you've used for the 'Accept' key, " +
			"the sub menu will be dispalyed instead of using the selected menu item.", "")]
		[ORKEditorInfo("Sub Menu Settings", "A sub menu can be displayed for a selected menu item (item, equipment), " +
			"the sub menu can display different choices (e.g. use/equip, remove, etc.).\n" +
			"The sub menu is called by using an input key, if you use the same key as you've used for the 'Accept' key, " +
			"the sub menu will be dispalyed instead of using the selected menu item.", "")]
		public bool useSubMenu = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useSubMenu", true, endCheckGroup=true, autoInit=true)]
		public SubMenu subMenu;
		
		
		// level points display
		[ORKEditorHelp("Display Level Points", "Display an equipment's level points (if it can be leveld up).", "")]
		[ORKEditorInfo("Level Points Display", "Equipment that can be leveled up can display their " +
			"current level points as text and bar in their menu item.\n" +
			"Level points will only be displayed for equipment that can level up and haven't reached their maximum level yet.", "", separatorForce=true)]
		public bool displayLevelPoints = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Level Points Element", "Adds a level points element.", "", 
			"Remove", "Removes this level points element.", "", foldout=true, isMove=true, isCopy=true,  
			foldoutText=new string[] {"Level Points Element", "Set the position, size, content and background image of this element.\n" +
				"The coordinates X=0, Y=0 are located at the upper left corner of the button displaying the equipment.", ""})]
		[ORKEditorLayout("displayLevelPoints", true, endCheckGroup=true, autoInit=true)]
		public HUDLevelPoints[] levelPointsElement;
		
		
		// ingame
		private GUIBox box;
		
		private GUIBox box2;
		
		private int tmpTypeID = 0;
		
		private int current = 0;
		
		private int current2 = 0;
		
		private bool exitFlag = false;
		
		private SubMenuItem menuAction;
		
		private bool inActionRefresh = false;
		
		
		// item types
		private ChoiceContent[] typeChoice;
		
		private int[] typeAction;
		
		private List<int> itemTypes;
		
		
		// items/equipment
		private ChoiceContent[] itemChoice;
		
		private List<IShortcut> items;
		
		public InventoryMenuPart()
		{
			
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return false;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return false;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public override bool Controlable
		{
			get{ return this.IsOpened;}
		}
		
		
		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public override bool OnScreenCombatant
		{
			get{ return this.useScreenCom;}
		}
		
		public override bool IsOpened
		{
			get
			{
				return (this.box == null || this.box.FadedIn) && 
					(this.box2 == null || this.box2.FadedIn);
			}
		}
		
		public override bool IsClosed
		{
			get{ return this.box == null && this.box2 == null;}
		}
		
		public bool Tick(GUIBox origin)
		{
			// refresh list when out of action
			if(this.screen.Combatant.Actions.InAction)
			{
				if(!this.inActionRefresh)
				{
					this.inActionRefresh = true;
					this.Refresh();
				}
			}
			else if(this.inActionRefresh)
			{
				this.inActionRefresh = false;
				this.Refresh();
			}
			
			// type change
			if(this.useTypeKeys)
			{
				if(ORK.InputKeys.Get(this.nextTypeKey).GetButton())
				{
					this.ChangeTypeKey(1, origin);
					return true;
				}
				else if(ORK.InputKeys.Get(this.prevTypeKey).GetButton())
				{
					this.ChangeTypeKey(-1, origin);
					return true;
				}
			}
			// sub menu call
			if(this.useSubMenu && origin == this.box2 && 
				this.current2 >= 0 && this.current2 < this.itemChoice.Length && 
				this.items[this.current2] != null)
			{
				if(ORK.InputKeys.Get(this.subMenu.keyID).GetButton())
				{
					if(this.subMenu.Show(this.items[this.current2], this, this.animateUse))
					{
						origin.Audio.PlayAccept();
					}
					else
					{
						origin.Audio.PlayFail();
					}
					return true;
				}
				else
				{
					for(int i=0; i<this.subMenu.item.Length; i++)
					{
						if(this.subMenu.item[i].useKey && 
							ORK.InputKeys.Get(this.subMenu.item[i].keyID).GetButton())
						{
							if(this.subMenu.item[i].Use(this.items[this.current2], this, null, this.animateUse))
							{
								origin.Audio.PlayAccept();
								if(this.closeAfter)
								{
									if(this.closeAfterNoReturn)
									{
										this.screen.Clear();
									}
									this.screen.Close();
								}
							}
							else
							{
								origin.Audio.PlayFail();
							}
							return true;
						}
					}
				}
			}
			return false;
		}
		
		private void ChangeTypeKey(int change, GUIBox origin)
		{
			origin.Audio.PlayCursorMove();
			if(this.showTypeBox)
			{
				int index = this.current + change;
				if(index < 0)
				{
					index = this.typeChoice.Length - 1;
				}
				else if(index >= this.typeChoice.Length)
				{
					index = 0;
				}
				
				if(this.box != null)
				{
					this.box.Content.Selection = index;
				}
				if(this.box2 == origin)
				{
					this.ShowItems();
				}
			}
			else if(this.box2 == origin)
			{
				this.CreateTypeList();
				
				int index = 0;
				for(int i=0; i<this.itemTypes.Count; i++)
				{
					if(this.itemTypes[i] == this.tmpTypeID)
					{
						index = i;
						break;
					}
				}
				index += change;
				if(index < 0)
				{
					index = this.itemTypes.Count - 1;
				}
				else if(index >= this.itemTypes.Count)
				{
					index = 0;
				}
				this.tmpTypeID = this.itemTypes[index];
				this.ShowItems();
			}
		}
		
		
		/*
		============================================================================
		Choice creation functions
		============================================================================
		*/
		private void CreateTypeList()
		{
			if(this.allTypes)
			{
				if(this.showEmptyTypes)
				{
					this.itemTypes = new List<int>();
					for(int i=0; i<ORK.ItemTypes.Count; i++)
					{
						this.itemTypes.Add(i);
					}
				}
				else
				{
					this.itemTypes = this.screen.Combatant.Inventory.GetItemTypes(
						this.addMoney, this.addItems, this.addWeapons, this.addArmors);
				}
			}
			else
			{
				if(this.showEmptyTypes)
				{
					this.itemTypes = new List<int>(this.availableTypeID);
				}
				else
				{
					this.itemTypes = new List<int>();
					for(int i=0; i<this.availableTypeID.Length; i++)
					{
						if(this.screen.Combatant.Inventory.HasItemType(this.availableTypeID[i], 
							this.addMoney, this.addItems, this.addWeapons, this.addArmors))
						{
							this.itemTypes.Add(this.availableTypeID[i]);
						}
					}
				}
			}
			this.typeSorter.Sort(ref this.itemTypes, ORKDataType.ItemType);
		}
		
		private void CreateTypeChoices()
		{
			this.typeChoice = null;
			this.typeAction = null;
			
			if(this.screen.Combatant != null)
			{
				this.CreateTypeList();
				
				List<ChoiceContent> cc = new List<ChoiceContent>();
				List<int> ca = new List<int>();
				
				// back first
				if(this.addBackType && this.backFirstType)
				{
					cc.Add(this.typeContentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
					ca.Add(-1);
				}
				
				// types
				for(int i=0; i<this.itemTypes.Count; i++)
				{
					ChoiceContent content = this.typeContentLayout.GetChoiceContent(ORK.ItemTypes.Get(this.itemTypes[i]));
					if(this.showEmptyTypes)
					{
						content.Active = this.screen.Combatant.Inventory.HasItemType(this.itemTypes[i], 
							this.addMoney, this.addItems, this.addWeapons, this.addArmors);
					}
					cc.Add(content);
					ca.Add(this.itemTypes[i]);
				}
				
				// back last
				if(this.addBackType && !this.backFirstType)
				{
					cc.Add(this.typeContentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
					ca.Add(-1);
				}
				
				this.typeChoice = cc.ToArray();
				this.typeAction = ca.ToArray();
			}
		}
		
		private void CreateItemChoices()
		{
			this.items = null;
			this.itemChoice = null;
			
			if(this.menuAction == null)
			{
				this.menuAction = SubMenuItem.Create(this.defaultAction);
				if(SubMenuAction.AssignShortcut.Equals(this.defaultAction))
				{
					this.menuAction.shortcutMenu = this.shortcutMenu;
				}
			}
			
			if(this.screen.Combatant != null)
			{
				if(!this.showTypeBox && !this.mergeTypes && this.typeTabs)
				{
					this.CreateTypeChoices();
				}
				
				// items
				if((this.showTypeBox || (!this.mergeTypes && this.typeTabs)) && 
					this.current >= 0 && this.current < this.typeAction.Length && 
					this.typeAction[this.current] != -1)
				{
					this.items = this.screen.Combatant.Inventory.GetContent(this.screen.Combatant, 
						this.addMoney, this.addItems, this.addWeapons, this.addArmors, this.typeAction[this.current]);
				}
				else if(!this.showTypeBox && this.mergeTypes)
				{
					this.items = this.screen.Combatant.Inventory.GetContent(this.screen.Combatant, 
						this.addMoney, this.addItems, this.addWeapons, this.addArmors);
				}
				else
				{
					this.items = this.screen.Combatant.Inventory.GetContent(this.screen.Combatant, 
						this.addMoney, this.addItems, this.addWeapons, this.addArmors, this.tmpTypeID);
				}
				
				if(this.items != null)
				{
					this.contentSorter.Sort(ref this.items);
					
					List<ChoiceContent> cc = new List<ChoiceContent>();
					
					// back first
					if(this.addBack && this.backFirst)
					{
						cc.Add(this.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
						this.items.Insert(0, null);
					}
					
					for(int i=0; i<this.items.Count; i++)
					{
						if(this.items[i] != null)
						{
							if(this.items[i] is ItemShortcut && 
								((ItemShortcut)this.items[i]).Setting.hidden)
							{
								this.items.RemoveAt(i--);
							}
							else
							{
								ChoiceContent content = this.contentLayout.GetChoiceContent(this.items[i], this.screen.Combatant);
								content.Active = (!SubMenuAction.Use.Equals(this.defaultAction) || 
									(this.items[i].IsUseable(UseableIn.Field) && 
										!this.items[i].TargetEnemy() && 
										!this.screen.Combatant.Actions.InAction)) && 
									this.menuAction.CanUse(this.items[i], this);
								
								if(this.showItemPortraits && this.items[i].HasPortrait())
								{
									content.portrait = this.items[i].GetPortrait();
								}
								
								// drag and drop
								content.isDragable = this.enableDrag;
								content.isDoubleClick = this.enableDoubleClick;
								content.isTooltip = this.enableTooltip;
								content.dragInactive = this.dragInactive;
								if(content.isDragable || content.isDoubleClick || content.isTooltip || 
									(this.displayLevelPoints && this.items[i] is EquipShortcut && 
									((EquipShortcut)this.items[i]).CanLevelUp()))
								{
									content.drag = this.items[i].GetDrag(this, this.screen.Combatant);
									if(content.drag != null && this.displayLevelPoints && 
										this.items[i] is EquipShortcut && ((EquipShortcut)this.items[i]).CanLevelUp())
									{
										content.drag.LevelPointsDisplay = this.levelPointsElement;
									}
								}
								cc.Add(content);
							}
						}
					}
					
					// back last
					if(this.addBack && !this.backFirst)
					{
						cc.Add(this.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
						this.items.Add(null);
					}
					
					this.itemChoice = cc.ToArray();
				}
			}
		}
		
		
		/*
		============================================================================
		Screen functions
		============================================================================
		*/
		public override bool ShowFirstDescription()
		{
			if(this.box != null && this.typeChoice != null && 
				this.current >= 0 && this.current < this.typeChoice.Length)
			{
				this.screen.ShowDescription(
					this.typeChoice[this.current].description, 
					this.typeChoice[this.current].Content.text, 
					this.typeAction[this.current] != -1 ? 
						ORK.ItemTypes.Get(this.typeAction[this.current]) : null);
				return true;
			}
			if(this.box2 != null && this.itemChoice != null && 
				this.current2 >= 0 && this.current2 < this.itemChoice.Length)
			{
				this.screen.ShowDescription(
					this.itemChoice[this.current2].description, 
					this.itemChoice[this.current2].Content.text, 
					this.items[this.current2]);
				return true;
			}
			return false;
		}
		
		public override bool FocusFirst()
		{
			if(this.box != null)
			{
				this.box.SetFocus();
				return true;
			}
			else if(this.box2 != null)
			{
				this.box2.SetFocus();
				return true;
			}
			return false;
		}
		
		public override bool IsFocused()
		{
			return (this.box != null && this.box.Focused) || 
				(this.box2 != null && this.box2.Focused);
		}
		
		public override void Refresh()
		{
			if(this.box != null)
			{
				this.ShowTypes();
			}
			if(this.box2 != null)
			{
				this.ShowItems();
			}
		}
		
		public override void Show(MenuScreen s)
		{
			this.screen = s;
			this.CreateTypeList();
			this.tmpTypeID = this.itemTypes.Count > 0 ? this.itemTypes[0] : 0;
			
			if(this.showTypeBox && 
				MenuBoxDisplay.Same.Equals(this.display))
			{
				this.guiBoxID = this.guiBoxID2;
			}
			
			this.screen.Combatant.Inventory.Changed += this.InventoryChanged;
			
			this.Show();
		}
		
		public override void ChangeCombatant(Combatant old)
		{
			old.Inventory.Changed -= this.InventoryChanged;
			this.screen.Combatant.Inventory.Changed += this.InventoryChanged;
			this.Refresh();
		}
		
		public override void CloseImmediate()
		{
			this.screen.Combatant.Inventory.Changed -= this.InventoryChanged;
			if(this.box != null)
			{
				this.box.SetOutDone();
				this.box = null;
			}
			if(this.box2 != null)
			{
				this.box2.SetOutDone();
				this.box2 = null;
			}
		}
		
		public override void Close()
		{
			this.screen.Combatant.Inventory.Changed -= this.InventoryChanged;
			this.exitFlag = true;
			if(this.box != null && !this.box.FadingOut && !this.box.FadedOut)
			{
				this.box.InitOut();
			}
			if(this.box2 != null && !this.box2.FadingOut && !this.box2.FadedOut)
			{
				this.box2.InitOut();
			}
		}
		
		public void InventoryChanged(Inventory inventory, 
			ItemDropType type, int id, int level, int quantity)
		{
			this.Refresh();
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show()
		{
			if(!this.screen.RememberSelection)
			{
				this.current = 0;
				this.current2 = 0;
			}
			
			// type choice and items
			if(this.showTypeBox)
			{
				this.ShowTypes();
				
				if(MenuBoxDisplay.Multi.Equals(this.display))
				{
					this.ShowItems();
				}
				
				this.box.SetFocus();
				this.SelectionChanged(this.current, this.box);
			}
			// only items
			else
			{
				this.ShowItems();
			}
		}
		
		public void FocusGained(GUIBox origin)
		{
			if(this.box == origin && !this.box.FadingOut && !this.box.FadedOut && 
				this.typeChoice != null && 
				this.current >= 0 && this.current < this.typeChoice.Length)
			{
				this.screen.ShowDescription(
					this.typeChoice[this.current].description, 
					this.typeChoice[this.current].Content.text, 
					this.typeAction[this.current] != -1 ? 
						ORK.ItemTypes.Get(this.typeAction[this.current]) : null);
				
				if(this.box2 != null && !this.box2.FadingOut && 
					this.showTypeBox && 
					MenuBoxDisplay.Sequence.Equals(this.display))
				{
					this.box2.InitOut();
				}
			}
			else if(this.box2 == origin && !this.box2.FadingOut && !this.box2.FadedOut && 
				this.itemChoice != null && 
				this.current2 >= 0 && this.current2 < this.itemChoice.Length)
			{
				this.screen.ShowDescription(
					this.itemChoice[this.current2].description, 
					this.itemChoice[this.current2].Content.text, 
					this.items[this.current2]);
				ORK.GUI.SelectedShortcut = this.items[this.current2];
			}
		}
		
		public void FocusLost(GUIBox origin)
		{
			if(this.box2 == origin)
			{
				ORK.GUI.SelectedShortcut = null;
				if(!this.box2.FadingOut && this.showTypeBox && 
					MenuBoxDisplay.Sequence.Equals(this.display))
				{
					this.box2.InitOut();
				}
			}
		}
		
		private void ShowTypes()
		{
			this.CreateTypeChoices();
			
			if(this.box == null || this.box.FadingOut || this.box.FadedOut)
			{
				this.box = ORK.GUIBoxes.Create(this.guiBoxID);
				this.box.inPause = this.screen.pauseGame;
				this.box.InitIn();
			}
			
			ValueHelper.Limit(ref this.current, 0, this.typeChoice.Length - 1);
			if(this.box.Content == null)
			{
				this.box.Content = new DialogueContent("", 
					this.useTypeTitle ? this.typeTitle[ORK.Game.Language] : "", 
					this.typeChoice, this, this.current);
			}
			else
			{
				((DialogueContent)this.box.Content).Update("", 
					this.useTypeTitle ? this.typeTitle[ORK.Game.Language] : "", 
					this.typeChoice, this.current, null, null);
			}
			if(this.box.Focused)
			{
				this.SelectionChanged(this.current, this.box);
			}
		}
		
		private void ShowItems()
		{
			this.CreateItemChoices();
			
			if(this.box2 == null || this.box2.FadingOut || this.box2.FadedOut)
			{
				this.box2 = ORK.GUIBoxes.Create(this.guiBoxID2);
				this.box2.inPause = this.screen.pauseGame;
				this.box2.InitIn();
			}
			
			if(this.itemChoice == null)
			{
				this.current2 = 0;
			}
			else
			{
				ValueHelper.Limit(ref this.current2, 0, this.itemChoice.Length - 1);
			}
			
			if(this.box2.Content == null)
			{
				this.box2.Content = new DialogueContent("", this.GetTitle(), 
					this.itemChoice, this, this.current2);
			}
			else
			{
				((DialogueContent)this.box2.Content).Update("", this.GetTitle(), 
					this.itemChoice, this.current2, null, null);
			}
			
			if(!this.showTypeBox && !this.mergeTypes && this.typeTabs)
			{
				this.box2.Content.SetTabs(this.typeChoice);
			}
			if(this.box2.Focused)
			{
				this.SelectionChanged(this.current2, this.box2);
			}
		}
		
		private string GetTitle()
		{
			if(this.useTitle)
			{
				if(this.showTypeBox && this.typeChoice != null && 
					this.current >= 0 && this.current < this.typeChoice.Length && 
					this.typeAction[this.current] != -1)
				{
					return this.title[ORK.Game.Language].Replace("%n", this.typeChoice[this.current].Content.text);
				}
				else if(!this.showTypeBox && !this.mergeTypes)
				{
					return this.title[ORK.Game.Language].Replace("%n", ORK.ItemTypes.GetName(this.tmpTypeID));
				}
				else
				{
					return this.title[ORK.Game.Language].Replace("%n", "");
				}
			}
			return "";
		}
		
		public void Closed(GUIBox origin)
		{
			if(this.exitFlag)
			{
				if(this.box == origin)
				{
					this.box = null;
				}
				else if(this.box2 == origin)
				{
					this.box2 = null;
				}
				if(this.box == null && this.box2 == null)
				{
					this.exitFlag = false;
				}
			}
			else
			{
				// type switch to item
				if(this.box == origin)
				{
					this.box = null;
					if(MenuBoxDisplay.One.Equals(this.display))
					{
						this.ShowItems();
					}
				}
				// item
				else if(this.box2 == origin)
				{
					this.box2 = null;
					if(this.showTypeBox && 
						MenuBoxDisplay.One.Equals(this.display))
					{
						this.ShowTypes();
					}
				}
			}
		}
		
		public override void CombatantChoiceClosed(bool canceled)
		{
			this.Refresh();
			if(!canceled && this.closeAfter)
			{
				if(this.closeAfterNoReturn)
				{
					this.screen.Clear();
				}
				this.screen.Close();
			}
			else if(this.box2 != null)
			{
				this.box2.SetFocus();
			}
		}
		
		public override void SubMenuClosed(bool canceled)
		{
			this.Refresh();
			if(!canceled && this.closeAfter)
			{
				if(this.closeAfterNoReturn)
				{
					this.screen.Clear();
				}
				this.screen.Close();
			}
			else if(this.box2 != null)
			{
				this.box2.SetFocus();
			}
		}
		
		
		/*
		============================================================================
		Selection functions
		============================================================================
		*/
		public void ChoiceSelected(int index, GUIBox origin)
		{
			// type
			if(this.box == origin && this.typeChoice != null && 
				index >= 0 && index < this.typeChoice.Length)
			{
				if(this.current != index)
				{
					this.SelectionChanged(index, origin);
				}
				
				this.current = index;
				
				if(this.typeAction[this.current] == -1)
				{
					this.Cancel(this.box);
				}
				else
				{
					if(MenuBoxDisplay.Same.Equals(this.display))
					{
						this.box2 = this.box;
						this.box = null;
						this.ShowItems();
					}
					else if(MenuBoxDisplay.One.Equals(this.display))
					{
						this.box.InitOut();
					}
					else if(MenuBoxDisplay.Multi.Equals(this.display))
					{
						this.box2.SetFocus();
					}
					else if(MenuBoxDisplay.Sequence.Equals(this.display))
					{
						this.ShowItems();
					}
				}
			}
			// item
			else if(this.box2 == origin && this.itemChoice != null && 
				index >= 0 && index < this.itemChoice.Length)
			{
				this.current2 = index;
				if(this.items[this.current2] == null)
				{
					this.Cancel(this.box2);
				}
				else if(this.menuAction.Use(this.items[index], this, null, this.animateUse))
				{
					if(this.closeAfter)
					{
						if(this.closeAfterNoReturn)
						{
							this.screen.Clear();
						}
						this.screen.Close();
					}
					else
					{
						this.Refresh();
					}
				}
			}
		}
		
		public void SelectionChanged(int index, GUIBox origin)
		{
			// type
			if(this.box == origin)
			{
				if(this.typeChoice != null && 
					index >= 0 && index < this.typeChoice.Length)
				{
					this.screen.ShowDescription(
						this.typeChoice[index].description, 
						this.typeChoice[index].Content.text, 
						this.typeAction[index] != -1 ? 
							ORK.ItemTypes.Get(this.typeAction[index]) : null);
				}
				else
				{
					this.screen.ShowDescription("", "", null);
				}
				
				this.current = index;
				if(MenuBoxDisplay.Multi.Equals(this.display))
				{
					this.ShowItems();
				}
			}
			// item
			else if(this.box2 == origin)
			{
				if(this.itemChoice != null && 
					index >= 0 && index < this.itemChoice.Length)
				{
					this.screen.ShowDescription(
						this.itemChoice[index].description, 
						this.itemChoice[index].Content.text, 
						this.items[index]);
					ORK.GUI.SelectedShortcut = this.items[index];
				}
				else
				{
					this.screen.ShowDescription("", "", null);
					ORK.GUI.SelectedShortcut = null;
				}
				this.current2 = index;
			}
		}
		
		public void TabChanged(int index, GUIBox box)
		{
			if(this.box2 == box)
			{
				this.current = index;
				this.ShowItems();
			}
		}
		
		public void Canceled(GUIBox origin)
		{
			origin.Audio.PlayCancel();
			this.Cancel(origin);
		}
		
		private void Cancel(GUIBox origin)
		{
			// type
			if(this.box == origin)
			{
				this.screen.Close();
			}
			// item
			else if(this.box2 == origin)
			{
				if(this.showTypeBox)
				{
					if(MenuBoxDisplay.Same.Equals(this.display))
					{
						this.box = this.box2;
						this.box2 = null;
						this.ShowTypes();
					}
					else if(MenuBoxDisplay.One.Equals(this.display))
					{
						this.box2.InitOut();
					}
					else if(MenuBoxDisplay.Multi.Equals(this.display))
					{
						this.box.SetFocus();
					}
					else if(MenuBoxDisplay.Sequence.Equals(this.display))
					{
						this.box2.InitOut();
						this.box.SetFocus();
					}
				}
				else
				{
					this.screen.Close();
				}
			}
		}
		
		
		/*
		============================================================================
		Drag and drop functions
		============================================================================
		*/
		public void Dropped(DragInfo drag)
		{
			this.Refresh();
		}
		
		public bool DroppedOnCombatant(Combatant c, DragInfo drag)
		{
			if(this.dropGive)
			{
				if(drag.User != c && c.Inventory.GetAllowedCount(drag.Shortcut) != 0)
				{
					this.giveQuantity.Call(
						new QuantityData(this.screen.pauseGame, null, drag.Shortcut, 
							c.Inventory.GetAllowedQuantity(drag.Shortcut, -1), 
							c.Inventory.GetCount(drag.Shortcut), 
							0, drag.User.Inventory.GetMoney(0), drag.Shortcut.BuyPrice, 
							QuantitySelectionMode.Give, c.Inventory.Add, drag.User.Inventory.Remove));
				}
				return true;
			}
			else if(drag.UseOn(c, this.animateUse))
			{
				if(this.closeAfter)
				{
					if(this.closeAfterNoReturn)
					{
						this.screen.Clear();
					}
					this.screen.Close();
				}
				return true;
			}
			return false;
		}
		
		public bool DroppedToWorld(Vector3 position, DragInfo drag)
		{
			if(this.dropToWorld && drag.Shortcut != null && drag.Shortcut.IsDropable())
			{
				this.dropQuantity.Call(
					new QuantityData(this.screen.pauseGame, null, drag.Shortcut, drag.Shortcut.Quantity, 
						drag.User.Inventory.GetCount(drag.Shortcut), 
						0, drag.User.Inventory.GetMoney(0), drag.Shortcut.BuyPrice, 
						QuantitySelectionMode.Drop, null, drag.User.Inventory.Drop));
				return true;
			}
			return false;
		}
		
		public void ChoiceDropped(int index, GUIBox origin, DragInfo drag)
		{
			if(this.box2 == origin && 
				(drag.Shortcut is EquipShortcut || 
				drag.Shortcut is ItemShortcut || 
				drag.Shortcut is MoneyShortcut))
			{
				// drop not coming from combatant, e.g. item box
				if(drag.User == null)
				{
					drag.Origin.DroppedOnCombatant(this.screen.Combatant, drag);
				}
				// drop coming from other combatant
				else
				{
					// try unequipping if equipment
					if(drag.Shortcut is EquipShortcut)
					{
						drag.User.Equipment.Unequip(drag.Shortcut as EquipShortcut, drag.User.Inventory);
					}
					// remove/add to inventory only if different inventories
					if(drag.User.Inventory != this.screen.Combatant.Inventory)
					{
						drag.User.Inventory.Remove(drag.Shortcut, true, true);
						this.screen.Combatant.Inventory.Add(drag.Shortcut, true, true);
					}
				}
			}
		}
	}
}
