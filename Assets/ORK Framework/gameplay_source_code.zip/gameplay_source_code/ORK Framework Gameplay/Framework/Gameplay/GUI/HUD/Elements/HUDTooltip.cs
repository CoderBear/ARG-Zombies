
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class HUDTooltip : HUDElement
	{
		[ORKEditorHelp("Text", "The text that will be displayed.", "")]
		[ORKEditorInfo(separator=true, isTextArea=true, label=new string[] {
			"%n = name, %d = description, %i = icon, % = information (e.g. quantity, use costs)", 
			"%tn = type name, %td = type description, %ti = type icon"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		public string[] text = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		
		// text format
		[ORKEditorHelp("Line Spacing", "The space between text lines.", "")]
		[ORKEditorInfo("Text Formatting", "Define the appearance of the text, e.g. alignment, text/shadow color, font size/style.", "", 
			separatorForce=true)]
		public float lineSpacing = 10;
		
		[ORKEditorHelp("Text Alignment", "Select how the text will be aligned horizontally.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public TextAlignment alignment = TextAlignment.Left;
		
		[ORKEditorHelp("Line Alignment", "Select how text lines will be aligned vertically.\n" +
			"This is used to align text lines consisting of labels with different heights (e.g. text and icons).", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public VerticalTextAlignment vAlignment = VerticalTextAlignment.Bottom;
		
		[ORKEditorInfo(separator=true, endFoldout=true)]
		public TextFormat textFormat = TextFormat.Default;
		
		public HUDTooltip()
		{
			
		}
		
		
		/*
		============================================================================
		Create label functions
		============================================================================
		*/
		public override void CreateLabels(out List<BaseLabel> label, Rect displayBounds, 
			Combatant combatant)
		{
			if(ORK.GUI.TooltipContent != null)
			{
				string tmp = this.text[ORK.Game.Language];
				
				if(tmp.Contains("%t"))
				{
					IContentSimple typeContent = ORK.GUI.TooltipContent.GetTypeContent();
					if(typeContent != null)
					{
						tmp = tmp.Replace("%tn", typeContent.GetName()).
							Replace("%td", typeContent.GetDescription()).
							Replace("%ti", typeContent.GetIconTextCode());
					}
					else
					{
						tmp = tmp.Replace("%tn", "").
							Replace("%td", "").
							Replace("%ti", "");
					}
				}
				
				label = new MultiContent(
					TextHelper.ReplaceSpecials(tmp.
						Replace("%n", ORK.GUI.TooltipContent.GetName()).
						Replace("%d", ORK.GUI.TooltipContent.GetDescription()).
						Replace("%i", ORK.GUI.TooltipContent.GetIconTextCode()).
						Replace("%", ORK.GUI.TooltipContent.GetInfo(
							combatant != null ? combatant : ORK.Game.ActiveGroup.Leader))), 
					null, null, displayBounds, this.lineSpacing, 
					this.alignment, this.vAlignment, BoxHeightAdjustment.Auto, false, this.textFormat).label;
			}
			else
			{
				label = null;
			}
		}
		
		public override void CreateLabelsEditor(out List<BaseLabel> label, Rect displayBounds, 
			Combatant combatant)
		{
			Item item = ORK.Items.Get(0);
			string tmp = this.text[ORK.Game.Language];
			
			if(tmp.Contains("%t"))
			{
				IContentSimple typeContent = item.GetTypeContent();
				if(typeContent != null)
				{
					tmp = tmp.Replace("%tn", typeContent.GetName()).
						Replace("%td", typeContent.GetDescription()).
						Replace("%ti", typeContent.GetIconTextCode());
				}
				else
				{
					tmp = tmp.Replace("%tn", "").
						Replace("%td", "").
						Replace("%ti", "");
				}
			}
			
			label = new MultiContent(
				TextHelper.ReplaceSpecials(tmp.
					Replace("%n", item.GetName()).
					Replace("%d", item.GetDescription()).
					Replace("%i", item.GetIconTextCode()).
					Replace("%", item.GetInfo(combatant != null ? combatant : ORK.Game.ActiveGroup.Leader))), 
				null, null, displayBounds, this.lineSpacing, 
				this.alignment, this.vAlignment, BoxHeightAdjustment.Auto, false, this.textFormat).label;
		}
	}
}
