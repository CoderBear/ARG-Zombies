
using UnityEngine;
using ORKFramework;
using ORKFramework.Menu.Parts;
using System.Collections.Generic;

namespace ORKFramework.Menu
{
	public class InformationPage : BaseData
	{
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used GUI box.", "")]
		public bool useTitle = false;
		
		[ORKEditorHelp("Title", "The title of the information box.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitle", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] title;
		
		
		// information settings
		[ORKEditorHelp("Auto Update", "The information page will automatically be updated (i.e. recalculated) periodically.\n" +
			"Use this if you use information text codes that need regular updates (e.g. #time).", "")]
		[ORKEditorInfo(separator=true)]
		public bool autoUpdate = false;
		
		[ORKEditorHelp("Update Interval (s)", "The time in seconds between HUD updates.", "")]
		[ORKEditorLayout("autoUpdate", true, endCheckGroup=true)]
		public float updateInterval = 1;
		
		
		// information elements
		[ORKEditorHelp("Use HUD", "Use the information elements defined in a HUD.\n" +
			"Only the information elements of the HUD will be used, the rest of the HUD's settings are ignored.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useHUD = false;
		
		[ORKEditorHelp("HUD", "Select the HUD that will be used.\n" +
			"Only 'Information' type HUDs are allowed. Using any other HUD or a " +
			"'Information' type HUD without information elements result in an empty box.", "")]
		[ORKEditorInfo(ORKDataType.HUD, "type", HUDType.Information, true)]
		[ORKEditorLayout("useHUD", true)]
		public int hudID = 0;
		
		
		// elements
		[ORKEditorArray(false, "Add Information Element", "Adds an information element to the game info box.", "", 
			"Remove", "Removes this information element.", "", isMove=true, isCopy=true, 
			foldout=true, foldoutText=new string[] {"Information Element", 
				"Set the position, size, content and background image of this element.\n" +
				"The coordinates X=0, Y=0 are located at the upper left corner of the GUI box.", ""})]
		[ORKEditorInfo(instanceCallback="button:InformationPageToInformationHUD")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public HUDText[] informationElement;
		
		public InformationPage()
		{
			
		}
		
		public GUIBoxContent GetContent(IChoice parent)
		{
			PrecalcHUDContent content = new PrecalcHUDContent(
				this.useHUD ? 
					ORK.HUDs.Get(this.hudID).infoElement : 
					this.informationElement, HUDType.Information);
			if(this.autoUpdate)
			{
				content.SetAutoUpdate(this.updateInterval);
			}
			content.SetName(this.useTitle ? this.title[ORK.Game.Language] : "");
			content.controlInterface = parent;
			return content;
		}
	}
}
