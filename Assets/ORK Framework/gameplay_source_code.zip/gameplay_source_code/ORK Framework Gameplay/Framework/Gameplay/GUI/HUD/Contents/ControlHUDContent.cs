
using UnityEngine;
using ORKFramework;
using ORKFramework.Display;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ControlHUDContent : GUIBoxContent
	{
		private HUDSetting hudSetting;
		
		private HUDControl[] element;
		
		public List<InputKey> keys;
		
		public List<InputKey> keys2;
		
		
		// scroll
		private float scrollSize = 0;

		private float newHeight = 0;
		
		
		// new UI
		private GameObject bgObject;
		
		private GameObject fgObject;
		
		public ControlHUDContent(HUDSetting setting)
		{
			this.hudSetting = setting;
			this.element = this.hudSetting.controlElement;
			
			// init controls
			this.keys = new List<InputKey>();
			this.keys2 = new List<InputKey>();
			
			for(int i=0; i<this.element.Length; i++)
			{
				this.keys.Add(ORK.InputKeys.Get(this.element[i].keyID));
				if(HUDControlType.Joystick.Equals(this.element[i].type))
				{
					this.keys2.Add(ORK.InputKeys.Get(this.element[i].keyID2));
				}
				else
				{
					this.keys2.Add(null);
				}
			}
		}
		
		public override void Clear()
		{
			base.Clear();
			if(this.bgObject != null)
			{
				GameObject.Destroy(this.bgObject);
			}
			if(this.fgObject != null)
			{
				GameObject.Destroy(this.fgObject);
			}
		}

		public override void Tick()
		{
			base.Tick();
			if(this.box != null)
			{
				// interface tick
				if(this.box.Controlable && this.controlInterface != null && this.box.Focused)
				{
					this.controlInterface.Tick(this.box);
				}
				
				// control tick
				for(int i=0; i<this.element.Length; i++)
				{
					this.element[i].Tick(this, i);
				}
			}
		}
		
		public override void Closed()
		{
			if(this.element != null)
			{
				for(int i=0; i<this.element.Length; i++)
				{
					this.element[i].Close();
				}
			}
			if(this.controlInterface != null)
			{
				this.controlInterface.Closed(this.box);
			}
		}
		
		
		/*
		============================================================================
		Init functions
		============================================================================
		*/
		public override void Init(GUIBox box)
		{
			if(this.newContent || this.box == null)
			{
				this.box = box;
				
				this.CalculateContent(this.box.bounds.width - 
					(this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), false);
				
				this.newContent = false;
			}
		}
		
		private void CalculateContent(float baseWidth, bool recalced)
		{
			float contentHeight = 0;
			
			// display content
			if(this.element != null)
			{
				for(int i=0; i<this.element.Length; i++)
				{
					// update height
					float height = this.element[i].bounds.y + this.element[i].bounds.height;
					if(contentHeight < height)
					{
						contentHeight = height;
					}
				}
			}
			
			if(BoxHeightAdjustment.Auto.Equals(this.box.Settings.heightAdjustment) && 
				!this.box.forceSize)
			{
				this.box.bounds.height = contentHeight + this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w;
			}
			else if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				this.scrollRect = new Rect(this.box.Settings.boxPadding.x, this.box.Settings.boxPadding.y, 
					baseWidth, contentHeight);
			}
			
			this.contentBounds = new Rect(this.box.Settings.boxPadding.x, this.box.Settings.boxPadding.y, 
				this.box.bounds.width - (this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), 
				this.box.bounds.height - (this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w));
			
			if(!recalced && contentHeight > this.contentBounds.height && 
				BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				float scrollbarWidth = 0;
				if(ORK.GUI.IsNewUI)
				{
					if(this.box.Skins.scrollbarPrefab != null)
					{
						RectTransform rect = this.box.Skins.scrollbarPrefab.GetComponent<RectTransform>();
						if(rect != null)
						{
							scrollbarWidth = rect.sizeDelta.x;
						}
					}
				}
				else
				{
					scrollbarWidth = GUI.skin.verticalScrollbar.fixedWidth;
				}
				this.CalculateContent(baseWidth - (scrollbarWidth + this.box.Settings.scrollPadding), true);
			}
		}
		
		public override void CreateNewUI()
		{
			if(ORK.GUI.IsNewUI && 
				this.box.gameObject != null)
			{
				GameObject parent = this.CreatePanel();
				
				// display content
				for(int i=0; i<this.element.Length; i++)
				{
					this.element[i].CreateObjects(this.box, parent);
				}
				
				// background image
				if(this.hudSetting != null && this.bgObject == null && 
					this.hudSetting.showBackground && this.hudSetting.bgImage != null)
				{
					this.bgObject = this.CreateImage(this.hudSetting.bgImage, 
						this.hudSetting.bgRelative, this.hudSetting.bgRelativeTo, -1);
				}
				// foreground image
				if(this.hudSetting != null && this.fgObject == null && 
					this.hudSetting.showForeground && this.hudSetting.fgImage != null)
				{
					this.fgObject = this.CreateImage(this.hudSetting.fgImage, 
						this.hudSetting.fgRelative, this.hudSetting.fgRelativeTo, 1);
				}
			}
		}
		
		
		/*
		============================================================================
		Show GUI functions
		============================================================================
		*/
		public override void ShowBefore()
		{
			// background image
			if(this.hudSetting != null && 
				this.hudSetting.showBackground && this.hudSetting.bgImage != null)
			{
				if(this.hudSetting.bgRelative)
				{
					Vector2 tmp = GUIHelper.GetRectAnchor(this.box.windowRect, this.hudSetting.bgRelativeTo);
					this.hudSetting.bgImage.Show(tmp.x, tmp.y);
				}
				else
				{
					this.hudSetting.bgImage.Show(0, 0);
				}
			}
		}
		
		public override void ShowAfter()
		{
			// foreground image
			if(this.hudSetting != null && 
				this.hudSetting.showForeground && this.hudSetting.fgImage != null)
			{
				if(this.hudSetting.fgRelative)
				{
					Vector2 tmp = GUIHelper.GetRectAnchor(this.box.windowRect, this.hudSetting.fgRelativeTo);
					this.hudSetting.fgImage.Show(tmp.x, tmp.y);
				}
				else
				{
					this.hudSetting.fgImage.Show(0, 0);
				}
			}
		}

		public override void ShowWindow()
		{
			if(this.box.doFlash)
			{
				GUI.color = this.box.flashColor;
			}
			else
			{
				GUI.color = this.box.color;
			}
			
			Rect textBounds = this.box.bounds;
			textBounds.x = 0;
			textBounds.y = 0;
			if(BoxHeightAdjustment.Auto.Equals(this.box.Settings.heightAdjustment) && 
				this.newHeight > 0)
			{
				textBounds.height = this.newHeight;
			}
			
			GUI.BeginGroup(textBounds);
			
			textBounds.x += this.box.Settings.boxPadding.x;
			textBounds.y += this.box.Settings.boxPadding.y;
			textBounds.width -= (this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z);
			textBounds.height -= (this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w);
			
			if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				Rect scrollRect = new Rect(textBounds.x, textBounds.y, 
					textBounds.width - this.box.Settings.boxPadding.z, this.scrollSize);
				
				if(this.scrollSize > textBounds.height)
				{
					scrollRect.width -= GUI.skin.verticalScrollbar.fixedWidth + 1;
				}
				
				this.scroll = GUI.BeginScrollView(textBounds, this.scroll, scrollRect);
				GUI.BeginGroup(scrollRect);
				textBounds.width = scrollRect.width;
			}
			else
			{
				GUI.BeginGroup(textBounds);
			}
			
			this.newHeight = 0;
			
			// display content
			if(this.element != null)
			{
				for(int i=0; i<this.element.Length; i++)
				{
					// no flash > reset color
					this.box.SetGUIColor(this.element[i].noFlash);
					
					// show element
					this.element[i].Show();
					
					// update height
					float height = this.element[i].bounds.y + this.element[i].bounds.height;
					if(this.newHeight < height)
					{
						this.newHeight = height;
					}
				}
			}
			
			GUI.EndGroup();
			if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				GUI.EndScrollView();
				this.scrollSize = this.newHeight;
			}
			GUI.EndGroup();
			
			if(BoxHeightAdjustment.Auto.Equals(this.box.Settings.heightAdjustment))
			{
				this.newHeight += this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w;
				if(this.newHeight > 0 && !this.box.forceSize)
				{
					this.box.bounds.height = this.newHeight;
				}
			}
		}
	}
}
