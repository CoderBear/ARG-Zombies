
using UnityEngine;
using ORKFramework;
using ORKFramework.Menu;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class QuantityContent : GUIBoxContent
	{
		private QuantitySelection quantitySelection;
		
		// content
		private string topText = "";
		
		private string bottomText = "";
		
		private string quantityText = "";
		
		private MultiContent topContent;
		
		private MultiContent bottomContent;
		
		private MultiContent quantityContent;
		
		
		// buttons
		private ChoiceContent[] horizontal;
		
		private float[] horizontalTimeout = new float[2];

		private ChoiceContent[] vertical;
		
		private float[] verticalTimeout = new float[2];
		
		
		// choice
		private float choiceTimeout = 0;
		
		public QuantityContent(string topText, string quantityText, string bottomText, string name, IChoice ci)
		{
			this.controlInterface = ci;
			if(ci is QuantitySelection)
			{
				this.quantitySelection = ci as QuantitySelection;
			}
			this.SetContent(topText, quantityText, bottomText, name);
		}
		
		public void SetContent(string topText, string quantityText, string bottomText, string name)
		{
			this.topText = topText;
			this.quantityText = quantityText;
			this.bottomText = bottomText;
			this.SetName(name);
			
			this.newContent = true;
		}
		
		
		/*
		============================================================================
		Control functions
		============================================================================
		*/
		private void CheckTimeout(float[] timeout, ChoiceContent[] button)
		{
			for(int i=0; i<timeout.Length; i++)
			{
				if(timeout[i] > 0)
				{
					timeout[i] -= ORK.Core.GUITimeDelta;
				}
				button[i].Active = timeout[i] <= 0;
			}
		}
		
		public override void Tick()
		{
			base.Tick();
			if(this.horizontal != null)
			{
				this.CheckTimeout(this.horizontalTimeout, this.horizontal);
			}
			if(this.vertical != null)
			{
				this.CheckTimeout(this.verticalTimeout, this.vertical);
			}
			
			if(this.box != null && this.box.Controlable && 
				this.controlInterface != null && this.box.Focused && 
				!this.controlInterface.Tick(this.box))
			{
				if(!this.box.disableChoice)
				{
					if(ORK.InputKeys.Get(ORK.GameControls.acceptKey).GetButton())
					{
						this.OkPressed();
					}
					else if((Time.realtimeSinceStartup - this.choiceTimeout) > ORK.GameControls.cursorTimeout)
					{
						// vertical change
						if(!QuantityInputType.HorizontalButtons.Equals(this.quantitySelection.type))
						{
							float v = ORK.InputKeys.Get(ORK.GameControls.verticalAxis).GetAxis();
							if(v < -0.3)
							{
								this.box.Audio.PlayCursorMove();
								this.quantitySelection.ChangeQuantity(
									-this.quantitySelection.vertical.change, 
									this.quantitySelection.vertical.loop);
								this.choiceTimeout = Time.realtimeSinceStartup;
								this.verticalTimeout[1] = ORK.GameControls.cursorTimeout;
							}
							else if(v > 0.3)
							{
								this.box.Audio.PlayCursorMove();
								this.quantitySelection.ChangeQuantity(
									this.quantitySelection.vertical.change, 
									this.quantitySelection.vertical.loop);
								this.choiceTimeout = Time.realtimeSinceStartup;
								this.verticalTimeout[0] = ORK.GameControls.cursorTimeout;
							}
						}
						// horizontal change
						if(!QuantityInputType.VerticalButtons.Equals(this.quantitySelection.type))
						{
							float h = ORK.InputKeys.Get(ORK.GameControls.horizontalAxis).GetAxis();
							if(h > 0.3)
							{
								this.box.Audio.PlayCursorMove();
								this.quantitySelection.ChangeQuantity(
									this.quantitySelection.horizontal.change, 
									this.quantitySelection.horizontal.loop);
								this.choiceTimeout = Time.realtimeSinceStartup;
								this.horizontalTimeout[1] = ORK.GameControls.cursorTimeout;
							}
							else if(h < -0.3)
							{
								this.box.Audio.PlayCursorMove();
								this.quantitySelection.ChangeQuantity(
									-this.quantitySelection.horizontal.change, 
									this.quantitySelection.horizontal.loop);
								this.choiceTimeout = Time.realtimeSinceStartup;
								this.horizontalTimeout[0] = ORK.GameControls.cursorTimeout;
							}
						}
					}
				}
				
				if(ORK.InputKeys.Get(ORK.GameControls.cancelKey).GetButton())
				{
					this.CancelPressed();
				}
			}
		}
		
		public override void OkPressed()
		{
			ORK.InputKeys.ResetInputAxes();
			if(this.controlInterface != null)
			{
				this.box.Audio.PlayAccept();
				this.controlInterface.ChoiceSelected(0, this.box);
			}
		}
		
		public override void CancelPressed()
		{
			ORK.InputKeys.ResetInputAxes();
			if(this.controlInterface != null)
			{
				this.controlInterface.Canceled(this.box);
			}
		}
		
		public override void Closed()
		{
			if(this.controlInterface != null)
			{
				this.controlInterface.Closed(this.box);
			}
		}
		
		
		/*
		============================================================================
		Init functions
		============================================================================
		*/
		public override void Init(GUIBox box)
		{
			if(this.newContent)
			{
				this.box = box;
				
				this.CalculateContent(this.box.bounds.width - (this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), false);
				
				this.newContent = false;
			}
		}
		
		private void CalculateContent(float baseWidth, bool recalced)
		{
			Rect textBounds = new Rect(0, 0, baseWidth, 
				this.box.bounds.height - (this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w));
			
			// top text
			TextHelper.ReplaceSpecials(ref this.topText);
			this.topContent = new MultiContent(this.topText, null, null, textBounds, this.box.Settings.lineSpacing, 
				this.box.Settings.alignment, this.box.Settings.vAlignment, 
				this.box.Settings.heightAdjustment, 
				this.box.Settings.oneline, this.box.Settings.textFormat);
			
			if(this.topContent.size.y > 0)
			{
				textBounds.y = this.topContent.size.y + this.box.Settings.lineSpacing;
			}
			
			
			// create vertical buttons
			Vector2 verticalSize = Vector2.zero;
			if(!QuantityInputType.HorizontalButtons.Equals(this.quantitySelection.type) && 
				!this.quantitySelection.vertical.hideButtons)
			{
				if(this.vertical == null)
				{
					this.vertical = new ChoiceContent[2];
					this.vertical[0] = this.quantitySelection.vertical.increase[ORK.Game.Language].GetChoiceContent();
					this.vertical[1] = this.quantitySelection.vertical.decrease[ORK.Game.Language].GetChoiceContent();
				}
				
				for(int i=0; i<this.vertical.Length; i++)
				{
					this.vertical[i].isButton = this.quantitySelection.vertical.isButton;
					this.vertical[i].InitContent(textBounds, this.box.Settings.selectFirst, this.box.Settings.buttonSettings, null);
					this.vertical[i].SetToContentSize(this.box.Settings.buttonSettings.padding);
					this.vertical[i].CheckBiggestContent(ref verticalSize);
				}
				
				Vector2 newPos = new Vector2((textBounds.width - verticalSize.x) / 2, textBounds.y);
				for(int i=0; i<this.vertical.Length; i++)
				{
					this.vertical[i].buttonBounds.width = verticalSize.x;
					this.vertical[i].buttonBounds.height = verticalSize.y;
					this.vertical[i].SetPosition(newPos);
				}
				textBounds.y += verticalSize.y + this.box.Settings.lineSpacing;
			}
			
			
			// create quantity content
			TextHelper.ReplaceSpecials(ref this.quantityText);
			this.quantityContent = new MultiContent(this.quantityText, null, null, 
				textBounds, this.box.Settings.lineSpacing, 
				TextAlignment.Center, VerticalTextAlignment.Middle, 
				this.box.Settings.heightAdjustment, 
				this.box.Settings.oneline, this.box.Settings.textFormat);
			
			
			// horizontal buttons
			Vector2 horizontalSize = Vector2.zero;
			if(!QuantityInputType.VerticalButtons.Equals(this.quantitySelection.type) && 
				!this.quantitySelection.horizontal.hideButtons)
			{
				if(this.horizontal == null)
				{
					this.horizontal = new ChoiceContent[2];
					this.horizontal[0] = this.quantitySelection.horizontal.decrease[ORK.Game.Language].GetChoiceContent();
					this.horizontal[1] = this.quantitySelection.horizontal.increase[ORK.Game.Language].GetChoiceContent();
				}
				
				for(int i=0; i<this.horizontal.Length; i++)
				{
					this.horizontal[i].isButton = this.quantitySelection.horizontal.isButton;
					this.horizontal[i].InitContent(textBounds, this.box.Settings.selectFirst, this.box.Settings.buttonSettings, null);
					this.horizontal[i].SetToContentSize(this.box.Settings.buttonSettings.padding);
					this.horizontal[i].CheckBiggestContent(ref horizontalSize);
				}
				
				for(int i=0; i<this.horizontal.Length; i++)
				{
					this.horizontal[i].buttonBounds.width = horizontalSize.x;
					this.horizontal[i].buttonBounds.height = horizontalSize.y;
				}
				this.horizontal[0].SetPosition(new Vector2(0, textBounds.y));
				this.horizontal[1].SetPosition(new Vector2(textBounds.width - horizontalSize.x, textBounds.y));
			}
			
			if(this.quantityContent.size.y > 0 && 
				horizontalSize.y < this.quantityContent.size.y - this.quantityContent.startPos.y)
			{
				textBounds.y += this.quantityContent.size.y - this.quantityContent.startPos.y;
			}
			else
			{
				textBounds.y += horizontalSize.y;
			}
			
			if(this.vertical != null)
			{
				this.vertical[1].buttonBounds.y = textBounds.y + this.box.Settings.lineSpacing;
				textBounds.y += verticalSize.y + this.box.Settings.lineSpacing;
			}
			
			
			// bottom text
			if(this.bottomText != "")
			{
				textBounds.y += this.box.Settings.lineSpacing;
			}
			
			TextHelper.ReplaceSpecials(ref this.bottomText);
			this.bottomContent = new MultiContent(this.bottomText, null, null, 
				textBounds, this.box.Settings.lineSpacing, 
				this.box.Settings.alignment, this.box.Settings.vAlignment, 
				this.box.Settings.heightAdjustment, 
				this.box.Settings.oneline, this.box.Settings.textFormat);
			
			if(this.bottomContent.size.y > 0)
			{
				textBounds.y += this.bottomContent.size.y - this.bottomContent.startPos.y;
			}
			
			// box
			if(BoxHeightAdjustment.Auto.Equals(this.box.Settings.heightAdjustment) && 
				!this.box.forceSize)
			{
				this.box.bounds.height = textBounds.y + this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w;
			}
			else if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				this.scrollRect = new Rect(this.box.Settings.boxPadding.x, this.box.Settings.boxPadding.y, 
					baseWidth, textBounds.y);
			}
			
			this.contentBounds = new Rect(this.box.Settings.boxPadding.x, this.box.Settings.boxPadding.y, 
				this.box.bounds.width - (this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), 
				this.box.bounds.height - (this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w));
			
			
			if(!recalced && textBounds.y > textBounds.height && 
				BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				float scrollbarWidth = 0;
				if(ORK.GUI.IsNewUI)
				{
					if(this.box.Skins.scrollbarPrefab != null)
					{
						RectTransform rect = this.box.Skins.scrollbarPrefab.GetComponent<RectTransform>();
						if(rect != null)
						{
							scrollbarWidth = rect.sizeDelta.x;
						}
					}
				}
				else
				{
					scrollbarWidth = GUI.skin.verticalScrollbar.fixedWidth;
				}
				this.CalculateContent(baseWidth - (scrollbarWidth + this.box.Settings.scrollPadding), true);
			}
			else
			{
				this.CalculateButtons();
			}
		}
		
		public override void CreateNewUI()
		{
			if(ORK.GUI.IsNewUI && 
				this.box.gameObject != null)
			{
				GameObject parent = this.UpdatePanel();
				
				// create
				int index = 0;
				if(this.labelObject == null)
				{
					this.labelObject = new List<RectTransform>();
				}
				else
				{
					for(int i=0; i<this.labelObject.Count; i++)
					{
						if(this.labelObject[i] == null)
						{
							this.labelObject.RemoveAt(i--);
						}
						else
						{
							this.labelObject[i].SetParent(null, false);
						}
					}
				}
				
				// top content
				for(int i=0; i<this.topContent.label.Count; i++)
				{
					this.topContent.label[i].CreateObject(parent, this.labelObject, ref index);
				}
				
				// quantity content
				for(int i=0; i<this.quantityContent.label.Count; i++)
				{
					this.quantityContent.label[i].CreateObject(parent, this.labelObject, ref index);
				}
				
				// bottom content
				for(int i=0; i<this.bottomContent.label.Count; i++)
				{
					this.bottomContent.label[i].CreateObject(parent, this.labelObject, ref index);
				}
				
				// vertical buttons
				if(this.vertical != null)
				{
					for(int i=0; i<this.vertical.Length; i++)
					{
						this.vertical[i].CreateObject("Vertical", this.box, i, 
							this.box.Skins.buttonPrefab, parent, this.labelObject, ref index, 
							this.VerticalClicked);
					}
				}
				
				// horizontal buttons
				if(this.horizontal != null)
				{
					for(int i=0; i<this.horizontal.Length; i++)
					{
						this.horizontal[i].CreateObject("Horizontal", this.box, i, 
							this.box.Skins.buttonPrefab, parent, this.labelObject, ref index, 
							this.HorizontalClicked);
					}
				}
				
				// update labels
				for(int i=0; i<this.labelObject.Count; i++)
				{
					// remove empty
					if(this.labelObject[i] == null)
					{
						this.labelObject.RemoveAt(i--);
					}
					// remove exceeding labels
					else if(i >= index)
					{
						GameObject.Destroy(this.labelObject[i].gameObject);
						this.labelObject.RemoveAt(i--);
					}
				}
			}
		}
		
		public void VerticalClicked(int index)
		{
			if(!this.box.disableChoice)
			{
				this.verticalTimeout[index] = ORK.GameControls.cursorTimeout;
				if(index == 0)
				{
					this.box.Audio.PlayCursorMove();
					this.quantitySelection.ChangeQuantity(
						this.quantitySelection.vertical.change, 
						this.quantitySelection.vertical.loop);
				}
				else if(index == 1)
				{
					this.box.Audio.PlayCursorMove();
					this.quantitySelection.ChangeQuantity(
						-this.quantitySelection.vertical.change, 
						this.quantitySelection.vertical.loop);
				}
			}
		}
		
		public void HorizontalClicked(int index)
		{
			if(!this.box.disableChoice)
			{
				this.horizontalTimeout[index] = ORK.GameControls.cursorTimeout;
				if(index == 0)
				{
					this.box.Audio.PlayCursorMove();
					this.quantitySelection.ChangeQuantity(
						-this.quantitySelection.horizontal.change, 
						this.quantitySelection.horizontal.loop);
				}
				else if(index == 1)
				{
					this.box.Audio.PlayCursorMove();
					this.quantitySelection.ChangeQuantity(
						this.quantitySelection.horizontal.change, 
						this.quantitySelection.horizontal.loop);
				}
			}
		}
		
		
		/*
		============================================================================
		Show GUI functions
		============================================================================
		*/
		public override void ShowBefore()
		{
			
		}

		public override void ShowAfter()
		{
			
		}

		public override void ShowWindow()
		{
			if(this.box.doFlash)
			{
				GUI.color = this.box.flashColor;
			}
			else
			{
				GUI.color = this.box.color;
			}
			
			if(this.box.controlable && this.box.focusable && !this.box.Focused)
			{
				this.box.InactiveColor.SetColors();
			}
			
			GUIStyle textStyle = new GUIStyle(GUI.skin.label);
			textStyle.wordWrap = false;
			
			if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				GUI.skin.horizontalScrollbar = GUIStyle.none;
				this.scroll = GUI.BeginScrollView(this.contentBounds, this.scroll, this.scrollRect);
				GUI.BeginGroup(this.scrollRect);
			}
			else
			{
				GUI.BeginGroup(this.contentBounds);
			}
			
			// top content
			for(int i=0; i<this.topContent.label.Count; i++)
			{
				this.topContent.label[i].Show(textStyle);
			}
			
			// quantity content
			for(int i=0; i<this.quantityContent.label.Count; i++)
			{
				this.quantityContent.label[i].Show(textStyle);
			}
			
			// bottom content
			for(int i=0; i<this.bottomContent.label.Count; i++)
			{
				this.bottomContent.label[i].Show(textStyle);
			}
			
			
			// buttons
			textStyle = new GUIStyle(GUI.skin.label);
			textStyle.wordWrap = false;
			
			// vertical buttons
			if(this.vertical != null)
			{
				this.ShowButtons(this.vertical, this.verticalTimeout,  
					this.quantitySelection.vertical.change, 
					this.quantitySelection.vertical.loop, 
					0, textStyle);
			}
			
			// horizontal buttons
			if(this.horizontal != null)
			{
				this.ShowButtons(this.horizontal, this.horizontalTimeout, 
					this.quantitySelection.horizontal.change, 
					this.quantitySelection.horizontal.loop, 
					1, textStyle);
			}
			
			GUI.EndGroup();
			if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				GUI.EndScrollView();
			}
		}
		
		private void ShowButtons(ChoiceContent[] button, float[] timeout, int change, bool loop, int increase, GUIStyle textStyle)
		{
			for(int i=0; i<button.Length; i++)
			{
				// button and alpha
				if(!button[i].Active && GUI.color.a > this.box.Settings.choiceInactiveAlpha)
				{
					Color c = GUI.color;
					c.a = this.box.Settings.choiceInactiveAlpha;
					GUI.color = c;
				}
				if(!this.box.disableChoice && timeout[i] > 0 && 
					this.box.Skins.selectSkin && button[i].isButton)
				{
					GUI.skin = this.box.Skins.selectSkin;
				}
				
				if(button[i].isButton)
				{
					if(this.box.Button(button[i].buttonBounds, 
							this.box.Settings.buttonSettings.showButton, -1, false) && 
						(this.box.inPause || !ORK.Game.Paused))
					{
						if(!this.box.disableChoice)
						{
							timeout[i] = ORK.GameControls.cursorTimeout;
							if(i == increase)
							{
								this.box.Audio.PlayCursorMove();
								this.quantitySelection.ChangeQuantity(change, loop);
							}
							else
							{
								this.box.Audio.PlayCursorMove();
								this.quantitySelection.ChangeQuantity(-change, loop);
							}
						}
					}
				}
				
				GUI.BeginGroup(button[i].buttonBounds);
				
				// content
				if(!this.box.Settings.buttonSettings.alignIcons && button[i].Content.image != null)
				{
					textStyle.alignment = TextAnchor.MiddleLeft;
					GUI.Label(button[i].cImgBounds, new GUIContent(button[i].Content.image), textStyle);
					textStyle.alignment = TextAnchor.UpperLeft;
				}
				if(button[i].contentLabel != null && button[i].contentLabel.label.Count > 0)
				{
					for(int j=0; j<button[i].contentLabel.label.Count; j++)
					{
						button[i].contentLabel.label[j].Show(textStyle);
					}
				}
				
				if(timeout[i] > 0 && this.box.Skins.skin)
				{
					GUI.skin = this.box.Skins.skin;
				}
				
				// reset alpha
				GUI.color = this.box.color;
				
				GUI.EndGroup();
			}
		}
	}
}
