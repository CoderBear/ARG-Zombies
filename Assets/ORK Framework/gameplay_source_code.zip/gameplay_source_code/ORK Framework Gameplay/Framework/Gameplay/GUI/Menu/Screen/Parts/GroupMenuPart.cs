
using UnityEngine;
using ORKFramework;
using ORKFramework.Display;
using ORKFramework.Menu;
using System.Collections.Generic;

namespace ORKFramework.Menu.Parts
{
	[ORKEditorHelp("Group", "Displays the player group and allows changing members of the battle group.", "")]
	public class GroupMenuPart : BaseMenuPart, IChoice
	{
		// action menu
		[ORKEditorHelp("Show Action Box", "An action selection box is displayed.\n" +
			"If disabled, no action selection box is displayed, " +
			"but you can still use the actions using the defined keys.", "")]
		[ORKEditorInfo("Action Menu", "The action menu displays the group change actions that are available.\n" +
			"You can also hide the action menu and only use the keys assigned to the menu items to use the actions.", "")]
		public bool showActionBox = true;
		
		[ORKEditorHelp("Display (Action>Battle)", "Select the box display mode (Action to Battle Group or Battle Group to Action):\n" +
			"- Same: Actions and members use the same GUI box.\n" +
			"- One: Only one box will be displayed at a time. Actions and members use different GUI boxes.\n" +
			"- Multi: Multiple boxes are displayed at the same time. Actions and members use different GUI boxes.\n" +
			"- Sequence: Same as 'Multi', but the members will only be displayed when an action was selected " +
			"(or actions after a member was selected).", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("showActionBox", true, setDefault=true, defaultValue=MenuBoxDisplay.Multi)]
		public MenuBoxDisplay display = MenuBoxDisplay.Multi;
		
		[ORKEditorHelp("Action Box", "Select the GUI box used to display the action menu.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		[ORKEditorLayout("display", MenuBoxDisplay.Same, elseCheckGroup=true, endCheckGroup=true)]
		public int guiBoxID = 0;
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used action GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		[ORKEditorLayout(setDefault=true, defaultValue=false)]
		public bool useActionTitle = false;
		
		[ORKEditorHelp("Title", "The title of the box.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useActionTitle", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] actionTitle;
		
		// layout
		[ORKEditorInfo("Action Content Layout", "Define the layout of the action buttons.", "", 
			endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public ContentLayout actionContentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.None);
		
		// menu items
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Menu Item", "Adds a menu item to the action menu.", "", 
			"Remove", "Removes this menu item.", "", noRemoveCount=1, isCopy=true, isMove=true, 
			foldout=true, foldoutText=new string[] {"Menu Item", "Define the action, key and button of this menu item.", ""})]
		public GroupMenuItem[] menuItem = new GroupMenuItem[] {
			new GroupMenuItem(GroupMenuAction.Change), 
			new GroupMenuItem(GroupMenuAction.Remove)
		};
		
		
		
		// battle group box settings
		[ORKEditorHelp("Display (Battle>Non-Battle)", "Select the box display mode (battle group members to rest of the group):\n" +
			"- Same: Battle group members and the rest of the group use the same GUI box.\n" +
			"- One: Only one box will be displayed at a time. Battle group members and the rest of the group use different GUI boxes.\n" +
			"- Multi: Multiple boxes are displayed at the same time. Battle group members and the rest of the group use different GUI boxes.\n" +
			"- Sequence: Same as 'Multi', but the rest of the group will only be displayed when a battle group member was selected.", "")]
		[ORKEditorInfo("Battle Group Box Settings", "Define the content and layout of the battle group box.", "", 
			isEnumToolbar=true, toolbarWidth=75)]
		public MenuBoxDisplay displayText = MenuBoxDisplay.Multi;
		
		[ORKEditorHelp("Battle Group Box", "Select the GUI box used to display the current battle group members.\n" +
			"If 'Same' box display is selected, this box will also display the action menu.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		[ORKEditorLayout("displayText", MenuBoxDisplay.Same, elseCheckGroup=true, endCheckGroup=true)]
		public int guiBoxID2 = 0;
		
		[ORKEditorHelp("Add Back", "A back button will be added to the battle group list.", "")]
		[ORKEditorInfo(separator=true)]
		public bool addBack = false;
		
		[ORKEditorHelp("First Element", "The back button will be the first element in the battle group list.\n" +
			"If disabled, the back button will be the last element.", "")]
		[ORKEditorLayout("addBack", true, endCheckGroup=true)]
		public bool backFirst = false;
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used battle group GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useTitle = false;
		
		[ORKEditorHelp("Title", "The title of the battle group box.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {"%n = action name"})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitle", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] title;
		
		// layout
		[ORKEditorInfo("Group Content Layout", "Define the layout of the group buttons.\n" +
			"Used for empty and back buttons.", "", 
			endFoldout=true)]
		public ContentLayout contentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.None);
		
		// empty slot
		[ORKEditorInfo("Empty Slot", "Define the name, description and icon of empty group slot buttons.", "", 
			endFoldout=true, endFolds=2)]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public LanguageInfo[] emptySlot = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"Empty"});
		
		
		
		// non-battle group box settings
		[ORKEditorHelp("Non-Battle Group Box", "Select the GUI box used to display the the non-battle group members.\n" +
			"If 'Same' box display is selected, this box will also display the battle group members.", "")]
		[ORKEditorInfo("Non-Battle Group Box Settings", "Define the content and layout of the non-battle group box.", "", 
			isPopup=true, popupType=ORKDataType.GUIBox)]
		public int guiBoxID3 = 0;
		
		[ORKEditorHelp("Add Back", "A back button will be added to the non-battle group list.", "")]
		[ORKEditorInfo(separator=true)]
		public bool addBackNon = false;
		
		[ORKEditorHelp("First Element", "The back button will be the first element in the non-battle group list.\n" +
			"If disabled, the back button will be the last element.", "")]
		[ORKEditorLayout("addBackNon", true, endCheckGroup=true)]
		public bool backFirstNon = false;
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used non-battle group GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useTitleNon = false;
		
		[ORKEditorHelp("Title", "The title of the non-battle group box.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {"%n = action name"}, endFoldout=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitleNon", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] titleNon;
		
		
		// own combatant choice layout
		[ORKEditorHelp("Own Layout", "Override the default combatant choice layout (Menu Settings).", "")]
		[ORKEditorInfo("Combatant Choice Layout", "A group menu screen can override the " +
			"default default layout for combatant choices.", "")]
		public bool ownCombatantChoice = false;
		
		[ORKEditorInfo(endFoldout=true, separator=true)]
		[ORKEditorLayout("ownCombatantChoice", true, endCheckGroup=true, autoInit=true)]
		public CombatantChoiceLayout combatantChoice;
		
		
		// ingame
		private GUIBox box;
		
		private GUIBox box2;
		
		private GUIBox box3;
		
		private int current = 0;
		
		private int current2 = 0;
		
		private int current3 = 0;
		
		private bool exitFlag = false;
		
		private int nextBox = 0;
		
		
		// actions
		private ChoiceContent[] actionChoice;
		
		
		// battle members
		private ChoiceContent[] battleChoice;
		
		private List<Combatant> battleMembers;
		
		
		// non-battle members
		private ChoiceContent[] nonBattleChoice;
		
		private List<Combatant> nonBattleMembers;
		
		public GroupMenuPart()
		{
			
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return false;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return false;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public override bool Controlable
		{
			get{ return this.IsOpened;}
		}
		
		
		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public override bool IsOpened
		{
			get
			{
				return (this.box == null || this.box.FadedIn) && 
					(this.box2 == null || this.box2.FadedIn) && 
						(this.box3 == null || this.box3.FadedIn);
			}
		}
		
		public override bool IsClosed
		{
			get{ return this.box == null && this.box2 == null && this.box3 == null;}
		}
		
		public bool Tick(GUIBox origin)
		{
			if(this.box == origin)
			{
				for(int i=0; i<this.menuItem.Length; i++)
				{
					if(this.menuItem[i].useKey && 
						ORK.InputKeys.Get(this.menuItem[i].keyID).GetButton())
					{
						this.ChoiceSelected(i, origin);
						return true;
					}
				}
			}
			else if(this.box2 == origin)
			{
				for(int i=0; i<this.menuItem.Length; i++)
				{
					if(this.menuItem[i].useKey && 
						ORK.InputKeys.Get(this.menuItem[i].keyID).GetButton())
					{
						if(this.box != null)
						{
							this.box.Content.Selection = i;
						}
						else
						{
							this.current = i;
						}
						this.ChoiceSelected(this.current2, origin);
						return true;
					}
				}
			}
			return false;
		}
		
		
		/*
		============================================================================
		Choice creation functions
		============================================================================
		*/
		private void CreateActionChoices()
		{
			if(this.screen.Combatant != null)
			{
				this.actionChoice = new ChoiceContent[this.menuItem.Length];
				
				for(int i=0; i<this.menuItem.Length; i++)
				{
					if(GroupMenuAction.Change.Equals(this.menuItem[i].action))
					{
						this.actionChoice[i] = this.actionContentLayout.GetChoiceContent(this.menuItem[i].button);
					}
					else if(GroupMenuAction.Remove.Equals(this.menuItem[i].action))
					{
						this.actionChoice[i] = this.actionContentLayout.GetChoiceContent(ORK.MenuSettings.removeButton);
					}
					else if(GroupMenuAction.Screen.Equals(this.menuItem[i].action))
					{
						this.actionChoice[i] = this.actionContentLayout.GetChoiceContent(this.menuItem[i].button);
					}
					else if(GroupMenuAction.Back.Equals(this.menuItem[i].action))
					{
						this.actionChoice[i] = this.actionContentLayout.GetChoiceContent(ORK.MenuSettings.backButton);
					}
					else if(GroupMenuAction.Cancel.Equals(this.menuItem[i].action))
					{
						this.actionChoice[i] = this.actionContentLayout.GetChoiceContent(ORK.MenuSettings.cancelButton);
					}
				}
			}
			else
			{
				this.actionChoice = null;
			}
		}
		
		private void CreateBattleChoices()
		{
			this.battleMembers = null;
			this.battleChoice = null;
			
			if(this.screen.Combatant != null)
			{
				this.battleMembers = new List<Combatant>(this.screen.Combatant.Group.GetBattle());
				
				if(this.battleMembers != null)
				{
					List<ChoiceContent> cc = new List<ChoiceContent>();
					
					// back first
					if(this.addBack && this.backFirst)
					{
						cc.Add(this.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
						this.battleMembers.Insert(0, null);
					}
					
					// members
					for(int i=0; i<this.battleMembers.Count; i++)
					{
						if(this.battleMembers[i] != null)
						{
							ChoiceContent choice = this.GetCombatantLayout().GetChoiceContent(this.battleMembers[i]);
							choice.Active = (this.battleMembers.Count > 1 || 
									!GroupMenuAction.Remove.Equals(this.menuItem[this.current].action)) && 
								(!this.screen.Combatant.Group.IsLockedBattleMember(this.battleMembers[i]) || 
									(!GroupMenuAction.Change.Equals(this.menuItem[this.current].action) && 
									!GroupMenuAction.Remove.Equals(this.menuItem[this.current].action)));
							cc.Add(choice);
						}
					}
					
					int empty = ORK.GameSettings.maxBattleGroup - (cc.Count - (this.addBack && this.backFirst ? 1 : 0));
					for(int i=0; i<empty; i++)
					{
						ChoiceContent choice = this.contentLayout.GetChoiceContent(this.emptySlot);
						choice.Active = !GroupMenuAction.Screen.Equals(this.menuItem[this.current].action) && 
							!GroupMenuAction.Remove.Equals(this.menuItem[this.current].action);
						cc.Add(choice);
						this.battleMembers.Add(null);
					}
					
					// back last
					if(this.addBack && !this.backFirst)
					{
						cc.Add(this.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
						this.battleMembers.Add(null);
					}
					
					this.battleChoice = cc.ToArray();
				}
			}
		}
		
		private void CreateNonBattleChoices()
		{
			this.nonBattleMembers = null;
			this.nonBattleChoice = null;
			
			if(this.screen.Combatant != null)
			{
				this.nonBattleMembers = new List<Combatant>(this.screen.Combatant.Group.GetNonBattle());
				
				if(this.nonBattleMembers != null)
				{
					List<ChoiceContent> cc = new List<ChoiceContent>();
					
					// back first
					if(this.addBack && this.backFirst)
					{
						cc.Add(this.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
						this.nonBattleMembers.Insert(0, null);
					}
					
					// members
					for(int i=0; i<this.nonBattleMembers.Count; i++)
					{
						if(this.nonBattleMembers[i] != null && 
							!this.screen.Combatant.Group.IsHiddenMember(this.nonBattleMembers[i]))
						{
							ChoiceContent choice = this.GetCombatantLayout().GetChoiceContent(this.nonBattleMembers[i]);
							choice.Active = !GroupMenuAction.Remove.Equals(this.menuItem[this.current].action) && 
								!this.screen.Combatant.Group.IsLockedBattleMember(this.battleMembers[this.current2]);
							cc.Add(choice);
						}
					}
					
					// back last
					if(this.addBack && !this.backFirst)
					{
						cc.Add(this.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
						this.nonBattleMembers.Add(null);
					}
					
					this.nonBattleChoice = cc.ToArray();
				}
			}
		}
		
		
		/*
		============================================================================
		Screen functions
		============================================================================
		*/
		public override bool ShowFirstDescription()
		{
			if(this.box != null && this.actionChoice != null && 
				this.current >= 0 && this.current < this.actionChoice.Length)
			{
				this.screen.ShowDescription(
					this.actionChoice[this.current].description, 
					this.actionChoice[this.current].Content.text, 
					null);
				return true;
			}
			if(this.box2 != null && this.battleChoice != null && 
				this.current2 >= 0 && this.current2 < this.battleChoice.Length)
			{
				this.screen.ShowDescription(
					this.battleChoice[this.current2].description, 
					this.battleChoice[this.current2].Content.text, 
					this.battleMembers[this.current2]);
				return true;
			}
			if(this.box3 != null && this.nonBattleChoice != null && 
				this.current3 >= 0 && this.current3 < this.nonBattleChoice.Length)
			{
				this.screen.ShowDescription(
					this.nonBattleChoice[this.current3].description, 
					this.nonBattleChoice[this.current3].Content.text, 
					this.nonBattleMembers[this.current3]);
				return true;
			}
			return false;
		}
		
		public override bool FocusFirst()
		{
			if(this.box != null)
			{
				this.box.SetFocus();
				return true;
			}
			else if(this.box2 != null)
			{
				this.box2.SetFocus();
				return true;
			}
			else if(this.box3 != null)
			{
				this.box3.SetFocus();
				return true;
			}
			return false;
		}
		
		public override bool IsFocused()
		{
			return (this.box != null && this.box.Focused) || 
				(this.box2 != null && this.box2.Focused) || 
				(this.box3 != null && this.box3.Focused);
		}
		
		public override void Refresh()
		{
			if(this.box != null)
			{
				this.ShowActions();
			}
			else
			{
				this.CreateActionChoices();
			}
			if(this.box2 != null)
			{
				this.ShowBattleMembers();
			}
			else
			{
				this.CreateBattleChoices();
			}
			if(this.box3 != null)
			{
				this.ShowNonBattleMembers();
			}
			else
			{
				this.CreateNonBattleChoices();
			}
		}
		
		public override void Show(MenuScreen s)
		{
			this.nextBox = 0;
			this.screen = s;
			
			// battle members and non-battle members share the same box
			if(MenuBoxDisplay.Same.Equals(this.displayText))
			{
				this.guiBoxID2 = this.guiBoxID3;
			}
			// actions and battle members share the same box
			if(this.showActionBox && 
				MenuBoxDisplay.Same.Equals(this.display))
			{
				this.guiBoxID = this.guiBoxID2;
			}
			
			this.screen.Combatant.Group.Changed += this.GroupChanged;
			
			this.Show();
		}
		
		public override void ChangeCombatant(Combatant old)
		{
			old.Group.Changed -= this.GroupChanged;
			this.screen.Combatant.Group.Changed += this.GroupChanged;
			this.Refresh();
		}
		
		public override void CloseImmediate()
		{
			this.screen.Combatant.Group.Changed -= this.GroupChanged;
			if(this.box != null)
			{
				this.box.SetOutDone();
				this.box = null;
			}
			if(this.box2 != null)
			{
				this.box2.SetOutDone();
				this.box2 = null;
			}
			if(this.box3 != null)
			{
				this.box3.SetOutDone();
				this.box3 = null;
			}
		}
		
		public override void Close()
		{
			this.screen.Combatant.Group.Changed -= this.GroupChanged;
			this.exitFlag = true;
			if(this.box != null && !this.box.FadingOut && !this.box.FadedOut)
			{
				this.box.InitOut();
			}
			if(this.box2 != null && !this.box2.FadingOut && !this.box2.FadedOut)
			{
				this.box2.InitOut();
			}
			if(this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
			{
				this.box3.InitOut();
			}
		}
		
		public void GroupChanged(Group group)
		{
			this.Refresh();
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show()
		{
			if(!this.screen.RememberSelection)
			{
				this.current = 0;
				this.current2 = 0;
				this.current3 = 0;
			}
			
			// action choice and battle members
			if(this.showActionBox)
			{
				this.ShowActions();
				
				if(MenuBoxDisplay.Multi.Equals(this.display))
				{
					this.ShowBattleMembers();
				}
				
				this.box.SetFocus();
				this.SelectionChanged(this.current, this.box);
			}
			// only battle members
			else
			{
				this.ShowBattleMembers();
				this.box2.SetFocus();
				this.SelectionChanged(this.current2, this.box2);
			}
		}
		
		public void FocusGained(GUIBox origin)
		{
			if(this.box == origin && 
				!this.box.FadingOut && !this.box.FadedOut)
			{
				if(MenuBoxDisplay.Sequence.Equals(this.display))
				{
					if(this.box2 != null && !this.box2.FadingOut && !this.box2.FadedOut)
					{
						this.box2.InitOut();
					}
					if(this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
					{
						this.box3.InitOut();
					}
				}
				
				// non-battle box
				if(MenuBoxDisplay.Same.Equals(this.displayText) && 
					this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
				{
					this.box2 = this.box3;
					this.box3 = null;
					this.ShowBattleMembers();
				}
				else if(MenuBoxDisplay.Sequence.Equals(this.displayText) && 
					this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
				{
					this.box3.InitOut();
				}
				else if(MenuBoxDisplay.One.Equals(this.displayText) && 
					this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
				{
					this.nextBox = 4;
					this.box3.InitOut();
				}
				
				if(!this.box.FadingOut && this.actionChoice != null && 
					this.current >= 0 && this.current < this.actionChoice.Length)
				{
					this.screen.ShowDescription(
						this.actionChoice[this.current].description, 
						this.actionChoice[this.current].Content.text, 
						null);
				}
			}
			else if(this.box2 == origin && 
				!this.box2.FadingOut && !this.box2.FadedOut)
			{
				if(MenuBoxDisplay.Sequence.Equals(this.displayText) && 
					this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
				{
					this.box3.InitOut();
				}
				
				if(!this.box2.FadingOut && this.battleChoice != null && 
					this.current2 >= 0 && this.current2 < this.battleChoice.Length)
				{
					this.screen.ShowDescription(
						this.battleChoice[this.current2].description, 
						this.battleChoice[this.current2].Content.text, 
						this.battleMembers[this.current2]);
				}
			}
			else if(this.box3 == origin && 
				!this.box3.FadingOut && !this.box3.FadedOut)
			{
				if(!this.box3.FadingOut && this.nonBattleChoice != null && 
					this.current3 >= 0 && this.current3 < this.nonBattleChoice.Length)
				{
					this.screen.ShowDescription(
						this.nonBattleChoice[this.current3].description, 
						this.nonBattleChoice[this.current3].Content.text, 
						this.nonBattleMembers[this.current3]);
				}
			}
		}
		
		public void FocusLost(GUIBox origin)
		{
			
		}
		
		private void ShowActions()
		{
			this.CreateActionChoices();
			
			if(this.box == null || this.box.FadingOut || this.box.FadedOut)
			{
				this.box = ORK.GUIBoxes.Create(this.guiBoxID);
				this.box.inPause = this.screen.pauseGame;
				this.box.InitIn();
			}
			
			ValueHelper.Limit(ref this.current, 0, this.actionChoice.Length - 1);
			
			if(this.box.Content == null)
			{
				this.box.Content = new DialogueContent("", 
					this.useActionTitle ? this.actionTitle[ORK.Game.Language] : "", 
					this.actionChoice, this, this.current);
			}
			else
			{
				((DialogueContent)this.box.Content).Update("", 
					this.useActionTitle ? this.actionTitle[ORK.Game.Language] : "", 
					this.actionChoice, this.current, null, null);
			}
			if(this.box.Focused)
			{
				this.SelectionChanged(this.current, this.box);
			}
		}
		
		private void ShowBattleMembers()
		{
			if(!this.showActionBox)
			{
				this.CreateActionChoices();
			}
			this.CreateBattleChoices();
			
			if(this.box2 == null || this.box2.FadingOut || this.box2.FadedOut)
			{
				this.box2 = ORK.GUIBoxes.Create(this.guiBoxID2);
				this.box2.inPause = this.screen.pauseGame;
				this.box2.InitIn();
			}
			
			if(this.battleChoice == null)
			{
				this.current2 = 0;
			}
			else
			{
				ValueHelper.Limit(ref this.current2, 0, this.battleChoice.Length - 1);
			}
			
			if(this.box2.Content == null)
			{
				this.box2.Content = new DialogueContent("", this.GetTitle(), 
					this.battleChoice, this, this.current2, null, 
					this.GetCombatantLayout().GetStatusElements());
			}
			else
			{
				((DialogueContent)this.box2.Content).Update("", this.GetTitle(), 
					this.battleChoice, this.current2, null, 
					this.GetCombatantLayout().GetStatusElements());
			}
			
			if(MenuBoxDisplay.Multi.Equals(this.displayText))
			{
				this.ShowNonBattleMembers();
			}
			if(this.box2.Focused)
			{
				this.SelectionChanged(this.current2, this.box2);
			}
		}
		
		private void ShowNonBattleMembers()
		{
			this.CreateNonBattleChoices();
			
			if(this.box3 == null || this.box3.FadingOut || this.box3.FadedOut)
			{
				this.box3 = ORK.GUIBoxes.Create(this.guiBoxID3);
				this.box3.inPause = this.screen.pauseGame;
				this.box3.InitIn();
			}
			
			if(this.nonBattleChoice == null)
			{
				this.current3 = 0;
			}
			else
			{
				ValueHelper.Limit(ref this.current3, 0, this.nonBattleChoice.Length - 1);
			}
			
			if(this.box3.Content == null)
			{
				this.box3.Content = new DialogueContent("", this.GetTitleNonBattle(), 
					this.nonBattleChoice, this, this.current3, null, 
					this.GetCombatantLayout().GetStatusElements());
			}
			else
			{
				((DialogueContent)this.box3.Content).Update("", this.GetTitleNonBattle(), 
					this.nonBattleChoice, this.current3, null, 
					this.GetCombatantLayout().GetStatusElements());
			}
			if(this.box3.Focused)
			{
				this.SelectionChanged(this.current3, this.box3);
			}
		}
		
		private CombatantChoiceLayout GetCombatantLayout()
		{
			if(this.ownCombatantChoice)
			{
				return this.combatantChoice;
			}
			else
			{
				return ORK.MenuSettings.combatantChoice;
			}
		}
		
		private string GetTitle()
		{
			if(this.useTitle)
			{
				if(this.actionChoice != null && 
					this.current >= 0 && this.current < this.actionChoice.Length && 
					!GroupMenuAction.Back.Equals(this.menuItem[this.current].action) && 
					!GroupMenuAction.Cancel.Equals(this.menuItem[this.current].action))
				{
					return this.title[ORK.Game.Language].Replace("%n", this.actionChoice[this.current].Content.text);
				}
				else
				{
					return this.title[ORK.Game.Language].Replace("%n", "");
				}
			}
			return "";
		}
		
		private string GetTitleNonBattle()
		{
			if(this.useTitle)
			{
				if(this.actionChoice != null && 
					this.current >= 0 && this.current < this.actionChoice.Length && 
					!GroupMenuAction.Back.Equals(this.menuItem[this.current].action) && 
					!GroupMenuAction.Cancel.Equals(this.menuItem[this.current].action))
				{
					return this.titleNon[ORK.Game.Language].Replace("%n", this.actionChoice[this.current].Content.text);
				}
				else
				{
					return this.titleNon[ORK.Game.Language].Replace("%n", "");
				}
			}
			return "";
		}
		
		public void Closed(GUIBox origin)
		{
			if(this.exitFlag)
			{
				if(this.box == origin)
				{
					this.box = null;
				}
				else if(this.box2 == origin)
				{
					this.box2 = null;
				}
				else if(this.box3 == origin)
				{
					this.box3 = null;
				}
				if(this.box == null && this.box2 == null && this.box3 == null)
				{
					this.exitFlag = false;
				}
			}
			else
			{
				// action switch to battle members
				if(this.box == origin)
				{
					this.box = null;
					
					if(MenuBoxDisplay.One.Equals(this.display))
					{
						this.ShowBattleMembers();
						this.box2.SetFocus();
						this.SelectionChanged(this.current2, this.box2);
					}
				}
				// battle members
				else if(this.box2 == origin)
				{
					this.box2 = null;
					
					if(this.nextBox == 3 && MenuBoxDisplay.One.Equals(this.displayText))
					{
						this.ShowNonBattleMembers();
					}
					else if(this.nextBox != 3 && this.showActionBox && 
						MenuBoxDisplay.One.Equals(this.display))
					{
						this.ShowActions();
					}
				}
				// non-battle members
				else if(this.box3 == origin)
				{
					this.box3 = null;
					
					if(this.nextBox == 2 && 
						MenuBoxDisplay.One.Equals(this.displayText))
					{
						this.ShowBattleMembers();
						this.box2.SetFocus();
						this.SelectionChanged(this.current2, this.box2);
					}
					else if(this.nextBox == 4 && 
						MenuBoxDisplay.One.Equals(this.displayText))
					{
						this.ShowBattleMembers();
						if(this.box != null)
						{
							this.box.SetFocus();
						}
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Selection functions
		============================================================================
		*/
		public void ChoiceSelected(int index, GUIBox origin)
		{
			// actions
			if(this.box == origin && this.actionChoice != null && 
				index >= 0 && index < this.actionChoice.Length)
			{
				if(this.current != index)
				{
					this.SelectionChanged(index, origin);
				}
				
				this.current = index;
				
				if(GroupMenuAction.Back.Equals(this.menuItem[this.current].action) || 
					GroupMenuAction.Cancel.Equals(this.menuItem[this.current].action))
				{
					this.Cancel(origin);
				}
				else
				{
					this.nextBox = 2;
					if(MenuBoxDisplay.Same.Equals(this.display))
					{
						this.box2 = this.box;
						this.box = null;
						this.ShowBattleMembers();
						this.box2.SetFocus();
						this.SelectionChanged(this.current2, this.box2);
					}
					else if(MenuBoxDisplay.One.Equals(this.display))
					{
						this.box.InitOut();
					}
					else if(MenuBoxDisplay.Multi.Equals(this.display))
					{
						this.box2.SetFocus();
					}
					else if(MenuBoxDisplay.Sequence.Equals(this.display))
					{
						this.ShowBattleMembers();
						this.box2.SetFocus();
						this.SelectionChanged(this.current2, this.box2);
					}
				}
			}
			// battle members
			else if(this.box2 == origin && this.battleChoice != null && 
				index >= 0 && index < this.battleChoice.Length)
			{
				if(this.current2 != index)
				{
					this.SelectionChanged(index, origin);
				}
				this.current2 = index;
				
				if(this.addBack && 
					((this.backFirst && this.current2 == 0) || 
					(!this.backFirst && this.current2 == this.battleChoice.Length - 1)))
				{
					this.Cancel(origin);
				}
				else
				{
					if(GroupMenuAction.Remove.Equals(this.menuItem[this.current].action) || 
						GroupMenuAction.Screen.Equals(this.menuItem[this.current].action))
					{
						this.menuItem[this.current].Use(this.screen, 
							this.battleMembers[this.current2], null);
					}
					else
					{
						this.nextBox = 3;
						if(MenuBoxDisplay.Same.Equals(this.displayText))
						{
							this.box3 = this.box2;
							this.box2 = null;
							this.ShowNonBattleMembers();
						}
						else if(MenuBoxDisplay.One.Equals(this.displayText))
						{
							this.box2.InitOut();
						}
						else if(MenuBoxDisplay.Multi.Equals(this.displayText))
						{
							this.box3.SetFocus();
						}
						else if(MenuBoxDisplay.Sequence.Equals(this.displayText))
						{
							this.ShowNonBattleMembers();
						}
					}
				}
			}
			// non-battle members
			else if(this.box3 == origin && this.nonBattleChoice != null && 
				index >= 0 && index < this.nonBattleChoice.Length)
			{
				if(this.current3 != index)
				{
					this.SelectionChanged(index, origin);
				}
				this.current3 = index;
				
				if(this.nonBattleMembers[this.current3] == null)
				{
					this.Cancel(origin);
				}
				else
				{
					this.menuItem[this.current].Use(this.screen, 
						this.battleMembers[this.current2], this.nonBattleMembers[this.current3]);
					this.Cancel(origin);
				}
			}
		}
		
		public void SelectionChanged(int index, GUIBox origin)
		{
			// actions
			if(this.box == origin)
			{
				this.current = index;
				
				if(this.actionChoice != null && 
					this.current >= 0 && this.current < this.actionChoice.Length)
				{
					this.screen.ShowDescription(
						this.actionChoice[this.current].description, 
						this.actionChoice[this.current].Content.text, 
						null);
				}
				else
				{
					this.screen.ShowDescription("", "", null);
				}
				
				if(MenuBoxDisplay.Multi.Equals(this.display))
				{
					this.ShowBattleMembers();
				}
			}
			// battle members
			else if(this.box2 == origin)
			{
				this.current2 = index;
				
				if(this.battleChoice != null && 
					this.current2 >= 0 && this.current2 < this.battleChoice.Length)
				{
					this.screen.ShowDescription(
						this.battleChoice[this.current2].description, 
						this.battleChoice[this.current2].Content.text, 
						this.battleMembers[this.current2]);
				}
				else
				{
					this.screen.ShowDescription("", "", null);
				}
				
				if(MenuBoxDisplay.Multi.Equals(this.displayText))
				{
					this.ShowNonBattleMembers();
				}
			}
			// non-battle members
			else if(this.box3 == origin)
			{
				this.current3 = index;
				
				if(this.nonBattleChoice != null && 
					this.current3 >= 0 && this.current3 < this.nonBattleChoice.Length)
				{
					this.screen.ShowDescription(
						this.nonBattleChoice[this.current3].description, 
						this.nonBattleChoice[this.current3].Content.text, 
						this.nonBattleMembers[this.current3]);
				}
				else
				{
					this.screen.ShowDescription("", "", null);
				}
			}
		}
		
		public void Canceled(GUIBox origin)
		{
			origin.Audio.PlayCancel();
			this.Cancel(origin);
		}
		
		private void Cancel(GUIBox origin)
		{
			// actions
			if(this.box == origin)
			{
				this.screen.Close();
			}
			// battle members
			else if(this.box2 == origin)
			{
				if(this.showActionBox)
				{
					this.nextBox = 1;
					if(MenuBoxDisplay.Same.Equals(this.display))
					{
						this.box = this.box2;
						this.box2 = null;
						this.ShowActions();
						
						if(this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
						{
							this.box3.InitOut();
						}
					}
					else if(MenuBoxDisplay.One.Equals(this.display))
					{
						this.box2.InitOut();
						
						if(this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
						{
							this.box3.InitOut();
						}
					}
					else if(MenuBoxDisplay.Multi.Equals(this.display))
					{
						this.box.SetFocus();
					}
					else if(MenuBoxDisplay.Sequence.Equals(this.display))
					{
						this.box2.InitOut();
						this.box.SetFocus();
					}
				}
				else
				{
					this.screen.Close();
				}
			}
			// non-battle members
			else if(this.box3 == origin)
			{
				this.nextBox = 2;
				if(MenuBoxDisplay.Same.Equals(this.displayText))
				{
					this.box2 = this.box3;
					this.box3 = null;
					this.ShowBattleMembers();
				}
				else if(MenuBoxDisplay.One.Equals(this.displayText))
				{
					this.box3.InitOut();
				}
				else if(MenuBoxDisplay.Multi.Equals(this.displayText))
				{
					this.box2.SetFocus();
				}
				else if(MenuBoxDisplay.Sequence.Equals(this.displayText))
				{
					this.box3.InitOut();
					this.box2.SetFocus();
				}
			}
		}
	}
}
