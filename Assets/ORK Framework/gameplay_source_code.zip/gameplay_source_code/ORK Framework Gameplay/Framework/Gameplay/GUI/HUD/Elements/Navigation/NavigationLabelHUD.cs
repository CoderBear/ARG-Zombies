
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Display
{
	public class NavigationLabelHUD : BaseData
	{
		[ORKEditorHelp("Bounds", "Set position (X, Y) and size (W, H) of this info label.\n" +
			"The position X=0, Y=0 is at the upper left corner of the HUD element's bounds.", "")]
		public Rect bounds = new Rect(0, 0, 20, 20);
		
		[ORKEditorHelp("Anchor", "Select the anchor of the info label.\n" +
			"E.g. 'Upper Left' will place the upper left corner of the info label at the defined position, " +
			"'Lower Right' will place the lower right corner of the image at the defind position.", "")]
		public TextAnchor anchor = TextAnchor.UpperLeft;
		
		[ORKEditorHelp("Relative To", "Select the the corner of the shortcut's bounds the info label will be relative to.", "")]
		public TextAnchor relativeTo = TextAnchor.UpperLeft;
		
		
		// content
		[ORKEditorHelp("Show Image", "Display an image instead of a text.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useImage = false;
		
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("useImage", true, autoInit=true)]
		public BaseImage image;
		
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public StatusTextHUD text = new StatusTextHUD();
		
		public NavigationLabelHUD()
		{
			
		}
		
		public void Create(ref List<BaseLabel> label, Rect labelBounds, IContent info)
		{
			if(this.useImage)
			{
				ImageLabel img = this.image.Create(this.bounds);
				
				if(img != null)
				{
					// move to anchor positions
					Rect tmpBounds = new Rect(0, 0, this.bounds.width, this.bounds.height);
					Vector2 tmp = GUIHelper.GetRectAnchor(labelBounds, this.relativeTo);
					tmpBounds.x += (tmp.x - labelBounds.x);
					tmpBounds.y += (tmp.y - labelBounds.y);
					GUIHelper.GetRectAnchor(ref tmpBounds, -tmpBounds.width, -tmpBounds.height, this.anchor);
					img.ChangeX(tmpBounds.x);
					img.ChangeY(tmpBounds.y);
					
					label.Add(img);
				}
			}
			else
			{
				MultiContent mc = new MultiContent(
					TextHelper.ReplaceSpecials(this.GetText(info)), 
					null, null, this.bounds, this.text.lineSpacing, this.text.alignment, 
					this.text.vAlignment, BoxHeightAdjustment.Auto, false, this.text.textFormat);
				
				// move to anchor positions
				Rect tmpBounds = new Rect(0, 0, this.bounds.width, this.bounds.height);
				Vector2 tmp = GUIHelper.GetRectAnchor(labelBounds, this.relativeTo);
				tmpBounds.x += (tmp.x - labelBounds.x);
				tmpBounds.y += (tmp.y - labelBounds.y);
				GUIHelper.GetRectAnchor(ref tmpBounds, -tmpBounds.width, -tmpBounds.height, this.anchor);
				mc.ChangePosition(tmpBounds.x, tmpBounds.y);
				
				label.AddRange(mc.label);
			}
		}
		
		private string GetText(IContent info)
		{
			if(this.text.text[ORK.Game.Language].Contains("%"))
			{
				if(info != null)
				{
					return this.text.text[ORK.Game.Language].
						Replace("%n", info.GetName()).
						Replace("%d", info.GetDescription()).
						Replace("%i", info.GetIconTextCode());
				}
				else
				{
					return this.text.text[ORK.Game.Language].
						Replace("%n", "").
						Replace("%d", "").
						Replace("%i", "");
				}
			}
			else
			{
				return this.text.text[ORK.Game.Language];
			}
		}
	}
}
