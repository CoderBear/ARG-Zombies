
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class DefAttrHUD : BaseData
	{
		// attribute group
		[ORKEditorHelp("Attribute Group", "Select the defence attribute group that will be displayed.", "")]
		[ORKEditorInfo(ORKDataType.DefenceAttributes)]
		public int id = 0;
		
		[ORKEditorHelp("Group Information", "The name, description and icon displayed will be from the selected attribute group.\n" +
			"If disabled, the information of a selected attribute of the group (or a list of all attributes) will be displayed.", "")]
		public bool groupInfo = false;
		
		// data origin
		[ORKEditorHelp("Value Origin", "Select where the displayed value will come from:\n" +
			"- Current: The current value of the defence attributes.\n" +
			"- Preview: The preview value of the defence attributes. If no preview is available, the current value is used instead.\n" +
			"- Preview Hide: The preview value of the defence attributes. Hidden if no preview is available.\n" +
			"- Preview Hide No Change: The preview value of the defence attributes. Only hides values if there is no change to the current value." +
			"A preview value displays how the defence attributes will change if a selected equipment would be equipped. " +
			"Preview values are only available for player group members.", "")]
		[ORKEditorLayout("groupInfo", false, setDefault=true, defaultValue=HUDStatusOrigin.Current)]
		public HUDStatusOrigin origin = HUDStatusOrigin.Current;
		
		[ORKEditorInfo("Positive Change Text Format", "Define the appearance of the text for a positive change, " +
			"e.g. color, shadow, font size.", "", endFoldout=true)]
		[ORKEditorLayout("origin", HUDStatusOrigin.Current, elseCheckGroup=true)]
		public TextFormat previewPositiveFormat = TextFormat.Default;
		
		[ORKEditorInfo("Negative Change Text Format", "Define the appearance of the text for a negative change, " +
			"e.g. color, shadow, font size.", "", endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public TextFormat previewNegativeFormat = TextFormat.Default;
		
		
		// list
		[ORKEditorHelp("List All", "All attributes of the selected group will be listed.\n" +
			"If disabled, only the selected attribute of the group will be displayed.", "")]
		public bool list = false;
		
		[ORKEditorHelp("Offset", "The offset of each listed attribute.", "")]
		[ORKEditorLayout("list", true)]
		public Vector2 off = new Vector2(0, 30);
		
		[ORKEditorHelp("Set Size", "Set the size of the individual defence attribute manually.\n" +
			"If disabled, the size defined by the bounds is used.", "")]
		public bool setSize = false;
		
		[ORKEditorHelp("Size", "The width (X) and height (Y) of each defence attribute.", "")]
		[ORKEditorLayout("setSize", true, endCheckGroup=true)]
		public Vector2 size = new Vector2(100, 20);
		
		
		// single attribute
		[ORKEditorHelp("Attribute", "Select the attribute that will be displayed.", "")]
		[ORKEditorInfo(ORKDataType.DefenceAttributes, idFieldName="id")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public int id2 = 0;
		
		
		// text
		[ORKEditorInfo(separator=true, label=new string[] {
			"%n = name, %d = description, %i = icon", 
			"% = current value (not available for group info)", 
			"%c = change between current and preview value (not available for group info)"
		})]
		public StatusTextHUD text = new StatusTextHUD();
		
		public DefAttrHUD()
		{
			
		}
		
		
		/*
		============================================================================
		Create label functions
		============================================================================
		*/
		public void CreateLabels(out List<BaseLabel> label, Combatant combatant, bool isBestiary, Rect bounds)
		{
			label = new List<BaseLabel>();
			
			if(this.groupInfo)
			{
				label = new MultiContent(
					TextHelper.ReplaceSpecials(this.text.text[ORK.Game.Language].
						Replace("%n", ORK.DefenceAttributes.GetName(this.id)).
						Replace("%d", ORK.DefenceAttributes.GetDescription(this.id)).
						Replace("%i", TextCode.DefenceAttributeIcon + this.id + "#").
						Replace("%", "")), 
					null, null, bounds, this.text.lineSpacing, this.text.alignment, 
					this.text.vAlignment, BoxHeightAdjustment.Auto, false, this.text.textFormat).label;
			}
			else if(this.list)
			{
				for(int i=0; i<ORK.DefenceAttributes.AttributeCount(this.id); i++)
				{
					this.CreateAttribute(ref label, combatant, isBestiary, i, 
						new Rect(this.off.x * i, this.off.y * i, 
							this.setSize ? this.size.x : bounds.width, 
							this.setSize ? this.size.y : bounds.height));
				}
			}
			else
			{
				this.CreateAttribute(ref label, combatant, isBestiary, this.id2, bounds);
			}
		}
		
		private void CreateAttribute(ref List<BaseLabel> label, Combatant combatant, bool isBestiary, 
			int index, Rect bounds)
		{
			int change = 0;
			float value = 0;
			
			if(HUDStatusOrigin.Current.Equals(this.origin))
			{
				value = combatant.Status.GetDefenceAttribute(this.id).GetValue(index);
			}
			else if(HUDStatusOrigin.Preview.Equals(this.origin))
			{
				if(combatant.Status.PreviewAvailable)
				{
					value = combatant.Status.GetDefenceAttribute(this.id).GetPreviewValue(index);
					change = value.CompareTo(combatant.Status.GetDefenceAttribute(this.id).GetValue(index));
				}
				else
				{
					value = combatant.Status.GetDefenceAttribute(this.id).GetValue(index);
				}
			}
			else if(HUDStatusOrigin.PreviewHide.Equals(this.origin))
			{
				if(combatant.Status.PreviewAvailable)
				{
					value = combatant.Status.GetDefenceAttribute(this.id).GetPreviewValue(index);
					change = value.CompareTo(combatant.Status.GetDefenceAttribute(this.id).GetValue(index));
				}
				else
				{
					return;
				}
			}
			else if(HUDStatusOrigin.PreviewHideNoChange.Equals(this.origin))
			{
				if(combatant.Status.PreviewAvailable)
				{
					value = combatant.Status.GetDefenceAttribute(this.id).GetPreviewValue(index);
					
					if(value == combatant.Status.GetDefenceAttribute(this.id).GetValue(index))
					{
						return;
					}
					
					change = value.CompareTo(combatant.Status.GetDefenceAttribute(this.id).GetValue(index));
				}
				else
				{
					return;
				}
			}
			
			int previewChange = (int)(combatant.Status.GetDefenceAttribute(this.id).GetPreviewValue(index) - 
				combatant.Status.GetDefenceAttribute(this.id).GetValue(index));
			string tmpText = "";
			
			if(!isBestiary || combatant.Bestiary == null || combatant.Bestiary.IsComplete || 
				combatant.Bestiary.status.defenceAttribute[this.id].attribute[index])
			{
				tmpText = TextHelper.ReplaceSpecials(this.text.text[ORK.Game.Language].
					Replace("%n", ORK.DefenceAttributes.GetName(this.id, index)).
					Replace("%d", ORK.DefenceAttributes.GetDescription(this.id, index)).
					Replace("%i", TextCode.DefenceAttributeSubIcon + this.id + "#" + index + "#").
					Replace("%c", previewChange.ToString()).
					Replace("%", value.ToString()));
			}
			else
			{
				tmpText = TextHelper.ReplaceSpecials(this.text.text[ORK.Game.Language].
					Replace("%n", ORK.DefenceAttributes.GetName(this.id, index)).
					Replace("%d", ORK.DefenceAttributes.GetDescription(this.id, index)).
					Replace("%i", TextCode.DefenceAttributeSubIcon + this.id + "#" + index + "#").
					Replace("%c", previewChange.ToString()).
					Replace("%", ORK.GameSettings.bestiary.defenceAttributeText[ORK.Game.Language]));
			}
			
			label.AddRange(new MultiContent(tmpText, null, null, bounds, 
				this.text.lineSpacing, this.text.alignment, 
				this.text.vAlignment, BoxHeightAdjustment.Auto, false, 
				change > 0 ? 
				this.previewPositiveFormat : 
					(change < 0 ? 
						this.previewNegativeFormat : 
						this.text.textFormat)).label);
		}
	}
}
