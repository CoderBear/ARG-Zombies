
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class MouseTouchControl : BaseData
	{
		[ORKEditorHelp("Use Click", "Mouse clicks are used as input method.", "")]
		[ORKEditorInfo("Mouse/Touch Control", "Input settings for mouse or touch control.", "", separatorForce=true)]
		public bool useClick = false;
	
		[ORKEditorHelp("Mouse Button", "Set which mouse button is used as input.\n" +
			"- 0: left mouse button\n" +
			"- 1: right mouse button\n" +
			"- 2: middle mouse button", "")]
		[ORKEditorLayout("useClick", true, endCheckGroup=true)]
		public int mouseClick = 0;
		
		[ORKEditorHelp("Use Touch", " A touch is used as input method.", "")]
		public bool useTouch = false;
		
		[ORKEditorHelp("Touch Count", "Set the number of fingers used for touch input.\n" +
			"E.g.: 1 is one finger, 2 is two fingers, etc.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout("useTouch", true, endCheckGroup=true)]
		public int touchCount = 1;
		
		[ORKEditorHelp("Click Count", "The amount of clicks/taps used to trigger the input.\n" +
			"E.g.: 1 is a single click/tap, 2 is a double click/tap.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout(new string[] {"useClick", "useStart"}, 
			new System.Object[] {true, true}, needed=Needed.One, endCheckGroup=true)]
		public int clickCount = 1;
		
		[ORKEditorHelp("All Modes", "The input will happen at start, move and end of the mouse/touch interaction.", "")]
		[ORKEditorLayout(new string[] {"useClick", "useTouch"}, 
			new System.Object[] {true, true}, needed=Needed.One)]
		public bool allModes = false;
		
		[ORKEditorHelp("Mode", "Select when the input will happen.\n" +
			"- Start: When the mouse is clicked or the touch first occurs.\n" +
			"- Move: When the mouse/finger(s) is moved.\n" +
			"- End: When the mouse/touch is released.\n" +
			"- Hold: When the mouse/finger(s) is hold down " +
			"(i.e. the whole time between 'Start' and 'End')", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("allModes", false, endCheckGroup=true, endGroups=2)]
		public MouseTouch mode = MouseTouch.Start;
		
		
		// ingame
		private int count = 0;
	
		private float lastClickTime = 0;
		
		private Vector3 lastPosition = Vector3.zero;
	
		private Vector3 lastChange = Vector3.zero;
	
		private bool isPressed = false;
		
		
		// new
		private List<int> fingerIDs = new List<int>();
		
		public MouseTouchControl()
		{
			
		}
		
		public MouseTouchControl(bool active)
		{
			this.useClick = active;
			this.useTouch = active;
		}
		
		public MouseTouchControl(bool uc, int mc, bool ut, int tc, int cc, MouseTouch mo)
		{
			this.useClick = uc;
			this.mouseClick = mc;
			this.useTouch = ut;
			this.touchCount = tc;
			this.clickCount = cc;
			this.mode = mo;
		}
		
		public void Clear()
		{
			this.isPressed = false;
		}
		
		
		/*
		============================================================================
		Control handling functions
		============================================================================
		*/
		public bool Active()
		{
			return this.useClick || this.useTouch;
		}
		
		
		/*
		============================================================================
		Control handling functions
		============================================================================
		*/
		public Vector3 GetLastChange()
		{
			return this.lastChange;
		}
		
		public bool Interacted(ref Vector3 point)
		{
			// click count
			if(this.useClick && Input.GetMouseButtonDown(this.mouseClick))
			{
				if((Time.time - this.lastClickTime) > ORK.GameControls.clickTimeout)
				{
					this.count = 0;
				}
				this.count++;
				this.lastClickTime = Time.time;
			}
			else if(this.useTouch && this.touchCount > 0 && 
				ORK.Control.Touch.CanStart(this.touchCount))
			{
				if((Time.time - this.lastClickTime) > ORK.GameControls.clickTimeout)
				{
					this.count = 0;
				}
				this.count++;
				this.lastClickTime = Time.time;
			}
			
			if(this.allModes)
			{
				if(this.Started(ref point))
				{
					return true;
				}
				else if(this.isPressed)
				{
					if(this.Ended(ref point))
					{
						return true;
					}
					else if(MouseTouch.Hold.Equals(this.mode))
					{
						this.Moved(ref point);
						return this.isPressed;
					}
					else
					{
						return this.Moved(ref point);
					}
				}
			}
			else if(MouseTouch.Start.Equals(this.mode))
			{
				return this.Started(ref point);
			}
			else if(MouseTouch.Move.Equals(this.mode))
			{
				this.Started(ref point);
				this.Ended(ref point);
				return this.Moved(ref point);
			}
			else if(MouseTouch.End.Equals(this.mode))
			{
				return this.Ended(ref point);
			}
			else if(MouseTouch.Hold.Equals(this.mode))
			{
				this.Started(ref point);
				this.Ended(ref point);
				this.Moved(ref point);
				return this.isPressed;
			}
			return false;
		}
		
		private bool Started(ref Vector3 point)
		{
			bool started = false;
			
			if(this.useClick && Input.GetMouseButtonDown(this.mouseClick))
			{
				point = Input.mousePosition;
				started = true;
			}
			else if(this.useTouch && this.touchCount > 0 && 
				ORK.Control.Touch.CanStart(this.touchCount))
			{
				this.fingerIDs = ORK.Control.Touch.GetStarted();
				point = Vector2.zero;
				foreach(int id in this.fingerIDs)
				{
					Vector2 tmp = ORK.Control.Touch.GetPosition(id);
					point.x += tmp.x;
					point.y += tmp.y;
				}
				point /= this.touchCount;
				started = true;
			}
			
			if(started && this.clickCount != this.count)
			{
				started = false;
			}
			
			if(started)
			{
				if(ORK.GUI.CheckClick(point))
				{
					started = false;
				}
			}
			
			if(started)
			{
				this.lastPosition = point;
				this.isPressed = true;
			}
			return started;
		}
		
		private bool Moved(ref Vector3 point)
		{
			bool moved = false;
			
			if(this.isPressed)
			{
				if(this.useClick && Input.GetMouseButton(this.mouseClick))
				{
					point = Input.mousePosition;
					this.lastChange = Input.mousePosition - this.lastPosition;
					this.lastPosition = Input.mousePosition;
					moved = true;
				}
				else if(this.useTouch && this.touchCount == this.fingerIDs.Count && 
					ORK.Control.Touch.IsPhase(this.fingerIDs, InputHandling.Hold))
				{
					point = Vector2.zero;
					foreach(int id in this.fingerIDs)
					{
						Vector2 tmp = ORK.Control.Touch.GetPosition(id);
						point.x += tmp.x;
						point.y += tmp.y;
					}
					point /= this.touchCount;
					this.lastChange = point - this.lastPosition;
					this.lastPosition = point;
					moved = true;
				}
				
				if(moved && this.lastChange == Vector3.zero)
				{
					moved = false;
				}
			}
			
			if(moved && this.clickCount != this.count)
			{
				moved = false;
			}
			
			return moved;
		}
		
		private bool Ended(ref Vector3 point)
		{
			bool ended = false;
			
			if(this.useClick && Input.GetMouseButtonUp(this.mouseClick))
			{
				point = Input.mousePosition;
				ended = true;
			}
			else if(this.useTouch && this.touchCount == this.fingerIDs.Count && 
				ORK.Control.Touch.IsPhase(this.fingerIDs, InputHandling.Up))
			{
				point = Vector2.zero;
				foreach(int id in this.fingerIDs)
				{
					Vector2 tmp = ORK.Control.Touch.GetPosition(id);
					point.x += tmp.x;
					point.y += tmp.y;
				}
				point /= this.touchCount;
				ended = true;
			}
			
			if(ended && this.clickCount != this.count)
			{
				ended = false;
			}
			
			if(ended)
			{
				this.fingerIDs.Clear();
				this.isPressed = false;
			}
			return ended;
		}
	}
}
