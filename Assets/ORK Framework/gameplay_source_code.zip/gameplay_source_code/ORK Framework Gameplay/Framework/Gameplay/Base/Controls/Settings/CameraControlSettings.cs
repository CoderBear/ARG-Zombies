
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CameraControlSettings : BaseData
	{
		[ORKEditorHelp("Camera Control Type", "Select the camera control type:\n" +
			"- None: No control is added to the camera. " +
			"You have to add a camera control component to the camera in each scene by hand.\n" +
			"- Follow: The camera will follow behind the player.\n" +
			"- Look: The camera will look at the player.\n" +
			"- Mouse: The camera will follow the player. " +
			"Height and rotation can be changed by mouse/touch control.\n" +
			"- First Person: The camera is linked to the player (or a child object). " +
			"It can be moved horizontally/vertically (e.g. by mouse).\n" +
			"- Top Down Border: The camera follows the player until the he crosses a border. " +
			"The border is defined using a 'Camera Border' component with a 'Box Collider' in the scene.", "")]
		public CameraControlType type = CameraControlType.Follow;
		
		
		// use child object (all control types)
		[ORKEditorHelp("Use Child Object", "The camera will be positioned using a child object of the player (e.g. body/head).\n" +
			"Leave empty if you don't want to use a child object and place the camera using the root of the player object.", "")]
		[ORKEditorInfo(expandWidth=true, separator=true)]
		[ORKEditorLayout("type", CameraControlType.None, elseCheckGroup=true, endCheckGroup=true)]
		public string onChild = "";
		
		
		// follow
		[ORKEditorHelp("Distance", "The distance of the camera to the player.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", CameraControlType.Follow)]
		public float distanceFollow = 10.0f;
		
		[ORKEditorHelp("Height", "The height above the player.", "")]
		public float heightFollow = 5.0f;
		
		[ORKEditorHelp("Height Damping", "Used for smoother height changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float heightDampingFollow = 2.0f;
		
		[ORKEditorHelp("Rotation Damping", "Used for smoother rotation changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float rotationDampingFollow = 3.0f;
		
		
		// look
		[ORKEditorHelp("Smooth", "Camera changes will use damping.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", CameraControlType.Look)]
		public bool smooth = true;
		
		[ORKEditorHelp("Damping", "Used for smoother camera changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[ORKEditorLayout("smooth", true, endCheckGroup=true, endGroups=2)]
		[ORKEditorLimit(0.0f, false)]
		public float damping = 6.0f;
		
		
		// mouse
		[ORKEditorHelp("Distance", "The distance of the camera to the player.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", CameraControlType.Mouse)]
		public float distanceMouse = 10.0f;
		
		// height
		[ORKEditorHelp("Height", "The height above the player.", "")]
		public float heightMouse = 15.0f;
		
		[ORKEditorHelp("Minimum Height", "The minimum height above the player.", "")]
		public float minHeight = 5.0f;
		
		[ORKEditorHelp("Maximum Height", "The maximum height above the player.", "")]
		public float maxHeight = 30.0f;
		
		[ORKEditorHelp("Height Damping", "Used for smoother height changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float heightDampingMouse = 2.0f;
		
		[ORKEditorInfo(separator=true)]
		public MouseTouchControl mouseTouch = new MouseTouchControl(false, 1, true, 2, 1, MouseTouch.Move);
		
		// rotation
		[ORKEditorHelp("Allow Rotation", "The rotation of the camera can be changed by mouse/touch controls.\n" +
			"The rotation can be changed by a horizontal mouse/touch drag.", "")]
		[ORKEditorInfo(separator=true)]
		public bool allowRotation = true;
		
		[ORKEditorHelp("Start Rotation", "The start rotation of the camera.\n" +
			"E.g. 90 will show the player from the south (world axis).", "")]
		public float rotation = 0;
		
		[ORKEditorHelp("Rotation Damping", "Used for smoother rotation changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float rotationDampingMouse = 3.0f;
		
		[ORKEditorHelp("Rotation Factor", "The actual touch/mouse move is multiplied with this number " +
			"to determine the rotation change.\n" +
			"Set to negative numbers to invert rotation.", "")]
		[ORKEditorLayout("allowRotation", true, endCheckGroup=true)]
		public float rotationFactor = 1;
		
		// zoom
		[ORKEditorHelp("Allow Zoom", "The camera zoom (height) can be changed by mouse/touch controls.\n" +
			"The height can be changed by a vertical mouse/touch drag.", "")]
		[ORKEditorInfo(separator=true)]
		public bool allowZoom = true;
		
		[ORKEditorHelp("Zoom Factor", "The actual touch/mouse move is multiplied with this number " +
			"to determine the zoom change.\n" +
			"Set to negative numbers to invert zoom.", "")]
		[ORKEditorLayout("allowZoom", true)]
		public float zoomFactor = 1;
		
		[ORKEditorHelp("Use Axis", "Use an input key as axis for the zoom.\n" +
			"Enable this setting if you want to use a mouse wheel.\n" +
			"If disabled, you can define a zoom in and a zoom out key.", "")]
		public bool zoomAxis = false;
		
		[ORKEditorHelp("Zoom Axis", "The key (used as axis) used to zoom in/out.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("zoomAxis", true)]
		public int zoomAxisKey = 0;
		
		[ORKEditorHelp("Zoom Plus Key", "The key used to zoom in.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout(elseCheckGroup=true)]
		public int zoomPlusKey = 0;
		
		[ORKEditorHelp("Zoom Minus Key", "The key used to zoom out.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout(endCheckGroup=true)]
		public int zoomMinusKey = 0;
		
		[ORKEditorHelp("Zoom Key Change", "The amount the zoom changes on key press.", "")]
		public float zoomKeyChange = 3;
		
		[ORKEditorHelp("Limit Change", "Changing the camera rotation/zoom is limited to one axis at a time.\n" +
			"The axis (horizontal for rotation, vertical for zoom) that received the larger change will be used.", "")]
		[ORKEditorLayout("allowRotation", true, endCheckGroup=true, endGroups=3)]
		public bool mLimitChange = true;
		
		
		// first person
		[ORKEditorHelp("Offset", "The offset added to the player/child position when placing the camera.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", CameraControlType.FirstPerson)]
		public Vector3 offset = Vector3.zero;
		
		[ORKEditorHelp("Vertical Axis", "The key used for vertical camera changes.\n" +
			"Vertical camera changes will turn the camera along the X-axis.", "")]
		[ORKEditorInfo(ORKDataType.InputKey, separator=true)]
		public int verticalAxis = 2;
		
		[ORKEditorHelp("Horizontal Axis", "The key used for horizontal camera changes.\n" +
			"Horizontal camera changes will turn the camera along the Y-axis.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int horizontalAxis = 1;
		
		[ORKEditorHelp("Sensitivity", "The sensitivity of the horizontal (X) and vertical (Y) camera moves.\n" +
			"Use negative numbers to invert control.", "")]
		[ORKEditorInfo(separator=true)]
		public Vector2 sensitivity = new Vector2(15, 15);
		
		[ORKEditorHelp("Lock Cursor", "The mouse cursor will be locked when the camera control is enabled " +
			"(i.e. the mouse cursor is centered in the screen, hidden and can't be moved).", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool lockCursor = false;
		
		
		// top down border
		[ORKEditorHelp("Position Damping", "Used for smoother position changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[ORKEditorLayout("type", CameraControlType.TopDownBorder)]
		[ORKEditorLimit(0.0f, false)]
		public float tdbPositionDamping = 0;
		
		[ORKEditorHelp("Position Padding", "Padding added to the border.\n" +
			"Left + X, top - Y, right - Z, bottom + W.\n" +
			"If the player steps outside the border left or right, the camera will stop following on the X-axis.\n" +
			"If the player steps outside the border to or bottom, the camera will stop following on the Z-axis.", "")]
		public Vector4 tdbPositionPadding = new Vector4(0, 0, 0, 0);
		
		[ORKEditorHelp("Distance", "The distance of the camera to the player.", "")]
		public float tdbDistance = 15.0f;
		
		[ORKEditorHelp("Height", "The height above the player.", "")]
		public float tdbHeight = 15.0f;
		
		[ORKEditorHelp("Height Damping", "Used for smoother height changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float tdbHeightDamping = 2.0f;
		
		[ORKEditorHelp("Rotation", "The rotation of the camera.\n" +
			"This defines the looking direction of the camera, e.g.:" +
			"- 0 looks north\n" +
			"- 90 looks east\n" +
			"- 180 looks south\n" +
			"- 270 (or -90) will look west", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public float tdbRotation = 0;
		
		
		// collision camera settings
		[ORKEditorInfo(separator=true, labelText="Collision Camera Settings")]
		public CollisionCameraSettings collisionCamera = new CollisionCameraSettings();
		
		public CameraControlSettings()
		{
			
		}
		
		
		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool IsFollowControl()
		{
			return CameraControlType.Follow.Equals(this.type);
		}
		
		public bool IsLookControl()
		{
			return CameraControlType.Look.Equals(this.type);
		}
		
		public bool IsMouseControl()
		{
			return CameraControlType.Mouse.Equals(this.type);
		}
		
		public bool IsFirstPersonControl()
		{
			return CameraControlType.FirstPerson.Equals(this.type);
		}
		
		public bool IsTopDownBorderControl()
		{
			return CameraControlType.TopDownBorder.Equals(this.type);
		}
		
		
		/*
		============================================================================
		Ingame functions
		============================================================================
		*/
		public void AddCameraControl(GameObject camera)
		{
			ORK.GameControls.customControl.AddCameraControls(
				ORK.Game.ActiveGroup.Leader != null ? 
					ORK.Game.ActiveGroup.Leader.GameObject : null, 
				camera);
			
			NoCameraControl check = camera.GetComponent<NoCameraControl>();
			if(check == null)
			{
				if(this.IsFollowControl())
				{
					SmoothFollow comp = camera.GetComponent<SmoothFollow>();
					if(comp == null)
					{
						comp = camera.AddComponent<SmoothFollow>();
					}
					comp.onChild = this.onChild;
					comp.distance = this.distanceFollow;
					comp.height = this.heightFollow;
					comp.heightDamping = this.heightDampingFollow;
					comp.rotationDamping = this.rotationDampingFollow;
					
					ORK.Control.AddCameraControl(comp);
				}
				else if(this.IsLookControl())
				{
					SmoothLookAt comp = camera.GetComponent<SmoothLookAt>();
					if(comp == null)
					{
						comp = camera.AddComponent<SmoothLookAt>();
					}
					comp.onChild = this.onChild;
					comp.damping = this.damping;
					comp.smooth = this.smooth;
					
					ORK.Control.AddCameraControl(comp);
				}
				else if(this.IsMouseControl())
				{
					TouchCamera comp = camera.GetComponent<TouchCamera>();
					if(comp == null)
					{
						comp = camera.AddComponent<TouchCamera>();
					}
					comp.onChild = this.onChild;
					comp.distance = this.distanceMouse;
					comp.height = this.heightMouse;
					comp.minHeight = this.minHeight;
					comp.maxHeight = this.maxHeight;
					comp.heightDamping = this.heightDampingMouse;
					comp.allowRotation = this.allowRotation;
					comp.allowZoom = this.allowZoom;
					comp.rotation = this.rotation;
					comp.rotationDamping = this.rotationDampingMouse;
					comp.rotationFactor = this.rotationFactor;
					comp.zoomFactor = this.zoomFactor;
					comp.zoomAxis = this.zoomAxis;
					comp.zoomAxisKey = this.zoomAxisKey;
					comp.mouseTouch = this.mouseTouch;
					comp.zoomPlusKey = this.zoomPlusKey;
					comp.zoomMinusKey = this.zoomMinusKey;
					comp.zoomKeyChange = this.zoomKeyChange;
					comp.limitChange = this.mLimitChange;
					
					ORK.Control.AddCameraControl(comp);
				}
				else if(this.IsFirstPersonControl())
				{
					FirstPersonCamera comp = camera.GetComponent<FirstPersonCamera>();
					if(comp == null)
					{
						comp = camera.AddComponent<FirstPersonCamera>();
					}
					comp.onChild = this.onChild;
					comp.offset = this.offset;
					comp.horizontalAxis = this.horizontalAxis;
					comp.verticalAxis = this.verticalAxis;
					comp.sensitivity = this.sensitivity;
					comp.lockCursor = this.lockCursor;
					
					ORK.Control.AddCameraControl(comp);
				}
				else if(this.IsTopDownBorderControl())
				{
					TopDownBorderCamera comp = camera.GetComponent<TopDownBorderCamera>();
					if(comp == null)
					{
						comp = camera.AddComponent<TopDownBorderCamera>();
					}
					comp.onChild = this.onChild;
					comp.positionDamping = this.tdbPositionDamping;
					comp.positionPadding = this.tdbPositionPadding;
					comp.distance = this.tdbDistance;
					comp.height = this.tdbHeight;
					comp.heightDamping = this.tdbHeightDamping;
					comp.rotation = this.tdbRotation;
					
					ORK.Control.AddCameraControl(comp);
				}
			}
			
			this.collisionCamera.Add(camera);
		}
		
		public void RemoveCameraControl(GameObject camera)
		{
			ORK.GameControls.customControl.RemoveCameraControls(
				ORK.Game.ActiveGroup.Leader != null ? 
					ORK.Game.ActiveGroup.Leader.GameObject : null, 
				camera);
			
			NoCameraControl check = camera.GetComponent<NoCameraControl>();
			if(check == null)
			{
				if(this.IsFollowControl())
				{
					SmoothFollow comp = camera.GetComponent<SmoothFollow>();
					ORK.Control.RemoveCameraControl(comp);
					if(comp != null)
					{
						GameObject.Destroy(comp);
					}
				}
				else if(this.IsLookControl())
				{
					SmoothLookAt comp = camera.GetComponent<SmoothLookAt>();
					ORK.Control.RemoveCameraControl(comp);
					if(comp != null)
					{
						GameObject.Destroy(comp);
					}
				}
				else if(this.IsMouseControl())
				{
					TouchCamera comp = camera.GetComponent<TouchCamera>();
					ORK.Control.RemoveCameraControl(comp);
					if(comp != null)
					{
						GameObject.Destroy(comp);
					}
				}
				else if(this.IsFirstPersonControl())
				{
					FirstPersonCamera comp = camera.GetComponent<FirstPersonCamera>();
					ORK.Control.RemoveCameraControl(comp);
					if(comp != null)
					{
						GameObject.Destroy(comp);
					}
				}
				else if(this.IsTopDownBorderControl())
				{
					TopDownBorderCamera comp = camera.GetComponent<TopDownBorderCamera>();
					ORK.Control.RemoveCameraControl(comp);
					if(comp != null)
					{
						GameObject.Destroy(comp);
					}
				}
			}
		}
	}
}
