
using UnityEngine;

namespace ORKFramework
{
	public class PlayAudioSettings : BaseData
	{
		[ORKEditorHelp("Play One Shot", "Uses the PlayOneShot function of the AudioSource component to play the audio clip.", "")]
		public bool oneShot = false;
		
		// advanced settings
		[ORKEditorHelp("Advanced Settings", "Change settings of the AudioSource component used to play the clip.", "")]
		[ORKEditorInfo(separator=true)]
		public bool advSet = false;
		
		[ORKEditorHelp("Volume", "The volume this audio clip is played at.", "")]
		[ORKEditorLayout(new string[] {"oneShot", "advSet"}, 
			new System.Object[] {true, true}, needed=Needed.One, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float volume = 1;
		
		[ORKEditorHelp("Minimum Distance", "Within the minimum distance the AudioSource will cease to grow louder in volume.", "")]
		[ORKEditorLayout("advSet", true)]
		[ORKEditorLimit(0.0f, false)]
		public float minD = 0;
		
		[ORKEditorHelp("Maximum Distance", "(Logarithmic rolloff) Maximum distance is the distance a sound stops attenuating at.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float maxD = 100;
		
		[ORKEditorHelp("Rolloff Mode", "Sets how the AudioSource attenuates over distance.", "")]
		public AudioRolloffMode rolloff = AudioRolloffMode.Linear;
		
		[ORKEditorHelp("Pitch", "The pitch of the audio source.", "")]
		public float pitch = 1;
		
		[ORKEditorHelp("Loop", "The audio clip will loop.", "")]
		public bool loop = false;
		
		[ORKEditorHelp("Ignore Listener Vol.", "This makes the AudioSource not take into account the volume of the AudioListener.", "")]
		public bool ignoreLV = false;
		
		[ORKEditorHelp("Set Pan", "Set the AudioSource pan settings.", "")]
		public bool setPan = false;
		
		[ORKEditorHelp("Pan Level", "Sets how much the 3d engine has an effect on the channel, 0=2D and 1=3D.", "")]
		[ORKEditorLayout("setPan", true)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float panLevel = 0;
		
		[ORKEditorHelp("Pan", "Sets a channels pan position linearly.\n" +
			"Only works for 2D clips. -1.0 is full left, 0.0 is center, 1.0 is full right.", "")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		[ORKEditorLimit(-1.0f, 1.0f)]
		public float pan = 0;
		
		public PlayAudioSettings()
		{
			
		}
		
		public float PlayAudio(GameObject obj, AudioClip clip)
		{
			AudioSource audio = ComponentHelper.Get<AudioSource>(obj);
			if(this.advSet)
			{
				audio.pitch = this.pitch;
				audio.volume = this.volume * ORK.Game.SoundVolume;
				audio.rolloffMode = this.rolloff;
				audio.minDistance = this.minD;
				audio.maxDistance = this.maxD;
				audio.loop = this.loop;
				audio.ignoreListenerVolume = this.ignoreLV;
				if(this.setPan)
				{
					audio.panLevel = this.panLevel;
					audio.pan = this.pan;
				}
			}
			if(this.oneShot)
			{
				audio.PlayOneShot(clip, this.volume * ORK.Game.SoundVolume);
			}
			else
			{
				audio.clip = clip;
				audio.Play();
			}
			return clip.length;
		}
	}
}

