
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class PlayerControlSettings : BaseData
	{
		[ORKEditorHelp("Player Control Type", "Select the player control type:\n" +
			"- None: No control is added, you have to add your own components to the player prefab.\n" +
			"- Button: Keyboard/joystick controls are used to move the player.\n" +
			"- Mouse: Mouse/touch controls are used to move the player.\n" +
			"Depending on your control type selection you'll have different settings available.\n\n" +
			"The 'Mouse' control uses raycasting to set the move target.\n" +
			"You can set up areas that block clicks/touches for player movement - " +
			"add a NoClickMove component to a game object with a collider. " +
			"The bounds are used to check if the clicked/touched position is a valid move position. " +
			"The Y-position of the game object is ignored for the check.", "")]
		public PlayerControlType type = PlayerControlType.Button;
		
		
		// overall controls
		[ORKEditorHelp("Move Dead", "You can control the player, even when the player combatant is dead.", "")]
		[ORKEditorInfo(separator=true)]
		public bool moveDead = true;
		
		[ORKEditorHelp("Use Combatant Speed", "The speed of the player combatant according to its move speed settings is used.", "")]
		public bool useSpeed = true;
		
		[ORKEditorHelp("Speed", "The speed in world units per second the player will move at.", "")]
		[ORKEditorLayout("useSpeedDefault", false, endCheckGroup=true)]
		[ORKEditorLimit(0.1f, false)]
		public float runSpeed = 8.0f;
		
		[ORKEditorHelp("Gravity", "The gravity used when moving.\n" +
			"Use negative numbers.", "")]
		public float gravity = Physics.gravity.y;
		
		[ORKEditorHelp("Speed Smoothing", "Used to have a smooth transition between no movement and full move speed.", "")]
		public float speedSmoothing = 10.0f;
		
		
		// button controller
		[ORKEditorHelp("Rotation Speed", "The speed used when rotating the character.", "")]
		[ORKEditorLayout("type", PlayerControlType.Button)]
		public float rotateSpeed = 500.0f;
		
		[ORKEditorHelp("First Person", "The axis keys will be used for first person control, " +
			"i.e. vertical axis will move forward/backward, vertical axis will move sidewards.", "")]
		[ORKEditorInfo(separator=true)]
		public bool firstPerson = false;
		
		[ORKEditorHelp("Use Camera Direction", "Tthe axis keys will move the player based on the camera view.\n" +
			"If disabled, the vertical axis key moves the player forward/backward, the horizontal axis key turns the player.", "")]
		public bool useCamDirection = true;
		
		[ORKEditorHelp("Vertical Axis", "The key used for vertical control.", "")]
		[ORKEditorInfo(ORKDataType.InputKey, separator=true)]
		public int verticalAxis = 2;
		
		[ORKEditorHelp("Horizontal Axis", "The key used for horizontal control.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int horizontalAxis = 1;
		
		// jump
		[ORKEditorHelp("Use Jump", "The player can jump.", "")]
		[ORKEditorInfo(separator=true, labelText="Jump Settings")]
		public bool useJump = false;
		
		[ORKEditorHelp("Jump Key", "The key used to jump.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("useJump", true)]
		public int jumpKey = 0;
		
		[ORKEditorHelp("Jump Duration (s)", "The time in seconds the player will move up before falling down again.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float jumpDuration = 0.5f;
		
		[ORKEditorHelp("Jump Delay (s)", "The time inseconds before the actual jump will be performed.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float jumpDelay = 0;
		
		[ORKEditorHelp("Jump Speed", "The vertical speed in world units used when jumping.\n" +
			"Use positive numbers.", "")]
		public float jumpSpeed = -Physics.gravity.y;
		
		[ORKEditorHelp("Jump Interpolation", "The interpolation used for changing the jump speed over time.\n" +
			"E.g. EaseOutQuad will decrease the jump speed at the end of the jump.", "")]
		public EaseType jumpInterpolation = EaseType.EaseOutQuad;
		
		[ORKEditorHelp("In Air Modifier", "This setting effects the move speed while in the air.\n" +
			"A value below 1 will decrease the speed, above will increase.", "")]
		public float inAirModifier = 0.5f;
		
		[ORKEditorHelp("Maximum Ground Angle", "The maximum angle of the ground to allow jumping.\n" +
			"Use this setting to prevent jumping from steep slopes.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public float jumpMaxGroundAngle = 45;
		
		// sprint
		[ORKEditorHelp("Use Sprint", "The player can sprint.", "")]
		[ORKEditorInfo(separator=true, labelText="Sprint Settings")]
		public bool useSprint = false;
		
		[ORKEditorHelp("Sprint Key", "The key used to sprint.\n" +
			"The key must be held down to sprint - select handling type Hold in the settings of the key.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("useSprint", true)]
		public int sprintKey = 0;
		
		[ORKEditorHelp("Sprint Factor", "The players move speed will be multiplied with this number when sprinting.\n" +
			"E.g. 2 will double the move speed.", "")]
		public float sprintFactor = 2.0f;
		
		[ORKEditorHelp("Use Energy", "Sprinting will consume energy.", "")]
		public bool useEnergy = false;
		
		[ORKEditorInfo("Maximum Energy", "The maximum sprint energy.", "", endFoldout=true)]
		[ORKEditorLayout("useEnergy", true, autoInit=true)]
		public FloatValue maxEnergy;
		
		[ORKEditorInfo("Energy Consume", "The energy consumed per second when sprinting.", "", endFoldout=true)]
		[ORKEditorLayout(autoInit=true)]
		public FloatValue energyConsume;
		
		[ORKEditorInfo("Energy Regeneration", "The energy regenerated per second.", "", endFoldout=true)]
		[ORKEditorLayout(autoInit=true, endCheckGroup=true, endGroups=3)]
		public FloatValue energyRegeneration;
		
		
		// mouse controller
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", PlayerControlType.Mouse)]
		public MouseTouchControl mouseTouch = new MouseTouchControl(true);
		
		// raycast
		[ORKEditorHelp("Raycast Distance", "The distance the raycast will check to set the move target.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLimit(0.0f, false)]
		public float raycastDistance = 100.0f;
		
		[ORKEditorHelp("Layer Mask", "Select the layers the raycast will check.", "")]
		public LayerMask layerMask = -1;
		
		// cursor
		[ORKEditorHelp("Cursor Prefab", "The prefab used to display a cursor on the position of the move target.\n" +
			"Select none if no cursor should be displayed.", "")]
		[ORKEditorInfo(separator=true)]
		public GameObject cursorObject;
		
		[ORKEditorHelp("Cursor Offset", "The offset added to the move target position for displaying the cursor.", "")]
		public Vector3 cursorOffset = Vector3.zero;
		
		[ORKEditorHelp("Min. Move Distance", "The minimum distance to the move target the player must reach to stop moving.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLimit(0.1f, false)]
		public float minimumMoveDistance = 0.2f;
		
		[ORKEditorHelp("Ignore Y Distance", "The distance along the Y-axis will be ignored for the " +
			"minimum move distance check, i.e. the height difference is ignored.", "")]
		public bool ignoreYDistance = true;
		
		[ORKEditorHelp("Use Event Mover", "The move will be performed using the ActorEventMover component and interpolating the " +
			"player's position between move start and move target.\n" +
			"The player will be able to go through obstacles in the way with this setting.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useEventMover = false;
		
		// secure move
		[ORKEditorHelp("Secure Move", "The movement will end if the player couldn't move for a defined amount of time.\n" +
			"If disabled, the player will move until it reached it's target.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("useEventMover", false)]
		public bool secureMove = false;
		
		[ORKEditorHelp("Secure Time (s)", "The time in seconds the player mustn't move to stop the movement.", "")]
		[ORKEditorLayout("secureMove", true, endCheckGroup=true, endGroups=2)]
		[ORKEditorLimit(0.1f, false)]
		public float secureTime = 0.5f;
		
		[ORKEditorHelp("Remove Cursor No Control", "The cursor will automatically be removed when " +
			"control is not possible (e.g. when an event starts).", "")]
		public bool autoRemoveCursor = true;
		
		[ORKEditorHelp("Remove Cursor Target", "The cursor will automatically be removed when " +
			"the target destination is reached (or movement stopped).", "")]
		public bool autoRemoveCursorTarget = true;
		
		[ORKEditorHelp("Auto Stop Move", "The move will be stopped when e.g. an event starts.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool autoStopMove = true;
		
		public PlayerControlSettings()
		{
			
		}
		
		
		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool IsButtonControl()
		{
			return PlayerControlType.Button.Equals(this.type);
		}
		
		public bool IsMouseControl()
		{
			return PlayerControlType.Mouse.Equals(this.type);
		}
		
		/*
		============================================================================
		Ingame functions
		============================================================================
		*/
		public void AddPlayerControl(GameObject player)
		{
			ORK.GameControls.AddInteractionController(player);
			
			ORK.GameControls.customControl.AddPlayerControls(
				player, 
				Camera.main != null ? Camera.main.gameObject : null);
			
			if(this.IsButtonControl())
			{
				ButtonPlayerController comp = player.GetComponent<ButtonPlayerController>();
				if(comp == null)
				{
					comp = player.AddComponent<ButtonPlayerController>();
				}
				comp.moveDead = this.moveDead;
				comp.useCharacterSpeed = this.useSpeed;
				comp.runSpeed = this.runSpeed;
				comp.gravity = this.gravity;
				comp.speedSmoothing = this.speedSmoothing;
				comp.rotateSpeed = this.rotateSpeed;
				comp.verticalAxis = this.verticalAxis;
				comp.horizontalAxis = this.horizontalAxis;
				comp.useJump = this.useJump;
				comp.jumpKey = this.jumpKey;
				comp.jumpDuration = this.jumpDuration;
				comp.jumpDelay = this.jumpDelay;
				comp.jumpSpeed = this.jumpSpeed;
				comp.jumpInterpolation = this.jumpInterpolation;
				comp.inAirModifier = this.inAirModifier;
				comp.jumpMaxGroundAngle = this.jumpMaxGroundAngle;
				comp.useSprint = this.useSprint;
				comp.sprintKey = this.sprintKey;
				comp.useEnergy = this.useEnergy;
				comp.maxEnergy = this.maxEnergy;
				comp.energyConsume = this.energyConsume;
				comp.energyRegeneration = this.energyRegeneration;
				comp.firstPerson = this.firstPerson;
				comp.useCamDirection = this.useCamDirection;
				
				ORK.Control.AddPlayerControl(comp);
			}
			else if(this.IsMouseControl())
			{
				MousePlayerController comp = player.GetComponent<MousePlayerController>();
				if(comp == null)
				{
					comp = player.AddComponent<MousePlayerController>();
				}
				comp.mouseTouch.SetData(this.mouseTouch.GetData());
				comp.moveDead = this.moveDead;
				comp.useCharacterSpeed = this.useSpeed;
				comp.runSpeed = this.runSpeed;
				comp.gravity = this.gravity;
				comp.speedSmoothing = this.speedSmoothing;
				comp.raycastDistance = this.raycastDistance;
				comp.layerMask = this.layerMask;
				comp.cursorOffset = this.cursorOffset;
				comp.minimumMoveDistance = this.minimumMoveDistance;
				comp.ignoreYDistance = this.ignoreYDistance;
				comp.useEventMover = this.useEventMover;
				comp.autoRemoveCursor = this.autoRemoveCursor;
				comp.autoRemoveCursorTarget = this.autoRemoveCursorTarget;
				comp.autoStopMove = this.autoStopMove;
				comp.secureMove = this.secureMove;
				comp.secureTime = this.secureTime;
				
				comp.cursorObject = this.cursorObject;
				
				ORK.Control.AddPlayerControl(comp);
			}
		}
		
		public void RemovePlayerControl(GameObject player)
		{
			ORK.GameControls.customControl.RemovePlayerControls(
				player, 
				Camera.main != null ? Camera.main.gameObject : null);
			
			if(this.IsButtonControl())
			{
				ButtonPlayerController comp = player.GetComponent<ButtonPlayerController>();
				ORK.Control.RemovePlayerControl(comp);
				if(comp != null)
				{
					GameObject.Destroy(comp);
				}
			}
			else if(this.IsMouseControl())
			{
				MousePlayerController comp = player.GetComponent<MousePlayerController>();
				ORK.Control.RemovePlayerControl(comp);
				if(comp != null)
				{
					comp.ClearCursor();
					GameObject.Destroy(comp);
				}
			}
		}
	}
}
