
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Animations
{
	public class LegacyAnimationBase : BaseData
	{
		[ORKEditorHelp("Animation Name", "Set the name of the animation clip.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string name = "";
		
		[ORKEditorHelp("Set Layer", "Set the layer of the animation.", "")]
		public bool setLayer = false;
		
		[ORKEditorHelp("Animation Layer", "Set the animation layer for this animation clip.", "")]
		[ORKEditorLayout("setLayer", true, endCheckGroup=true)]
		public int layer = 0;
		
		[ORKEditorHelp("Set Speed", "Set the playback speed of the animation based on a formula, e.g.:\n" +
			"- 1 results in the normal playback speed.\n" +
			"- 2 results in double playback speed, i.e. the animations will be twice as fast.\n" +
			"- 0.5 results in halve playback speed, i.e. the animation will be halve as slow.\n" +
			"Everything below 0 results in playing animations backwards.", "")]
		public bool setSpeed = false;
		
		[ORKEditorInfo("Speed Value", "Define the playback speed.\n" +
			"1 is the normal playback speed, above 1 will play faster, below 1 will play slower.", "", endFoldout=true)]
		[ORKEditorLayout("setSpeed", true, endCheckGroup=true, autoInit=true)]
		public FloatValue speedValue;
		
		
		// play settings
		[ORKEditorHelp("Play Type", "Select how the animation will be played:\n" +
		 	"- Play: Plays animation without any blending.\n" +
		 	"- Cross Fade: Fades the animation in over a period of time and fades other animations out.\n" +
		 	"- Blend: Blends the animation towards a target weight over time.\n" +
		 	"- Play Queued: Plays an animation after previous animations finished playing.\n" +
		 	"- Cross Fade Queued: Cross fades an animation after previous animations finished playing.\n" +
		 	"- Stop: Stops the animation (or all animations).", "")]
		[ORKEditorInfo(separator=true, labelText="Play Settings")]
		public LegacyAnimationPlayMode playType = LegacyAnimationPlayMode.CrossFade;
		
		[ORKEditorHelp("Play Mode", "Select how other animations will be handled, either StopSameLayer or StopAll.", "")]
		[ORKEditorLayout(new string[] {"playType", "playType"}, 
			new System.Object[] {LegacyAnimationPlayMode.Blend, LegacyAnimationPlayMode.Stop}, 
			needed=Needed.One, elseCheckGroup=true, endCheckGroup=true)]
		public PlayMode playMode = PlayMode.StopSameLayer;
		
		[ORKEditorHelp("Fade Length", "The time in seconds used to fade from the previous animation to the new one.", "")]
		[ORKEditorLayout(new string[] {"playType", "playType", "playType"}, 
			new System.Object[] {LegacyAnimationPlayMode.CrossFade, LegacyAnimationPlayMode.CrossFadeQueued, LegacyAnimationPlayMode.Blend}, 
			needed=Needed.One, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float fade = 0.1f;
		
		[ORKEditorHelp("Target Weight", "The target weight to blend to.", "")]
		[ORKEditorLayout("playType", LegacyAnimationPlayMode.Blend, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float weight = 1;
		
		[ORKEditorHelp("Queue Mode", "Select how other animations will be handled, either CompleteOthers or PlayNow.", "")]
		[ORKEditorLayout(new string[] {"playType", "playType"}, 
			new System.Object[] {LegacyAnimationPlayMode.PlayQueued, LegacyAnimationPlayMode.CrossFadeQueued}, 
			needed=Needed.One, endCheckGroup=true)]
		public QueueMode queueMode = QueueMode.CompleteOthers;
		
		// stop
		[ORKEditorHelp("Stop All", "Stop all animations.\n" +
			"If disabled, only the defined animation will be stopped.", "")]
		[ORKEditorLayout("playType", LegacyAnimationPlayMode.Stop, endCheckGroup=true)]
		public bool stopAll = false;
		
		public LegacyAnimationBase()
		{
			
		}
		
		
		/*
		============================================================================
		Animation functions
		============================================================================
		*/
		public void Init(Combatant combatant, Animation animation)
		{
			if(this.name != "" && animation[this.name] != null)
			{
				if(this.setLayer)
				{
					animation[this.name].layer = layer;
				}
				if(this.setSpeed)
				{
					animation[this.name].speed = this.speedValue.GetValue(combatant, combatant) * ORK.Game.AnimationFactor;
				}
			}
		}
		
		public AnimInfo Play(Animation animation)
		{
			if(LegacyAnimationPlayMode.Stop.Equals(this.playType))
			{
				if(this.stopAll)
				{
					animation.Stop();
				}
				else
				{
					animation.Stop(this.name);
				}
				return new AnimInfo(AnimationSystem.Legacy, this.name, -1);
			}
			else if(animation[this.name] != null)
			{
				if(LegacyAnimationPlayMode.Play.Equals(this.playType))
				{
					animation.Play(this.name, this.playMode);
				}
				else if(LegacyAnimationPlayMode.PlayQueued.Equals(this.playType))
				{
					animation.PlayQueued(this.name, this.queueMode, this.playMode);
				}
				else if(LegacyAnimationPlayMode.CrossFade.Equals(this.playType))
				{
					animation.CrossFade(this.name, this.fade, this.playMode);
				}
				else if(LegacyAnimationPlayMode.CrossFadeQueued.Equals(this.playType))
				{
					animation.CrossFadeQueued(this.name, this.fade, this.queueMode, this.playMode);
				}
				else if(LegacyAnimationPlayMode.Blend.Equals(this.playType))
				{
					animation.Blend(this.name, this.weight, this.fade);
				}
				return new AnimInfo(AnimationSystem.Legacy, this.name, AnimationHelper.GetLength(animation, this.name));
			}
			return AnimInfo.None;
		}
	}
}
