
using UnityEngine;
using ORKFramework.AI;
using ORKFramework.Animations;
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CombatantSetting : BaseLanguageData, IContent
	{
		// base settings
		// prefab settings
		[ORKEditorHelp("Prefab", "Select the prefab of this combatant.\n" +
			"The prefab is used to spawn the combatant in the field and in battle.", "")]
		[ORKEditorInfo("Base Settings", "Define the prefabs, sounds and other basic settings of this combatant.", "", 
			"Prefab Settings", "Define the combatant's prefab.\n" +
			"The prefab is used to spawn the combatant in the field and in battles.\n" +
			"You can use status and variable conditions to change the prefab during the game.", "")]
		public GameObject prefab;
		
		[ORKEditorHelp("Set Object Name", "Set the name of the spawned game object (prefab) representing the " +
			"combatant to the combatant's name.\n" +
			"If disabled, the default name for spawned objects (e.g. 'PrefabName(Clone)') will be used.", "")]
		public bool setObjectName = false;
		
		[ORKEditorHelp("Child as Root", "The defined child object of the game object " +
			"(selected prefab) will be used as root object.\n" +
			"This can be used e.g. if the prefab root isn't the moving object.\n" +
			"Usage: Path/to/Child. Leave empty if no child object should be used.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string prefabRoot = "";
		
		[ORKEditorHelp("Box Radius", "The box radius is a radius around the combatant and represents " +
		 	"the combatants width.\n" +
		 	"It's used to calculate distances, e.g. for movement and range checks.\n" +
			"E.g.: Two combatants are 10 world units apart, one combatant has a box width of 4, " +
			"the other has a box width of 1.5 - the calculated distance would be 4.5.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float boxRadius = 0;
		
		[ORKEditorHelp("Spawn Offset", "Offset added to the combatants game object position when spawning.", "")]
		public Vector3 spawnOffset = Vector3.zero;
		
		// conditional prefabs
		[ORKEditorInfo(endFoldout=true, separator=true, labelText="Conditional Prefabs")]
		[ORKEditorArray(false, "Add Conditional Prefab", "Adds a conditional prefab.\n" +
			"A conditional prefab can replace the combatant's base prefab upon status and variable conditions.\n" +
			"The first conditional prefab with valid conditions will be used. " +
			"If none is valid, the base prefab will be used.", "", 
			"Remove", "Removes this conditional prefab.", "", isCopy=true, isMove=true, 
			foldout=true, foldoutText=new string[] {
				"Conditional Prefab", "A conditional prefab can replace the combatant's " +
				"base prefab upon status and variable conditions.\n" +
				"The first conditional prefab with valid conditions will be used. " +
				"If none is valid, the base prefab will be used.", ""
		})]
		public CombatantPrefab[] conditionalPrefab = new CombatantPrefab[0];
		
		// audio settings
		[ORKEditorInfo("Sound Settings", "Combatants use sounds to play default audio clips in events (e.g. a damage sound when being hit).\n" +
			"A sound is played if the sound's sound type is played on the combatant (through event steps).\n" +
			"This makes it easier to share events between different combatants.", "", endFoldout=true)]
		[ORKEditorArray(false, "Add Sound", "Adds a sound to the list.", "", 
			"Remove", "Removes this sound.", "", foldout=true, 
			foldoutText=new string[] {"Sound", "The sound is played if the selected sound type is played on the combatant.", ""})]
		public Sound[] battleSound = new Sound[0];
		
		// portraits
		[ORKEditorInfo("Portraits", "Portraits are used in dialogue event steps to display an image of the combatant as speaker.", "", endFoldout=true)]
		[ORKEditorArray(false, "Add Portrait", "Adds a portrait.", "", 
			"Remove", "Removes this portrait.", "", isMove=true, isCopy=true, 
			foldout=true, foldoutText=new string[] {"Portrait", 
			"This portrait is available in dialogue event steps.", ""})]
		public PortraitWithType[] portrait = new PortraitWithType[0];
		
		// control maps
		[ORKEditorHelp("Control Map", "Select the control map that will be used.", "")]
		[ORKEditorInfo("Control Settings", "If the combatant is controlled by the player, " +
			"you can use control maps to quickly access actions.", "", 
			isPopup=true, popupType=ORKDataType.ControlMap, endFoldout=true, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Control Map", "Adds a control map to this combatant.", "",
			"Remove", "Removes the control map.", "", isHorizontal=true)]
		public int[] controlMap = new int[0];
		
		// object variables
		[ORKEditorHelp("Use Object Variables", "Automatically adds an 'Object Variables' component " +
			"to the combatant's game object.\n" +
			"Object variables are used to bind game variables to game objects in the scene.", "")]
		[ORKEditorInfo("Object Variable Settings", 
			"You can automatically add an 'Object Variables' component to the player's prefab.\n" +
			"The object variables can be initialized with default values.", "")]
		public bool useObjectVariables = false;
		
		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("useObjectVariables", true, endCheckGroup=true, autoInit=true)]
		public ObjectVariableSetting objectVariables;
		
		// console texts
		// defend
		[ORKEditorHelp("Own Defend Text", "This combatant overrides the default defend text.", "")]
		[ORKEditorInfo("Console Texts", "A combatant can override the default console texts for defend, escape and death.", "")]
		public bool ownConsoleDefend = false;
		
		[ORKEditorInfo("Defend Text", "The text displayed for using the defend command.", "", endFoldout=true)]
		[ORKEditorLayout("ownConsoleDefend", true, endCheckGroup=true, autoInit=true)]
		public ConsoleTextAction consoleDefend;
		
		// escape
		[ORKEditorHelp("Own Escape Text", "This combatant overrides the default escape text.", "")]
		[ORKEditorInfo(separator=true)]
		public bool ownConsoleEscape = false;
		
		[ORKEditorInfo("Escape Text", "The text displayed for using the escape command.", "", endFoldout=true)]
		[ORKEditorLayout("ownConsoleEscape", true, endCheckGroup=true, autoInit=true)]
		public ConsoleTextAction consoleEscape;
		
		// death
		[ORKEditorHelp("Own Death Text", "This combatant overrides the default death text.", "")]
		[ORKEditorInfo(separator=true)]
		public bool ownConsoleDeath = false;
		
		[ORKEditorInfo("Death Text", "The text displayed for dying.", "", endFoldout=true)]
		[ORKEditorLayout("ownConsoleDeath", true, endCheckGroup=true, autoInit=true)]
		public ConsoleTextAction consoleDeath;
		
		// none
		[ORKEditorHelp("Own None Text", "This combatant overrides the default none text.", "")]
		[ORKEditorInfo(separator=true)]
		public bool ownConsoleNone = false;
		
		[ORKEditorInfo("None Text", "The text displayed for doing nothing.", "", endFoldout=true)]
		[ORKEditorLayout("ownConsoleNone", true, endCheckGroup=true, autoInit=true)]
		public ConsoleTextAction consoleNone;
		
		// change member
		[ORKEditorHelp("Own Change Member Text", "This combatant overrides the default change member text.", "")]
		[ORKEditorInfo(separator=true)]
		public bool ownConsoleChangeMember = false;
		
		[ORKEditorInfo("Change Member Text", "The text displayed for changing members.", "", endFoldout=true)]
		[ORKEditorLayout("ownConsoleChangeMember", true, endCheckGroup=true, autoInit=true)]
		public ConsoleTextAction consoleChangeMember;
		
		// join battle
		[ORKEditorHelp("Own Join Battle Text", "This combatant overrides the default join battle text.", "")]
		[ORKEditorInfo(separator=true)]
		public bool ownConsoleJoinBattle = false;
		
		[ORKEditorInfo("Join Battle Text", "The text displayed for joining a battle.", "", endFoldout=true)]
		[ORKEditorLayout("ownConsoleJoinBattle", true, endCheckGroup=true, autoInit=true)]
		public ConsoleTextAction consoleJoinBattle;
		
		// level up
		[ORKEditorHelp("Own Level Up Text", "This combatant overrides the default level up text.", "")]
		[ORKEditorInfo(separator=true)]
		public bool ownConsoleLevelUp = false;
		
		[ORKEditorInfo("Level Up Text", "The text displayed for reaching a new level.", "", endFoldout=true)]
		[ORKEditorLayout("ownConsoleLevelUp", true, endCheckGroup=true, autoInit=true)]
		public ConsoleTextLevelUp consoleLevelUp;
		
		// class level up
		[ORKEditorHelp("Own Class Level Up Text", "This combatant overrides the default class level up text.", "")]
		[ORKEditorInfo(separator=true)]
		public bool ownConsoleLevelUpClass = false;
		
		[ORKEditorInfo("Class Level Up Text", "The text displayed for reaching a new class level.", "", 
			endFoldout=true, endFolds=3)]
		[ORKEditorLayout("ownConsoleLevelUpClass", true, endCheckGroup=true, autoInit=true)]
		public ConsoleTextLevelUp consoleLevelUpClass;
		
		
		// status settings
		// start levels, class, defence attributes
		[ORKEditorHelp("Start Level", "The combatants base level when first appearing in the game.", "")]
		[ORKEditorInfo("Status Settings", "Set the combatant's levels, class and other status related settings.", "")]
		[ORKEditorLimit(1, false)]
		public int startLevel = 1;
		
		[ORKEditorHelp("Class", "Select the base class of the combatant.", "")]
		[ORKEditorInfo(ORKDataType.Class, separator=true, labelText="Class Settings")]
		public int startClassID = 0;
		
		[ORKEditorHelp("Start Class Level", "The combatants class level when first appearing in the game.", "")]
		[ORKEditorLimit(1, false)]
		public int startClassLevel = 1;
		
		// other settings
		[ORKEditorHelp("Not Scanable", "This combatant can't be scanned, " +
			"i.e. the bestiary can't learn anything about it's status.", "")]
		[ORKEditorInfo(separator=true, labelText="Bestiary Settings")]
		public bool notScanable = false;
		
		[ORKEditorHelp("No Bestiary Entry", "This combatant wont get an entry in the bestiary at all.\n" +
			"If disabled, an entry will be made for the combatant, but without status information.", "")]
		[ORKEditorLayout("notScanable", true, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool noBestiaryEntry = false;
		
		// status values
		[ORKEditorHelp("No Status Development", "The combatant doesn't use status development.\n" +
			"You have to set the base 'Normal' and 'Experience' type status values instead.\n" +
			"Player combatants will receive an enemies 'Experience' type status values as a reward upon defeating them.", "")]
		[ORKEditorInfo("Status Value Settings", "Define the status development and other status value related settings.", "")]
		public bool noStatusDevelopment = false;
		
		[ORKEditorHelp("Status Value", "Set the base 'Normal' and 'Experience' type status values of the combatant.\n" +
			"Player combatants will receive an enemies 'Experience' type status values as a reward upon defeating them.", "")]
		[ORKEditorInfo(callbackBefore="check:statusdevelopment")]
		[ORKEditorLayout("noStatusDevelopment", true)]
		[ORKEditorArray(ORKDataType.StatusValue, "type", StatusValueType.Consumable, negateLimit=true)]
		public int[] startValue;
		
		[ORKEditorHelp("Status Development", "Select the status development used by this combatant.", "")]
		[ORKEditorInfo(ORKDataType.StatusDevelopment)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int statusDevelopmentID = 0;
		
		// exp rewards
		[ORKEditorHelp("Use Exp. Reward", "Define the experience reward the player receives for defeating this combatant.\n" +
			"If disabled, the combatant's experience status values will be used as his reward.", "")]
		[ORKEditorInfo("Experience Reward", "The experience reward of a combatant " +
			"can optionally differ from their defined 'Experience' status values.", "")]
		public bool useExpReward = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Experience Reward", "Adds an experience reward.", "", 
			"Remove", "Removes this experience reward.", "", 
			removeType=ORKDataType.StatusValue, removeCheckField="statusID", 
			foldout=true, foldoutText=new string[] {
				"Experience Reward", "Define the 'Experience' type status value and reward the player receives.", ""
		})]
		[ORKEditorLayout("useExpReward", true, endCheckGroup=true, autoInit=true)]
		public ExperienceReward[] expReward;
		
		// time changes
		[ORKEditorInfo("Status Value Time Changes", "'Consumable' type status values " +
			"can be changed over time in battles or in the field.", "", 
			labelText="Field")]
		[ORKEditorArray(false, "Add Field Change", "Adds a field status value time change.", "", 
			"Remove", "Removes this field status value time change.", "", 
			removeType=ORKDataType.StatusValue, removeCheckField="statusID", 
			foldout=true, foldoutText=new string[] {
			"Field Change", "'Consumable' type status values can be changed over time while in the field.", ""
		})]
		public StatusTimeChange[] fieldStatusChange = new StatusTimeChange[0];
		
		[ORKEditorInfo(endFoldout=true, endFolds=2, separator=true, labelText="Battle")]
		[ORKEditorArray(false, "Add Battle Change", "Adds a battle status value time change.", "", 
			"Remove", "Removes this battle status value time change.", "", 
			removeType=ORKDataType.StatusValue, removeCheckField="statusID", 
			foldout=true, foldoutText=new string[] {
			"Battle Change", "'Consumable' type status values can be changed over time while in battle.", ""
		})]
		public StatusTimeChange[] battleStatusChange = new StatusTimeChange[0];
		
		// attribute settings
		// defence attributes
		[ORKEditorHelp("Defence Attribute", "Select the base defence attributes for this combatant.", "")]
		[ORKEditorInfo("Attribute Settings", "Define the combatant's defence attributes and optional attribute start values.", "", 
			isPopup=true, popupType=ORKDataType.DefenceAttributes, labelText="Defence Attributes")]
		public int[] defenceAttributeID = new int[ORK.DefenceAttributes.Count];
		
		// attack attribute startvalues
		[ORKEditorInfo("Attack Attributes Start Values", 
			"Override the default start values of attack attributes.", "", endFoldout=true)]
		[ORKEditorArray(false, "Add Attack Attribute", "Adds an attack attribute start value setting.", "", 
			"Remove", "Removes this attack attributes start value setting.", "", 
			removeType=ORKDataType.AttackAttributes, removeCheckField="attributeID", 
			foldout=true, foldoutText=new string[] {"Attack Attributes Start Value", 
				"Set the start values for the selected attack attribute.", ""})]
		public AtkAttrStartValue[] atkAttrStart = new AtkAttrStartValue[0];
		
		// defence attribute start values
		[ORKEditorInfo("Defence Attributes Start Values", 
			"Override the default start values of defence attributes.", "", endFoldout=true, endFolds=2)]
		[ORKEditorArray(false, "Add Defence Attributes", "Adds a defence attributes start value setting.", "", 
			"Remove", "Removes this defence attributes start value setting.", "", 
			removeType=ORKDataType.DefenceAttributes, removeCheckField="attributeID", 
			foldout=true, foldoutText=new string[] {"Defence Attributes Start Value", 
				"Set the start values for the selected defence attributes.", ""})]
		public DefAttrStartValue[] defAttrStart = new DefAttrStartValue[0];
		
		// bonus settings
		public BonusSettings bonus = new BonusSettings();
		
		// status effects
		[ORKEditorInfo("Status Effect Settings", "A combatant can have auto status effects and " +
			"status effect immunity.", "", endFoldout=true)]
		public AutoEffects autoEffects = new AutoEffects();
		
		// level up settings
		[ORKEditorHelp("Own Level Up", "This combatant overrides the default level up settings (battle system).", "")]
		[ORKEditorInfo("Level Up Settings", "A combatant can override the default level up settings of the battle system.", "")]
		public bool ownLvlUp = false;
		
		[ORKEditorInfo(endFoldout=true, endFolds=2)]
		[ORKEditorLayout("ownLvlUp", true, endCheckGroup=true, autoInit=true)]
		public LevelUpBonus lvlUp;
		
		
		// attacks/abilities
		// attack settings
		[ORKEditorInfo("Attacks & Abilities", "Define the combatant's base attack, " +
			"counter attack, auto attack and ability development.", "", 
			"Attack Settings", "Define the combatant's base attack, " +
			"every active ability can be used as a base attack.\n" +
			"You can add multiple attacks to enable combo attacks - " +
			"the combatant will circle through the base attacks, starting with the first one.", "", 
			endFoldout=true)]
		[ORKEditorArray(false, "Add Base Attack", "Add an ability used as base attack.", "", 
			"Remove", "Remove this ability.", "", noRemoveCount=1, foldout=true, foldoutText=new string[] {
				"Base Attack", "Define the ability that will be used as base attack.", ""
		})]
		public AbilitySetting[] baseAttack = new AbilitySetting[] {new AbilitySetting()};
		
		[ORKEditorInfo("Counter Attack Settings", "Define the combatant's counter attack, " +
			"every active ability can be used as a counter attack.\n" +
			"The combatant will use the counter attack when he counters an action used against him.", "", 
			endFoldout=true)]
		public AbilitySetting counterAttack = new AbilitySetting();
		
		// auto attack
		[ORKEditorInfo("Auto Attack Settings", "Auto attacks are performed periodically without ending a " +
			"combatants turn or using its timebar.", "", endFoldout=true)]
		public AutoAttack autoAttack = new AutoAttack();
		
		// ability development
		[ORKEditorInfo(endFoldout=true)]
		public AbilityDevelopment abilityDevelopment = new AbilityDevelopment();
		
		
		// inventory & equipment
		// start inventory settings
		[ORKEditorHelp("Money", "The amount of money per currency the combatant starts with.", "")]
		[ORKEditorInfo("Inventory & Equipment", "Define the combatant's inventory and equipment.", "", 
			"Start Inventory", "The inventory the combatant will have when " +
			"first appearing in the game.\n" +
			"If group inventory is used, the combatant's inventory will be added to the group's inventory.\n" +
			"The start inventory can also be used as loot (victory gains), if the combatant is defeated by the player group.", "")]
		[ORKEditorArray(ORKDataType.Currency)]
		[ORKEditorLimit(0, false)]
		public int[] money = new int[ORK.Currencies.Count];
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Item", "Adds an item to the start inventory.", "", 
			"Remove", "Remove this item from the inventory.", "", isMove=true, isCopy=true, 
			foldout=true, foldoutText=new string[] {"Item", 
				"This item will be added to the start inventory of the combatant.", ""})]
		public ItemGain[] itemDrop = new ItemGain[0];
		
		// loot settings
		[ORKEditorHelp("Use Start Inventory", "The start inventory of the combatant will be used as loot.\n" +
			"If disabled, loot tables are used.", "")]
		[ORKEditorInfo("Loot Settings", "The loot settings define the money, items and " +
			"equipment the player group will receive upon defeating this combatant.\n" +
			"You can either use the combatant's start inventory or loot tables.", "")]
		public bool lootInventory = true;
		
		[ORKEditorHelp("Get Random", "One of the defined loot settings will be selected randomly to create the loot.\n" +
			"If disabled, all loot settings are used.", "")]
		[ORKEditorLayout("lootInventory", false)]
		public bool lootRandom = false;
		
		[ORKEditorHelp("Loot", "Select the loot setting that will be used.\n" +
			"The first loot table that fits the combatant's level will be used to generate the loot.", "")]
		[ORKEditorInfo(ORKDataType.Loot, endFoldout=true, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Loot", "Adds a loot setting that will be used.", "",
			"Remove", "Removes this loot setting.", "", isHorizontal=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public int[] lootID;
		
		// own equipment settings
		[ORKEditorHelp("Own Equipment", "Override the equipment settings of the combatant's class.\n" +
			"Classes wont influence the available equipment parts and the weapons and armors the combatant can wear.\n" +
			"If disabled, the equipment settings of the class will be used.", "")]
		[ORKEditorInfo("Equipment Settings", "A combatant can override the equipment settings of its class, " +
			"making the available equipment independent from the class.", "")]
		public bool ownEquipment = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownEquipment", true, endCheckGroup=true, autoInit=true)]
		public AvailableEquipment equipment;
		
		// start equipment
		[ORKEditorInfo("Start Equipment", "The start equipment will be " +
			"equipped when first adding a combatant to the game and his level is within the start " +
			"and maximum level settings of the start equipment.", "", endFoldout=true, endFolds=2)]
		[ORKEditorArray(false, "Add Start Equipment", "Adds a new start equipment to this combatant.", "", 
			"Remove", "Removes this start equipment.", "", 
			foldout=true, foldoutText=new string[] {"Equipment Set", 
			"This equipment will be the combatant's start equipment within a defined level range.", ""})]
		public StartEquipment[] startEquipment = new StartEquipment[0];
		
		
		// battle settings
		// battle start distance
		[ORKEditorHelp("Auto Start Battles", "Automatically start battles when the player comes within a defined range of this combatant.\n" +
			"Only used when the player and this combatant are enemies.", "")]
		[ORKEditorInfo("Battle Settings", "Define this combatant's battle related settings " +
			"like base chances, AI and death settings.", "", 
			labelText="Battle Start Range")]
		public bool autoStartBattles = true;
		
		[ORKEditorLayout("autoStartBattles", true, endCheckGroup=true)]
		public Range battleStartRange = new Range(2);
		
		// battle menu
		[ORKEditorHelp("Own Battle Menu", "The combatant has it's own battle menu.\n" +
			"This setting overrides the class battle menu setting and the default battle menu.", "")]
		[ORKEditorInfo(separator=true, labelText="Battle Menu")]
		public bool ownBM = false;
		
		[ORKEditorHelp("Battle Menu", "Select the battle menu used by this combatant.", "")]
		[ORKEditorInfo(ORKDataType.BattleMenu)]
		[ORKEditorLayout("ownBM", true)]
		public int menuID = 0;
		
		// turn based menu
		[ORKEditorHelp("Own Turn Based Menu", "Use a different battle menu in turn based battles.", "")]
		public bool useTurnBasedMenu = false;
		
		[ORKEditorHelp("Turn Based Menu", "Select the battle menu that will be used in turn based battles.", "")]
		[ORKEditorInfo(ORKDataType.BattleMenu)]
		[ORKEditorLayout("useTurnBasedMenu", true, endCheckGroup=true)]
		public int turnBasedMenuID = 0;
		
		// active time menu
		[ORKEditorHelp("Own Active Time Menu", "Use a different battle menu in active time battles.", "")]
		public bool useActiveTimeMenu = false;
		
		[ORKEditorHelp("Active Time Menu", "Select the battle menu that will be used in active time battles.", "")]
		[ORKEditorInfo(ORKDataType.BattleMenu)]
		[ORKEditorLayout("useActiveTimeMenu", true, endCheckGroup=true)]
		public int activeTimeMenuID = 0;
		
		// real time menu
		[ORKEditorHelp("Own Real Time Menu", "Use a different battle menu in real time battles.", "")]
		public bool useRealTimeMenu = false;
		
		[ORKEditorHelp("Real Time Menu", "Select the battle menu that will be used in real time battles.", "")]
		[ORKEditorInfo(ORKDataType.BattleMenu)]
		[ORKEditorLayout("useRealTimeMenu", true, endCheckGroup=true)]
		public int realTimeMenuID = 0;
		
		// phase battle menu
		[ORKEditorHelp("Own Phase Menu", "Use a different battle menu in phase battles.", "")]
		public bool usePhaseMenu = false;
		
		[ORKEditorHelp("Phase Menu", "Select the battle menu that will be used in phase battles.", "")]
		[ORKEditorInfo(ORKDataType.BattleMenu)]
		[ORKEditorLayout("usePhaseMenu", true, endCheckGroup=true, endGroups=2)]
		public int phaseMenuID = 0;
		
		// chances
		[ORKEditorInfo("Base Counter Chance", "Define the base counter chance of this combatant.\n" +
			"The counter chance decides if the combatant counters an attack (i.e. when received damage).\n" +
			"The counter is performed if a random float number between two values (default 0 and 100, you can change " +
			"this in the game settings) is less or equal to this value.", "", endFoldout=true)]
		public FloatValue counterChance = new FloatValue();
		
		[ORKEditorInfo("Base Block Chance", "Define the base block chance of this combatant.\n" +
			"Attacks and abilities can be blocked (if enabled) if a random float number between two values " +
			"(default 0 and 100, you can change this in the game settings) is less or equal to this value.", "", endFoldout=true)]
		public FloatValue blockChance = new FloatValue();
		
		[ORKEditorInfo("Base Experience Factor", "Define the base experience factor of this combatant.\n" +
			"The experience factor influences the experience a combatant gains from battle. E.g.:\n" +
			"- factor 1: The combatant gets 100 % of the experience.\n" +
			"- factor 0.5: The combatant gets 50 % of the experience.\n" +
			"- factor 2: The combatant gets 200 % of the experience.\n" +
			"A negative experience factor is not possible, the smallest factor is 0.", "", endFoldout=true)]
		public FloatValue experienceFactor = new FloatValue(1);
		
		// death settings
		[ORKEditorHelp("No Revive", "The combatant can't be revived when he is dead.", "")]
		[ORKEditorInfo("Death Settings", "Define general settings related to the combatant's death and " +
			"the changes that happen when this combatant dies.\n" +
			"The player can learn a new log text (or complete log) when this combatant dies.\n" +
			"Combatants can change game variables when they die.", "")]
		public bool noRevive = false;
		
		[ORKEditorHelp("Leave on Death", "The combatant leaves the group he belongs to if he dies.", "")]
		public bool leaveOnDeath = false;
		
		[ORKEditorHelp("Keep Prefab", "The combatant's prefab wont be destroyed when the combatant dies.\n" +
			"Members of the player group will never be destroyed on death.", "")]
		public bool deathKeepPrefab = false;
		
		[ORKEditorHelp("Sympathy Change", "Additional to the faction's kill member sympathy change, this value will be added to the change.\n" +
			"The sympathy for all factions participating in the attack on the combatant will be changed.\n" +
			"Use negative values to decrease sympathy, positive values to increase.", "")]
		public float sympathyChange = 0;
		
		// death changes
		// learn log
		[ORKEditorHelp("Learn Log Text", "The player learns a new log text or complete log.", "")]
		[ORKEditorInfo(separator=true, labelText="Log Text")]
		public bool learnLog = false;
		
		[ORKEditorHelp("Complete Log", "Learn all log texts of a log.\n" +
			"If disabled, only a selected log text will be learned.", "")]
		[ORKEditorLayout("learnLog", true)]
		public bool completeLog = false;
		
		[ORKEditorHelp("Log Text", "Select the log text the player will learn.", "")]
		[ORKEditorInfo(ORKDataType.LogText)]
		[ORKEditorLayout("completeLog", false)]
		public int logTextID = 0;
		
		[ORKEditorHelp("Log", "Select the log the player will learn completely.", "")]
		[ORKEditorInfo(ORKDataType.Log)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int logID = 0;
		
		[ORKEditorHelp("Show Console", "Show the log's learning/update text in the console.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool logShowConsole = true;
		
		// variable changes
		[ORKEditorInfo(endFoldout=true, separator=true, labelText="Variable Changes")]
		public VariableSetter variables = new VariableSetter();
		
		// steal item
		[ORKEditorHelp("Steal Item", "Items can be stolen from the combatant.", "")]
		[ORKEditorInfo("Steal Settings", "This settings decide if an item (or money) can be stolen from the combatant.\n" +
			"Player combatants need to have the item or amount of money in the inventory to allow stealing them (it will be removed " +
			"from the inventory).\n" +
			"Other combatant's don't need the item or amount of money in the inventory and it wont be removed from it.", "", 
			labelText="Steal Item Settings")]
		public bool stealItem = false;
		
		[ORKEditorHelp("Steal Factor", "The steal chance is multiplied by this number.\n" +
			"E.g. if an ability has a steal chance of 50 % (including bonuses) and the " +
			"steal factor is 0.5, the steal chance will be reduced to 25 %.", "")]
		[ORKEditorLayout("stealItem", true)]
		public float stealItemFactor = 1.0f;
		
		[ORKEditorHelp("Fix Item", "A defined item will be stolen.\n" +
			"If not set, a random item from the inventory will be stolen.\n" +
			"This setting wont be used if the abilities steal settings use a fix item.", "")]
		public bool stealFixItem = true;
		
		[ORKEditorHelp("Type", "Which type of item can be stolen.\n" +
			"Either item, weapon or armor.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("stealFixItem", true)]
		public ItemDropType stealItemType = ItemDropType.Item;
		
		[ORKEditorHelp("Item", "Set the item, weapon or armor that can be stolen from this combatant.", "")]
		[ORKEditorInfo(isPopup=true, itemFieldName="stealItemType")]
		[ORKEditorLayout(endCheckGroup=true)]
		public int stealItemID = 0;
		
		[ORKEditorHelp("Steal Once", "If enabled, the item can be stolen only once.\n" +
			"If not set, the item can be stolen multiple times.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool stealItemOnce = false;
		
		// steal money
		[ORKEditorHelp("Steal Money", "Money can be stolen from the combatant.", "")]
		[ORKEditorInfo(separator=true, labelText="Steal Money Settings")]
		public bool stealMoney = false;
		
		[ORKEditorHelp("Steal Factor", "The steal chance is multiplied by this number.\n" +
			"E.g. if an ability has a steal chance of 50 % (including bonuses) and the " +
			"steal factor is 0.5, the steal chance will be reduced to 25 %.", "")]
		[ORKEditorLayout("stealMoney", true)]
		public float stealMoneyFactor = 1.0f;
		
		[ORKEditorHelp("Money Amount", "The amount of money that can be stolen.", "")]
		[ORKEditorLimit(0, false)]
		public int stealMoneyAmount = 0;
		
		[ORKEditorHelp("Steal Once", "If enabled, the money can be stolen only once.\n" +
			"If not set, the money can be stolen multiple times.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool stealMoneyOnce = false;
		
		// ai settings
		[ORKEditorHelp("AI Controlled", "This combatant is AI controlled (only used by combatants of the player group).\n" +
			"If you set a player combatant to be AI controlled, you wont have to select battle commands (if he's not the actual player).\n" +
			"Other combatants will still perform actions if they aren't AI controlled.", "")]
		[ORKEditorInfo("AI Settings", "Combatants can be AI controlled in battles.\n" +
			"If you set a player combatant to be AI controlled, you wont have to select battle commands (if he's not the actual player).\n" +
			"Other combatants will still perform actions if they aren't AI controlled.\n" +
			"If none of the battle AIs find a performable action, the base attack is used (if possible).", "")]
		public bool aiControlled = true;
		
		[ORKEditorHelp("Not Controllable", "This combatant is not controllable by the player (when member of the player group).\n" +
			"The combatant can still be controlled if set as the player in the event system " +
			"(or being the first/only combatant in the player group).\n" +
			"If disabled, the player can control this combatant.", "")]
		[ORKEditorLayout("aiControlled", true, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool notControllable = false;
		
		// target settings
		[ORKEditorHelp("Nearest Target", "The nearest target will be used when attacking, else a random target in range.", "")]
		[ORKEditorInfo(separator=true, labelText="Target Selection Settings")]
		public bool aiNearestTarget = false;
		
		[ORKEditorHelp("Attack Last Target", "The last target that was attacked will be used for the next attack.", "")]
		public bool attackLastTarget = false;
		
		[ORKEditorHelp("Attack Group Target", "The combatant will attack a group target (if possible).", "")]
		public bool attackGroupTarget = false;
		
		[ORKEditorHelp("Attack Individual Target", "The combatant will attack an individual target (if possible).", "")]
		public bool attackIndividualTarget = false;
		
		// aggression settings
		[ORKEditorHelp("Aggression Type", "Select when the combatant will become aggressive:\n" +
			"- Always: The combatant will always be aggressive.\n" +
			"- On Damage: The combatant will become aggressive when he received damage.\n" +
			"- On Selection: The combatant will become aggressive when selected as a target for a battle action or as group target.\n" +
			"- On Action: The combatant will become aggressive when another combatant starts using a battle action against him.\n" +
			"An aggressive combatant will hunt enemies in the field and attack them in 'Real Time Battle Areas'.", "")]
		[ORKEditorInfo(separator=true, labelText="Aggression Settings")]
		public AggressionType aggressionType = AggressionType.Always;
		
		[ORKEditorHelp("Notify Group", "The combatant will notify his group when changing aggression state " +
			"(i.e. when becoming aggressive or stop being aggressive).", "")]
		[ORKEditorInfo(separator=true)]
		public bool aggressionNotifyGroup = true;
		
		[ORKEditorHelp("React to Group", "The combatant will change his aggression state " +
			"as well when notified by the group.", "")]
		public bool aggressionReactGroup = true;
		
		[ORKEditorHelp("Notify Faction", "The combatant will notify his faction when changing aggression state " +
			"(i.e. when becoming aggressive or stop being aggressive).\n" +
			"All faction members in the scene will be notified.", "")]
		public bool aggressionNotifyFaction = false;
		
		[ORKEditorHelp("React to Faction", "The combatant will change his aggression state " +
			"as well when notified by the faction.", "")]
		public bool aggressionReactFaction = false;
		
		[ORKEditorInfo("Notification Range", "Set the range for group and faction notifications.\n" +
			"Only combatants in this range will be notified of the aggression state change. " +
			"Keep in mind that notified combatants can also become aggressive and notify other combatants as well.", "", 
			labelText="Group Range")]
		public Range aggressionNotifyRangeGroup = new Range(20);
		
		[ORKEditorInfo(endFoldout=true, separator=true, labelText="Faction Range")]
		public Range aggressionNotifyRangeFaction = new Range(20);
		
		// battle AI
		[ORKEditorHelp("Timeout (s)", "The timeout in seconds between two AI actions.", "")]
		[ORKEditorInfo(separator=true, labelText="Action Settings")]
		[ORKEditorLimit(0.0f, false)]
		public float aiTimeout = 0;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(true, "Add Battle AI", "Adds a battle AI to this combatant.", "", 
			"Remove", "Removes this battle AI.", "", isMove=true, isCopy=true, 
			labelText="Priority", removeType=ORKDataType.BattleAI, removeCheckField="battleAI")]
		public AIBehaviour[] aiBehaviour = new AIBehaviour[0];
		
		// battle animations
		//defend animation
		[ORKEditorHelp("Animate Defend", "The defend command will perform a series of battle events when used.", "")]
		[ORKEditorInfo("Battle Animations", "Define the battle events used to animate default actions, e.g. defend.", "", 
			labelText="Defend Animation")]
		public bool animateDefend = false;
		
		[ORKEditorArray(false, "Add Animation", "Adds a battle event to the defend command.\n" +
			"All battle events (passing the chance check) will be performed one by one.", "", 
			"Remove", "Removes this battle event from the list.", "", isCopy=true, isMove=true, noRemoveCount=1,  
			foldout=true, foldoutText=new string[] {"Defend Battle Event", 
				"Define the battle event, chance and battle systems the event will be performed in.", ""})]
		[ORKEditorLayout("animateDefend", true, endCheckGroup=true, autoInit=true, autoSize=1)]
		public BattleAnimation[] defendEvent;
		
		// escape animation
		[ORKEditorHelp("Animate Escape", "The escape command will perform a series of battle events when used.", "")]
		[ORKEditorInfo(separator=true, labelText="Escape Animation")]
		public bool animateEscape = false;
		
		[ORKEditorArray(false, "Add Animation", "Adds a battle event to the escape command.\n" +
			"All battle events (passing the chance check) will be performed one by one.", "", 
			"Remove", "Removes this battle event from the list.", "", isCopy=true, isMove=true, noRemoveCount=1,  
			foldout=true, foldoutText=new string[] {"Escape Battle Event", 
				"Define the battle event, chance and battle systems the event will be performed in.", ""})]
		[ORKEditorLayout("animateEscape", true, endCheckGroup=true, autoInit=true, autoSize=1)]
		public BattleAnimation[] escapeEvent;
		
		// death animation
		[ORKEditorHelp("Animate Death", "The death of the combatant will perform a series of battle events.", "")]
		[ORKEditorInfo(separator=true, labelText="Death Animation")]
		public bool animateDeath = false;
		
		[ORKEditorArray(false, "Add Animation", "Adds a battle event to the death animation.\n" +
			"All battle events (passing the chance check) will be performed one by one.", "", 
			"Remove", "Removes this battle event from the list.", "", isCopy=true, isMove=true, noRemoveCount=1,  
			foldout=true, foldoutText=new string[] {"Death Battle Event", 
				"Define the battle event, chance and battle systems the event will be performed in.", ""})]
		[ORKEditorLayout("animateDeath", true, endCheckGroup=true, autoInit=true, autoSize=1)]
		public BattleAnimation[] deathEvent;
		
		// none animation
		[ORKEditorHelp("Animate None", "Doing nothing (none action) will perform a series of battle events.", "")]
		[ORKEditorInfo(separator=true, labelText="None Animation")]
		public bool animateNone = false;
		
		[ORKEditorArray(false, "Add Animation", "Adds a battle event to the none animation.\n" +
			"All battle events (passing the chance check) will be performed one by one.", "", 
			"Remove", "Removes this battle event from the list.", "", isCopy=true, isMove=true, noRemoveCount=1,  
			foldout=true, foldoutText=new string[] {"None Battle Event", 
				"Define the battle event, chance and battle systems the event will be performed in.", ""})]
		[ORKEditorLayout("animateNone", true, endCheckGroup=true, autoInit=true, autoSize=1)]
		public BattleAnimation[] noneEvent;
		
		// retreat animation (change member)
		[ORKEditorHelp("Animate Retreat", "Retreating from battle when changing members will perform a series of battle events.", "")]
		[ORKEditorInfo(separator=true, labelText="Retreat Animation (Change Member)")]
		public bool animateRetreat = false;
		
		[ORKEditorArray(false, "Add Animation", "Adds a battle event to the retreat animation.\n" +
			"All battle events (passing the chance check) will be performed one by one.\n" +
			"One of the retreat animations must containa 'Calculate' step to change the members.", "", 
			"Remove", "Removes this battle event from the list.", "", isCopy=true, isMove=true, noRemoveCount=1,  
			foldout=true, foldoutText=new string[] {"Retreat Battle Event", 
				"Define the battle event, chance and battle systems the event will be performed in.", ""})]
		[ORKEditorLayout("animateRetreat", true, endCheckGroup=true, autoInit=true, autoSize=1)]
		public BattleAnimation[] retreatEvent;
		
		// enter battle animation (change member)
		[ORKEditorHelp("Animate Enter Battle", "Entering the battle when changing members will perform a series of battle events.", "")]
		[ORKEditorInfo(separator=true, labelText="Enter Battle Animation (Change Member)")]
		public bool animateEnterBattle = false;
		
		[ORKEditorArray(false, "Add Animation", "Adds a battle event to the enter battle animation.\n" +
			"All battle events (passing the chance check) will be performed one by one.", "", 
			"Remove", "Removes this battle event from the list.", "", isCopy=true, isMove=true, noRemoveCount=1,  
			foldout=true, foldoutText=new string[] {"Enter Battle Event", 
				"Define the battle event, chance and battle systems the event will be performed in.", ""})]
		[ORKEditorLayout("animateEnterBattle", true, endCheckGroup=true, autoInit=true, autoSize=1)]
		public BattleAnimation[] enterBattleEvent;
		
		// enter battle animation (change member)
		[ORKEditorHelp("Animate Join Battle", "Joining the battle when using 'Auto Join' during battles will perform a series of battle events.", "")]
		[ORKEditorInfo(separator=true, labelText="Join Battle Animation (Auto Join)")]
		public bool animateJoinBattle = false;
		
		[ORKEditorHelp("Look At Enemies", "The combatant will automatically look at his enemies when joining a battle.", "")]
		[ORKEditorLayout("animateJoinBattle", false)]
		public bool joinLookAt = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Animation", "Adds a battle event to the join battle animation.\n" +
			"All battle events (passing the chance check) will be performed one by one.", "", 
			"Remove", "Removes this battle event from the list.", "", isCopy=true, isMove=true, noRemoveCount=1,  
			foldout=true, foldoutText=new string[] {"Join Battle Event", 
				"Define the battle event, chance and battle systems the event will be performed in.", ""})]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, autoInit=true, autoSize=1)]
		public BattleAnimation[] joinBattleEvent;
		
		
		// shortcut settings
		[ORKEditorHelp("Use Class Shortcuts", "The combatant will use class shortcut lists.\n" +
			"I.e. the number of available shortcut lists and default shortcuts are defind by the current class - " +
			"changing the class will also change the shortcut lists.\n" +
			"If disabled, all classes share the same shortcut lists.", "")]
		[ORKEditorInfo("Shortcut Settings", "Shortcuts are used to quickly use items or abilities, or equip weapons and armors.\n" +
			"They can be used via control maps or 'Combatant' type HUDs with shortcut elements.\n" +
			"Shortcuts are organized in lists, each list consists of a variable amount of slots (index based). " +
			"Only the currently active list can be used - switching between lists can be done using the event system, " +
			"e.g. with a global event called when pressing an input key.\n" +
			"The shortcut lists can optionally also be changed with the class, " +
			"allowing the player to set up different lists for different classes.", "")]
		public bool useClassShortcuts = false;
		
		[ORKEditorHelp("Shortcut List Count", "The number of available shortcut lists.\n" +
			"Each list consists of a variable amount of slots (index based). " +
			"Lists can be changed using the event system.", "")]
		[ORKEditorLayout("useClassShortcuts", false)]
		[ORKEditorLimit(0, false)]
		public int shortcutListCount = 1;
		
		[ORKEditorInfo("Default Shortcuts", "Shortcuts are used to quickly use items or abilities, or equip weapons and armors.\n" +
			"They can be used via control maps or 'Combatant' type HUDs with shortcut elements.\n" +
			"The default shortcuts are set up when the combatant is created.", "", endFoldout=true, endFolds=3)]
		[ORKEditorArray(false, "Add Shortcut", "Adds a default shortcut.", "", 
			"Remove", "Removes this shortcut.", "", isMove=true, isCopy=true, 
			foldout=true, foldoutText=new string[] {"Shortcut", 
			"The selected shortcut slot will be assigned with the defined shortcut.", ""})]
		[ORKEditorLayout(endCheckGroup=true)]
		public ShortcutSlot[] defaultShortcut = new ShortcutSlot[0];
		
		
		// animation/movement
		// animations
		[ORKEditorHelp("System Type", "Select the animation system used by this combatant:\n" +
			"- Legacy: Unity's legacy animation system.\n" +
			"- Mecanim: Unity's mecanim system.\n" +
			"- Custom: A custom animation system.", "")]
		[ORKEditorInfo("Animations & Movement", "Define the combatant's animations and movement settings.", "", 
			"Animation Settings", "Select the animation system and animations used by this combatant.", "")]
		public AnimationSystem animationSystem = AnimationSystem.Legacy;
		
		[ORKEditorHelp("Component Name", "The name of the component used for the custom animation system.\n" +
			"The component will be used to call methods defined by animations.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("animationSystem", AnimationSystem.Custom, endCheckGroup=true)]
		public string animationCustomName = "";
		
		// animation selection
		[ORKEditorHelp("Animations", "Select the animation settings used to animate this combatant.", "")]
		[ORKEditorInfo(ORKDataType.Animation, separator=true, labelText="Animations")]
		public int animationID = 0;
		
		[ORKEditorHelp("Use Battle", "Use a different animation setting to animate this combatant in battle.\n" +
			"If disabled or an animation isn't defind in the battle animations, the same animation setting will be used in field and battle.", "")]
		public bool useBattleAnims = false;
		
		[ORKEditorHelp("Animations (Battle)", "Select the animation settings used to animate this combatant in battle.", "")]
		[ORKEditorInfo(ORKDataType.Animation)]
		[ORKEditorLayout("useBattleAnims", true, endCheckGroup=true)]
		public int animationBattleID = 0;
		
		// auto movement animation
		[ORKEditorHelp("Use Auto Animation", "ORK will automatically handle movement animations " +
			"(idle, walk, run, sprint, fall, land) based on the combatant's movement.\n" +
			"If disabled, you'll have to manage the movement animations with your own scripts.", "")]
		[ORKEditorInfo(separator=true, labelText="Automatic Move Animation")]
		public bool autoMoveAnimation = false;
		
		[ORKEditorHelp("Minimum Fall Time", "The minimum fall time in seconds to play the land animation.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("autoMoveAnimation", true)]
		public float amaMinFallTime = 0.3f;
		
		[ORKEditorHelp("Minimum Run Speed", "The minimum speed to play the run animation.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float amaMinRunSpeed = 3;
		
		[ORKEditorHelp("Run Speed Threshold", "The threshold is used for a smoother change between walk/run animations.\n" +
			"The run animation will be played when the combatant's speed is above 'Minimum Run Speed + threshold', " +
			"the walk animation will be played again when the speed is below 'Minimum Run Speed - threshold'.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float amaRunSpeedThreshold = 0;
		
		[ORKEditorHelp("Minimum Sprint Speed", "The minimum speed to play the sprint animation.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float amaMinSprintSpeed = 6;
		
		[ORKEditorHelp("Sprint Speed Threshold", "The threshold is used for a smoother change between run/sprint animations.\n" +
			"The sprint animation will be played when the combatant's speed is above 'Minimum Sprint Speed + threshold', " +
			"the run animation will be played again when the speed is below 'Minimum Sprint Speed - threshold'.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout(endCheckGroup=true)]
		[ORKEditorInfo(endFoldout=true)]
		public float amaSprintSpeedThreshold = 0;
		
		// movement settings
		[ORKEditorInfo("Movement Settings", "Set the combatants move speed and AI movement settings.\n" +
			"The move speed defined here can be used by events to determine the speed of the combatant when moving.\n" +
			"The move speed can be changed by classes, status effects, passive abilities, weapons and armors.\n" +
			"The AI movement settings determine how the combatant will move when not controlled by the player.", "")]
		[ORKEditorLimit(0.0f, false)]
		public MovementSettings moveSettings = new MovementSettings();
		
		// AI movement
		[ORKEditorHelp("Use Move AI", "The combatant uses a move AI to determine it's movement behaviour.", "")]
		[ORKEditorInfo(separator=true, labelText="AI Movement Settings")]
		public bool useMoveAI = false;
		
		[ORKEditorHelp("Move AI", "Select the move AI that will be used.", "")]
		[ORKEditorInfo(ORKDataType.MoveAI, endFoldout=true, endFolds=2)]
		[ORKEditorLayout("useMoveAI", true, endCheckGroup=true)]
		public int moveID = 0;
		
		public CombatantSetting()
		{
			
		}
		
		public CombatantSetting(string name) : base(name)
		{
			
		}
		
		public override void SetData(DataObject data)
		{
			base.SetData(data);
			
			if(this.useObjectVariables && 
				data.Contains<bool>("objectVariablesLocal"))
			{
				this.objectVariables = new ObjectVariableSetting();
				data.Get("objectVariablesLocal", ref this.objectVariables.isLocal);
				data.Get("objectVariablesID", ref this.objectVariables.objectVariablesID);
			}
			
			// check start equipment
			AvailableEquipment availEquip = this.ownEquipment ? 
				this.equipment : ORK.Classes.Get(this.startClassID).equipment;
			for(int i=0; i<this.startEquipment.Length; i++)
			{
				int prevLvl = 0;
				if(i > 0)
				{
					prevLvl = this.startEquipment[i-1].maxLevel;
				}
				this.startEquipment[i].CheckEquipment(availEquip, prevLvl);
			}
		}
		
		public void DoDeathChanges()
		{
			// learn log
			if(this.learnLog)
			{
				if(this.completeLog)
				{
					ORK.Game.Logs.Learn(this.logID, this.logShowConsole);
				}
				else
				{
					ORK.Game.Logs.LearnText(this.logTextID, this.logShowConsole);
				}
			}
			// change variables
			this.variables.SetVariables();
		}
		
		
		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public GameObject GetPrefab(Combatant combatant, ref int prefabIndex)
		{
			// conditional prefab
			for(int i=0; i<this.conditionalPrefab.Length; i++)
			{
				if(this.conditionalPrefab[i].Check(combatant))
				{
					prefabIndex = i;
					return this.conditionalPrefab[i].prefab;
				}
			}
			// base prefab
			prefabIndex = -1;
			return this.prefab;
		}
		
		
		/*
		============================================================================
		Development functions
		============================================================================
		*/
		public StatusDevelopment GetStatusDevelopment()
		{
			if(this.noStatusDevelopment)
			{
				return null;
			}
			else
			{
				return ORK.StatusDevelopments.Get(this.statusDevelopmentID);
			}
		}
		
		
		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public IContentSimple GetTypeContent()
		{
			return ORK.Classes.Get(this.startClassID);
		}

		public string GetInfo(Combatant c)
		{
			return "";
		}

		public int TypeID
		{
			get{ return this.startClassID;}
		}
		
		public string GetName()
		{
			return this.languageInfo[ORK.Game.Language].name;
		}

		public string GetDescription()
		{
			return this.languageInfo[ORK.Game.Language].description;
		}

		public string GetIconTextCode()
		{
			return TextCode.CombatantIcon + this.realID + "#";
		}

		public Texture2D GetIcon()
		{
			return this.languageInfo[ORK.Game.Language].icon;
		}

		public GUIContent GetContent()
		{
			return this.languageInfo[ORK.Game.Language].GetContent();
		}

		public int ID
		{
			get{ return this.realID;}
		}
		
		public Portrait GetPortrait(int typeID)
		{
			for(int i=0; i<this.portrait.Length; i++)
			{
				if(this.portrait[i].typeID == typeID)
				{
					return this.portrait[i];
				}
			}
			return null;
		}
	}
}
