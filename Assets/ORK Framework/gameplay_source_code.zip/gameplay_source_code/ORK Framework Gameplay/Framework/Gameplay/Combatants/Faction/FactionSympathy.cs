
using System;

namespace ORKFramework
{
	public class FactionSympathy : BaseData
	{
		[ORKEditorHelp("Faction Sympathy", "The sympathy this faction will have for other factions at the start of a new game.\n" +
			"The sympathy for the faction itself is always 0 and will be ignored in the game.", "")]
		[ORKEditorArray(ORKDataType.Faction)]
		public float[] sympathy = new float[ORK.Factions.Count];
		
		public FactionSympathy()
		{
			
		}
		
		public FactionSympathy(float[] values)
		{
			this.sympathy = new float[values.Length];
			System.Array.Copy(values, sympathy, this.sympathy.Length);
		}
	}
}
