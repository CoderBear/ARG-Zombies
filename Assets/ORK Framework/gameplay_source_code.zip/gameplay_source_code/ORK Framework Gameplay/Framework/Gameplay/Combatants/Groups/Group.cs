
using System.Collections.Generic;
using UnityEngine;
using ORKFramework.Behaviours;

namespace ORKFramework
{
	public class Group : ISaveData
	{
		private int factionID = 0;
		
		
		// items
		private Inventory inventory;
		
		private List<IShortcut> loot = new List<IShortcut>();
		
		
		// group targets
		private SelectedTargets selectedTargets;
		
		
		// members
		private List<Combatant> members = new List<Combatant>();
		
		private List<Combatant> battleMembers = new List<Combatant>();
		
		private List<Combatant> lockedBattleMembers = new List<Combatant>();
		
		private List<Combatant> inactiveMembers = new List<Combatant>();
		
		private List<Combatant> hiddenMembers = new List<Combatant>();
		
		private int battleLeaderIndex = 0;
		
		
		// spawner
		private CombatantSpawner spawner;
		
		private int spawnerIndex = -1;
		
		private bool spawnerRespawn = false;
		
		private BattleSystemType battleType;
		
		
		// change
		public event GroupChanged Changed;
		
		public Group()
		{
			this.inventory = new Inventory(this);
		}
		
		public Group(int fid)
		{
			this.factionID = fid;
			this.inventory = new Inventory(this);
		}
		
		public Group(DataObject data)
		{
			this.LoadGame(data);
		}
		
		public void FireChanged()
		{
			if(this.Changed != null)
			{
				this.Changed(this);
			}
		}
		
		
		/*
		============================================================================
		Time functions (only active player group)
		============================================================================
		*/
		public void Tick(float time, float battleTime)
		{
			// tick all unspawned members
			for(int i=0; i<this.members.Count; i++)
			{
				if(this.members[i].GameObject == null)
				{
					this.members[i].Tick(time, battleTime);
				}
			}
		}
		
		
		/*
		============================================================================
		Get/Set functions
		============================================================================
		*/
		public int FactionID
		{
			get{ return this.factionID;}
			set{ this.factionID = value;}
		}
		
		public Inventory Inventory
		{
			get
			{
				if(ORK.InventorySettings.IsIndividual() && 
					this.Leader != null)
				{
					return this.Leader.Inventory;
				}
				return this.inventory;
			}
		}
		
		public List<IShortcut> Loot
		{
			get{ return this.loot;}
		}
		
		public int Size
		{
			get{ return this.members.Count;}
		}
		
		public int BattleSize
		{
			get{ return this.battleMembers.Count;}
		}
		
		public int NonBattleSize
		{
			get{ return this.members.Count - this.battleMembers.Count;}
		}
		
		
		/*
		============================================================================
		Group target functions
		============================================================================
		*/
		public SelectedTargets SelectedTargets
		{
			get
			{
				if(this.selectedTargets == null)
				{
					this.selectedTargets = new SelectedTargets(this);
				}
				return this.selectedTargets;
			}
		}
		
		public void ClearTargets()
		{
			this.SelectedTargets.Clear();
			for(int i=0; i<this.members.Count; i++)
			{
				this.members[i].SelectedTargets.Clear();
			}
		}
		
		
		/*
		============================================================================
		Level functions
		============================================================================
		*/
		public int AverageLevel
		{
			get
			{
				int lvl = 0;
				for(int i=0; i<this.members.Count; i++)
				{
					lvl += this.members[i].Level;
				}
				return lvl / this.members.Count;
			}
		}
		
		public int AverageBattleLevel
		{
			get
			{
				int lvl = 0;
				for(int i=0; i<this.battleMembers.Count; i++)
				{
					lvl += this.battleMembers[i].Level;
				}
				return lvl / this.battleMembers.Count;
			}
		}
		
		public int AverageMaxLevel
		{
			get
			{
				int lvl = 0;
				for(int i=0; i<this.members.Count; i++)
				{
					lvl += this.members[i].MaxLevel;
				}
				return lvl / this.members.Count;
			}
		}
		
		public int AverageBattleMaxLevel
		{
			get
			{
				int lvl = 0;
				for(int i=0; i<this.battleMembers.Count; i++)
				{
					lvl += this.battleMembers[i].MaxLevel;
				}
				return lvl / this.battleMembers.Count;
			}
		}
		
		public int AverageClassLevel
		{
			get
			{
				int lvl = 0;
				for(int i=0; i<this.members.Count; i++)
				{
					lvl += this.members[i].ClassLevel;
				}
				return lvl / this.members.Count;
			}
		}
		
		public int AverageBattleClassLevel
		{
			get
			{
				int lvl = 0;
				for(int i=0; i<this.battleMembers.Count; i++)
				{
					lvl += this.battleMembers[i].ClassLevel;
				}
				return lvl / this.battleMembers.Count;
			}
		}
		
		public int AverageMaxClassLevel
		{
			get
			{
				int lvl = 0;
				for(int i=0; i<this.members.Count; i++)
				{
					lvl += this.members[i].MaxClassLevel;
				}
				return lvl / this.members.Count;
			}
		}
		
		public int AverageBattleMaxClassLevel
		{
			get
			{
				int lvl = 0;
				for(int i=0; i<this.battleMembers.Count; i++)
				{
					lvl += this.battleMembers[i].MaxClassLevel;
				}
				return lvl / this.battleMembers.Count;
			}
		}
		
		public int AverageTurn
		{
			get
			{
				int lvl = 0;
				for(int i=0; i<this.members.Count; i++)
				{
					lvl += this.members[i].Turn;
				}
				return lvl / this.members.Count;
			}
		}
		
		public int AverageBattleTurn
		{
			get
			{
				int lvl = 0;
				for(int i=0; i<this.battleMembers.Count; i++)
				{
					lvl += this.battleMembers[i].Turn;
				}
				return lvl / this.battleMembers.Count;
			}
		}
		
		
		/*
		============================================================================
		Get group functions
		============================================================================
		*/
		public List<Combatant> GetGroup()
		{
			return this.members;
		}
		
		public List<Combatant> GetBattle()
		{
			return this.battleMembers;
		}
		
		public List<Combatant> GetNonBattle()
		{
			List<Combatant> list = new List<Combatant>(this.members);
			for(int i=0; i<this.battleMembers.Count; i++)
			{
				list.Remove(this.battleMembers[i]);
			}
			return list;
		}
		
		public List<Combatant> GetInactiveGroup()
		{
			return this.inactiveMembers;
		}
		
		
		/*
		============================================================================
		Faction functions
		============================================================================
		*/
		public bool IsPlayerControlled()
		{
			return this == ORK.Game.ActiveGroup;
		}
		
		public bool IsEnemy(Combatant c)
		{
			return c != null && c.Group != null && 
				ORK.Game.Faction.IsEnemy(this.factionID, c.Group.FactionID);
		}
		
		public bool IsEnemy(int id)
		{
			return ORK.Game.Faction.IsEnemy(this.factionID, id);
		}
		
		
		/*
		============================================================================
		Leader functions
		============================================================================
		*/
		public Combatant Leader
		{
			get
			{
				if(ORK.Control.InBattle)
				{
					if(this.battleLeaderIndex >= 0 && 
						this.battleLeaderIndex < this.battleMembers.Count)
					{
						return this.battleMembers[this.battleLeaderIndex];
					}
				}
				if(this.members.Count > 0)
				{
					return this.members[0];
				}
				return null;
			}
		}
		
		public void SetLeader(Combatant c, bool moveOldBack)
		{
			if(this.members.Count == 0 || this.members[0] != c)
			{
				if(moveOldBack && this.members.Count > 0)
				{
					Combatant tmp = this.members[0];
					this.members.RemoveAt(0);
					this.members.Add(tmp);
				}
				if(this.members.Contains(c))
				{
					this.members.Remove(c);
				}
				this.members.Insert(0, c);
				
				// update battle group
				if(this.battleMembers.Contains(c))
				{
					this.battleLeaderIndex = this.battleMembers.IndexOf(c);
				}
			}
			this.FireChanged();
		}
		
		
		/*
		============================================================================
		Check functions
		============================================================================
		*/
		private bool InGroup(int id, List<Combatant> group)
		{
			for(int i=0; i<group.Count; i++)
			{
				if(group[i] != null && group[i].RealID == id)
				{
					return true;
				}
			}
			return false;
		}
		
		public bool IsMember(int id)
		{
			return this.InGroup(id, this.members);
		}
		
		public bool IsMember(Combatant c)
		{
			return this.members.Contains(c);
		}
		
		public bool IsBattleMember(int id)
		{
			return this.InGroup(id, this.battleMembers);
		}
		
		public bool IsBattleMember(Combatant c)
		{
			return this.battleMembers.Contains(c);
		}
		
		public bool IsInactive(int id)
		{
			return this.InGroup(id, this.inactiveMembers);
		}
		
		public bool IsInactive(Combatant c)
		{
			return this.inactiveMembers.Contains(c);
		}
		
		public bool AllDeadBattle()
		{
			if(this.battleMembers.Count > 0)
			{
				for(int i=0; i<this.battleMembers.Count; i++)
				{
					if(this.battleMembers[i] != null && 
						!this.battleMembers[i].Dead)
					{
						return false;
					}
				}
				return true;
			}
			return false;
		}
		
		
		/*
		============================================================================
		Group functions
		============================================================================
		*/
		public void Join(int id)
		{
			if(!this.IsMember(id))
			{
				Combatant c = this.GetInactive(id);
				if(c == null)
				{
					c = ORK.Combatants.Create(id, this);
					c.Init();
				}
				this.Join(c);
			}
		}
		
		public void Join(Combatant c)
		{
			if(c != null && !this.IsMember(c))
			{
				c.SetGroup(this);
				this.inactiveMembers.Remove(c);
				this.members.Add(c);
				this.JoinBattle(c);
				
				if(this == ORK.Game.ActiveGroup && c == this.Leader)
				{
					c.Inventory.showNotifications = true;
				}
				
				this.FireChanged();
			}
		}
		
		public void Leave(int id)
		{
			if(this.IsMember(id))
			{
				this.Leave(this.Get(id));
			}
		}
		
		public void Leave(Combatant c)
		{
			if(c != null)
			{
				this.UnlockBattleMember(c);
				this.LeaveBattle(c);
				this.members.Remove(c);
				this.inactiveMembers.Add(c);
				this.FireChanged();
			}
		}
		
		public void Remove(int id, bool setGroup)
		{
			this.Remove(this.Get(id), setGroup);
		}
		
		public void Remove(Combatant c, bool setGroup)
		{
			if(c != null)
			{
				if(setGroup)
				{
					c.SetGroup(null);
				}
				this.UnlockBattleMember(c);
				this.LeaveBattle(c);
				this.members.Remove(c);
				this.inactiveMembers.Remove(c);
				this.FireChanged();
			}
		}
		
		public void Regenerate(bool onlyBattle, bool revive)
		{
			if(onlyBattle)
			{
				for(int i=0; i<this.battleMembers.Count; i++)
				{
					if(this.battleMembers[i] != null)
					{
						this.battleMembers[i].Status.Regenerate();
						if(revive && this.battleMembers[i].Dead && 
							!this.battleMembers[i].Setting.noRevive)
						{
							this.battleMembers[i].Dead = false;
						}
					}
				}
			}
			else
			{
				for(int i=0; i<this.members.Count; i++)
				{
					if(this.members[i] != null)
					{
						this.members[i].Status.Regenerate();
						if(revive && this.members[i].Dead && 
							!this.members[i].Setting.noRevive)
						{
							this.members[i].Dead = false;
						}
					}
				}
			}
		}
		
		public void MarkHUDUpdate()
		{
			for(int i=0; i<this.members.Count; i++)
			{
				this.members[i].MarkHUDUpdate();
			}
		}
		
		
		/*
		============================================================================
		Battle functions
		============================================================================
		*/
		public void JoinBattle(Combatant c)
		{
			if(c != null && !this.IsBattleMember(c) && 
				(!this.IsPlayerControlled() || 
				this.battleMembers.Count < ORK.GameSettings.maxBattleGroup))
			{
				if(this.IsMember(c))
				{
					this.battleMembers.Add(c);
					if(this.Leader != null && this.Leader.GameObject != null && 
						(!this.IsPlayerControlled() || ORK.GameSettings.spawnGroup))
					{
						this.SpawnGroup(true);
					}
					this.FireChanged();
				}
				else
				{
					this.Join(c);
				}
			}
		}
		
		public void LeaveBattle(Combatant combatant)
		{
			if(combatant != null && !this.IsLockedBattleMember(combatant))
			{
				this.battleMembers.Remove(combatant);
				combatant.DestroyPrefab();
				this.PlayerChangeCheck(combatant);
				this.FireChanged();
			}
		}
		
		public void ChangeBattle(Combatant oldC, Combatant newC)
		{
			if(this.IsBattleMember(oldC) && 
				!this.IsLockedBattleMember(oldC) && 
				!this.IsBattleMember(newC))
			{
				this.battleMembers[this.battleMembers.IndexOf(oldC)] = newC;
				if(oldC.GameObject != null &&
					newC.GameObject == null)
				{
					Vector3 pos = oldC.GameObject.transform.position;
					Vector3 ea = oldC.GameObject.transform.eulerAngles;
					oldC.DestroyPrefab();
					
					newC.Spawn(pos, true, ea.y, false, Vector3.one);
				}
				else
				{
					oldC.DestroyPrefab();
					
					if(this.Leader != null && this.Leader.GameObject != null && 
						(!this.IsPlayerControlled() || ORK.GameSettings.spawnGroup))
					{
						this.SpawnGroup(true);
					}
				}
				
				this.PlayerChangeCheck(oldC);
				
				this.FireChanged();
			}
		}
		
		public void PlayerChangeCheck(Combatant combatant)
		{
			if(this.IsPlayerControlled() && 
				this.members.Count > 0 && 
				combatant == this.members[0] && 
				this.battleMembers.Count > 0)
			{
				ORK.Game.PlayerHandler.SetPlayer(this.battleMembers[0], false);
			}
		}
		
		
		/*
		============================================================================
		Index functions
		============================================================================
		*/
		private Combatant GetOffsetGroup(Combatant c, int offset, List<Combatant> group, ref int cycles)
		{
			int index = group.IndexOf(c) + offset;
			if(index < 0)
			{
				index = group.Count - 1;
				cycles++;
			}
			else if(index >= group.Count)
			{
				index = 0;
				cycles++;
			}
			return group[index];
		}
		
		public Combatant GetOffset(Combatant c, int offset, bool battleGroup)
		{
			int cycles = 0;
			if(battleGroup)
			{
				return this.GetOffsetGroup(c, offset, this.battleMembers, ref cycles);
			}
			else
			{
				return this.GetOffsetGroup(c, offset, this.members, ref cycles);
			}
		}
		
		public Combatant GetOffsetControllable(Combatant c, int offset, bool battleGroup)
		{
			int cycles = 0;
			Combatant found = c;
			do
			{
				if(battleGroup)
				{
					found = this.GetOffsetGroup(found, offset, this.battleMembers, ref cycles);
				}
				else
				{
					found = this.GetOffsetGroup(found, offset, this.members, ref cycles);
				}
				if(!found.Setting.aiControlled || 
					!found.Setting.notControllable)
				{
					return found;
				}
			} while(cycles < 2);
			
			return c;
		}
		
		public Combatant MemberAt(int index)
		{
			if(index >= 0 && index < this.members.Count)
			{
				return this.members[index];
			}
			else if(this.members.Count > 0)
			{
				return this.members[0];
			}
			return null;
		}
		
		public Combatant BattleMemberAt(int index)
		{
			if(index >= 0 && index < this.battleMembers.Count)
			{
				return this.battleMembers[index];
			}
			else if(this.battleMembers.Count > 0)
			{
				return this.battleMembers[0];
			}
			return null;
		}
		
		public Combatant NonBattleMemberAt(int index)
		{
			List<Combatant> nonBattle = this.GetNonBattle();
			if(index >= 0 && index < nonBattle.Count)
			{
				return nonBattle[index];
			}
			else if(nonBattle.Count > 0)
			{
				return nonBattle[0];
			}
			return null;
		}
		
		
		/*
		============================================================================
		Get member functions
		============================================================================
		*/
		public Combatant Get(int id)
		{
			for(int i=0; i<this.members.Count; i++)
			{
				if(this.members[i] != null && this.members[i].RealID == id)
				{
					return this.members[i];
				}
			}
			return null;
		}
		
		public Combatant GetInactive(int id)
		{
			for(int i=0; i<this.inactiveMembers.Count; i++)
			{
				if(this.inactiveMembers[i] != null && this.inactiveMembers[i].RealID == id)
				{
					return this.inactiveMembers[i];
				}
			}
			return null;
		}
		
		public Combatant GetMember(int id)
		{
			Combatant c = this.Get(id);
			if(c == null)
			{
				c = this.GetInactive(id);
			}
			return c;
		}
		
		public Combatant GetFirstAlive()
		{
			for(int i=0; i<this.battleMembers.Count; i++)
			{
				if(this.battleMembers[i] != null && 
					!this.battleMembers[i].Dead)
				{
					return this.battleMembers[i];
				}
			}
			for(int i=0; i<this.members.Count; i++)
			{
				if(this.members[i] != null && 
					!this.members[i].Dead)
				{
					return this.members[i];
				}
			}
			return this.Leader;
		}
		
		
		/*
		============================================================================
		Lock battle member functions
		============================================================================
		*/
		public void LockBattleMember(Combatant c)
		{
			if(c != null && this.IsBattleMember(c) && !this.IsLockedBattleMember(c))
			{
				this.lockedBattleMembers.Add(c);
				this.FireChanged();
			}
		}
		
		public void UnlockBattleMember(Combatant c)
		{
			if(c != null && this.IsBattleMember(c) && this.IsLockedBattleMember(c))
			{
				this.lockedBattleMembers.Remove(c);
				this.FireChanged();
			}
		}
		
		public bool IsLockedBattleMember(Combatant c)
		{
			return this.lockedBattleMembers.Contains(c);
		}
		
		
		/*
		============================================================================
		Hide member functions
		============================================================================
		*/
		public void HideMember(Combatant c)
		{
			if(c != null && this.IsMember(c))
			{
				this.lockedBattleMembers.Remove(c);
				this.battleMembers.Remove(c);
				this.hiddenMembers.Add(c);
				this.FireChanged();
			}
		}
		
		public void UnhideMember(Combatant c)
		{
			if(c != null && this.IsMember(c))
			{
				this.hiddenMembers.Remove(c);
				this.FireChanged();
			}
		}
		
		public bool IsHiddenMember(Combatant c)
		{
			return this.hiddenMembers.Contains(c);
		}
		
		
		/*
		============================================================================
		Spawn group functions
		============================================================================
		*/
		public BattleSystemType BattleType
		{
			get{ return this.battleType;}
			set{ this.battleType = value;}
		}
		
		public CombatantSpawner Spawner
		{
			get{ return this.spawner;}
		}
		
		public int SpawnerIndex
		{
			get{ return this.spawnerIndex;}
		}
		
		public void SetSpawner(CombatantSpawner spawner, int spawnerIndex, bool respawn)
		{
			this.spawner = spawner;
			this.spawnerIndex = spawnerIndex;
			this.spawnerRespawn = respawn;
		}
		
		public void CheckSpawner()
		{
			if(this.spawner != null && this.spawnerRespawn)
			{
				for(int i=0; i<this.battleMembers.Count; i++)
				{
					if(!this.battleMembers[i].Dead)
					{
						return;
					}
				}
				this.spawner.CheckRespawn(this.spawnerIndex);
			}
		}
		
		public void RespawnGroup()
		{
			List<Combatant> group = new List<Combatant>(this.GetBattle());
			for(int i=0; i<group.Count; i++)
			{
				if(!group[i].RespawnFlag)
				{
					group[i] = null;
				}
			}
			this.SpawnGroup(group);
		}
		
		public void SpawnGroup(bool onlyNonCreated)
		{
			List<Combatant> group = new List<Combatant>(this.GetBattle());
			if(onlyNonCreated)
			{
				for(int i=0; i<group.Count; i++)
				{
					if(group[i].GameObject != null)
					{
						group.RemoveAt(i--);
					}
				}
			}
			this.SpawnGroup(group);
		}
		
		public void SpawnGroup(List<Combatant> group)
		{
			group.Remove(this.Leader);
			for(int i=0; i<group.Count; i++)
			{
				if(group[i] != this.Leader && group[i] != null && 
					(!group[i].Dead || this.IsPlayerControlled()))
				{
					if(group[i].GameObject == null)
					{
						group[i].Spawn(this.Leader.GameObject.transform.TransformPoint(
							0, 1, -ORK.GameSettings.spawnDistance), true, 0, false, Vector3.one);
					}
					if(group[i].GameObject != null)
					{
						group[i].RespawnFlag = false;
						
						if(group.Count > 1)
						{
							if(group.Count <= 2)
							{
								group[i].GameObject.transform.RotateAround(
										this.Leader.GameObject.transform.position,
										Vector3.up, 45.0f - (90.0f * i));
							}
							else if(group.Count <= 6)
							{
								if(i % 2 == 0)
								{
									group[i].GameObject.transform.RotateAround(
											this.Leader.GameObject.transform.position,
											Vector3.up, (180.0f / group.Count) * i);
								}
								else
								{
									group[i].GameObject.transform.RotateAround(
											this.Leader.GameObject.transform.position,
											Vector3.up, -(180.0f / group.Count) * i);
								}
							}
							else
							{
								if(i % 2 == 0)
								{
									group[i].GameObject.transform.RotateAround(
											this.Leader.GameObject.transform.position,
											Vector3.up, (300.0f / (group.Count + 1)) * (i - 1));
								}
								else
								{
									group[i].GameObject.transform.RotateAround(
											this.Leader.GameObject.transform.position,
											Vector3.up, -(300.0f / (group.Count + 1)) * i);
								}
							}
						}
						group[i].GameObject.transform.rotation = this.Leader.GameObject.transform.rotation;
					}
				}
			}
		}
		
		public void DestroySpawnedGroup()
		{
			for(int i=0; i<this.members.Count; i++)
			{
				if(this.members[i] != this.Leader)
				{
					this.members[i].DestroyPrefab();
				}
			}
		}
		
		public void DestroyInstances()
		{
			for(int i=0; i<this.members.Count; i++)
			{
				this.members[i].DestroyPrefab();
			}
			for(int i=0; i<this.inactiveMembers.Count; i++)
			{
				this.inactiveMembers[i].DestroyPrefab();
			}
		}
		
		
		/*
		============================================================================
		Aggression functions
		============================================================================
		*/
		public void AggressionChangeGroup(Combatant combatant)
		{
			for(int i=0; i<this.battleMembers.Count; i++)
			{
				if(this.battleMembers[i] != combatant && 
					this.battleMembers[i].Setting.aggressionReactGroup && 
					combatant.Setting.aggressionNotifyRangeGroup.InRange(combatant, this.battleMembers[i]))
				{
					this.battleMembers[i].IsAggressive = combatant.IsAggressive;
				}
			}
		}
		
		public void AggressionChangeFaction(Combatant combatant)
		{
			for(int i=0; i<this.battleMembers.Count; i++)
			{
				if(this.battleMembers[i] != combatant && 
					this.battleMembers[i].Setting.aggressionReactFaction && 
					combatant.Setting.aggressionNotifyRangeFaction.InRange(combatant, this.battleMembers[i]))
				{
					this.battleMembers[i].IsAggressive = combatant.IsAggressive;
				}
			}
		}
		
		
		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();
			
			data.Set("factionID", this.factionID);
			data.Set("battleLeaderIndex", this.battleLeaderIndex);
			
			if(this.inventory != null)
			{
				data.Set("inventory", this.inventory.SaveGame());
			}
			
			// members
			DataObject[] tmp = new DataObject[this.members.Count];
			for(int i=0; i<tmp.Length; i++)
			{
				tmp[i] = this.members[i].SaveGame();
			}
			data.Set("members", tmp);
			
			// inactive members
			tmp = new DataObject[this.inactiveMembers.Count];
			for(int i=0; i<tmp.Length; i++)
			{
				tmp[i] = this.inactiveMembers[i].SaveGame();
			}
			data.Set("inactiveMembers", tmp);
			
			int[] tmp2 = new int[this.battleMembers.Count];
			for(int i=0; i<tmp2.Length; i++)
			{
				for(int j=0; j<this.members.Count; j++)
				{
					if(this.battleMembers[i] == this.members[j])
					{
						tmp2[i] = j;
					}
				}
			}
			data.Set("battleMembers", tmp2);
			
			tmp2 = new int[this.lockedBattleMembers.Count];
			for(int i=0; i<tmp2.Length; i++)
			{
				for(int j=0; j<this.members.Count; j++)
				{
					if(this.lockedBattleMembers[i] == this.members[j])
					{
						tmp2[i] = j;
					}
				}
			}
			data.Set("lockedBattleMembers", tmp2);
			
			tmp2 = new int[this.hiddenMembers.Count];
			for(int i=0; i<tmp2.Length; i++)
			{
				for(int j=0; j<this.members.Count; j++)
				{
					if(this.hiddenMembers[i] == this.members[j])
					{
						tmp2[i] = j;
					}
				}
			}
			data.Set("hiddenMembers", tmp2);
			
			return data;
		}

		public void LoadGame(DataObject data)
		{
			if(data != null)
			{
				data.Get("factionID", ref this.factionID);
				data.Get("battleLeaderIndex", ref this.battleLeaderIndex);
				
				DataObject inv = data.GetFile("inventory");
				if(inv != null)
				{
					this.inventory = new Inventory(this);
					this.inventory.LoadGame(inv);
				}
			}
		}

		public void LoadMembers(DataObject data)
		{
			if(data != null)
			{
				// members
				DataObject[] tmp = data.GetFileArray("members");
				if(tmp != null)
				{
					for(int i=0; i<tmp.Length; i++)
					{
						this.members.Add(new Combatant(tmp[i], this));
					}
				}
				
				// inactive members
				tmp = data.GetFileArray("inactiveMembers");
				if(tmp != null)
				{
					for(int i=0; i<tmp.Length; i++)
					{
						this.inactiveMembers.Add(new Combatant(tmp[i], this));
					}
				}
				
				int[] tmp2 = null;
				data.Get("battleMembers", out tmp2);
				if(tmp2 != null)
				{
					for(int i=0; i<tmp2.Length; i++)
					{
						this.battleMembers.Add(this.members[tmp2[i]]);
					}
				}
				
				tmp2 = null;
				data.Get("lockedBattleMembers", out tmp2);
				if(tmp2 != null)
				{
					for(int i=0; i<tmp2.Length; i++)
					{
						this.lockedBattleMembers.Add(this.members[tmp2[i]]);
					}
				}
				
				tmp2 = null;
				data.Get("hiddenMembers", out tmp2);
				if(tmp2 != null)
				{
					for(int i=0; i<tmp2.Length; i++)
					{
						this.hiddenMembers.Add(this.members[tmp2[i]]);
					}
				}
				
				// reset status for all
				for(int i=0; i<this.members.Count; i++)
				{
					this.members[i].MarkResetStatus();
				}
				for(int i=0; i<this.inactiveMembers.Count; i++)
				{
					this.inactiveMembers[i].MarkResetStatus();
				}
				
				if(this.inventory != null)
				{
					this.inventory.CheckSpace(0);
				}
			}
		}
	}
}
