
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Reflection
{
	public class CallParameter : BaseData
	{
		[ORKEditorHelp("Parameter Type", "Select the type of the parameter value.", "")]
		public ParameterType type = ParameterType.String;
		
		[ORKEditorHelp("String Value", "Define the string that will be used as parameter.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("type", ParameterType.String, endCheckGroup=true)]
		public string stringValue = "";
		
		[ORKEditorHelp("Bool Value", "Define the bool that will be used as parameter.", "")]
		[ORKEditorLayout("type", ParameterType.Bool, endCheckGroup=true)]
		public bool boolValue = false;
		
		[ORKEditorHelp("Int Value", "Define the int that will be used as parameter.", "")]
		[ORKEditorLayout("type", ParameterType.Int, endCheckGroup=true)]
		public int intValue = 0;
		
		[ORKEditorHelp("Float Value", "Define the float that will be used as parameter.", "")]
		[ORKEditorLayout("type", ParameterType.Float, endCheckGroup=true)]
		public float floatValue = 0;
		
		[ORKEditorHelp("Vector2 Value", "Define the Vector2 that will be used as parameter.", "")]
		[ORKEditorLayout("type", ParameterType.Vector2, endCheckGroup=true)]
		public Vector2 vector2Value = Vector2.zero;
		
		[ORKEditorHelp("Vector3 Value", "Define the Vector3 that will be used as parameter.", "")]
		[ORKEditorLayout("type", ParameterType.Vector3, endCheckGroup=true)]
		public Vector3 vector3Value = Vector3.zero;
		
		public CallParameter()
		{
			
		}
		
		public object GetValue()
		{
			if(ParameterType.String.Equals(this.type))
			{
				return this.stringValue;
			}
			else if(ParameterType.Bool.Equals(this.type))
			{
				return this.boolValue;
			}
			else if(ParameterType.Int.Equals(this.type))
			{
				return this.intValue;
			}
			else if(ParameterType.Float.Equals(this.type))
			{
				return this.floatValue;
			}
			else if(ParameterType.Vector2.Equals(this.type))
			{
				return this.vector2Value;
			}
			else if(ParameterType.Vector3.Equals(this.type))
			{
				return this.vector3Value;
			}
			return null;
		}
	}
}
