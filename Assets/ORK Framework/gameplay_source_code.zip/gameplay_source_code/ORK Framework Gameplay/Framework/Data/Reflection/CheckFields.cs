
using UnityEngine;
using System.Reflection;

namespace ORKFramework.Reflection
{
	public class CheckFields : BaseData
	{
		[ORKEditorHelp("Needed", "Either all or just one of the field/property checks needs to be valid.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public Needed needed = Needed.All;
		
		// parameters
		[ORKEditorArray(false, "Add Field", "Adds a field that will be checked.", "", 
			"Remove", "Removes this field.", "", 
			foldout=true, foldoutText=new string[] {"Field", "The field's value will be checked.", ""})]
		public CheckField[] field = new CheckField[0];
		
		public CheckFields()
		{
			
		}
		
		public bool Check(System.Object instance)
		{
			if(instance != null)
			{
				System.Type instanceType = instance.GetType();
				if(instanceType != null)
				{
					if(this.field.Length > 0)
					{
						for(int i=0; i<this.field.Length; i++)
						{
							if(this.field[i].Check(instance, instanceType))
							{
								if(Needed.One.Equals(this.needed))
								{
									return true;
								}
							}
							else if(Needed.All.Equals(this.needed))
							{
								return false;
							}
						}
						if(Needed.All.Equals(this.needed))
						{
							return true;
						}
						else
						{
							return false;
						}
					}
					else
					{
						return true;
					}
				}
			}
			return false;
		}
	}
}
