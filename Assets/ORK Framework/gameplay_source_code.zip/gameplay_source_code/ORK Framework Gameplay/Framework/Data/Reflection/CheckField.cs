
using UnityEngine;
using System.Collections.Generic;
using System.Reflection;

namespace ORKFramework.Reflection
{
	public class CheckField : BaseData
	{
		[ORKEditorHelp("Field Name", "The name of the field that will be checked.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string fieldName = "";
		
		[ORKEditorHelp("Is Property", "Check the value of a property.\n" +
			"If disabled, the value of a field will be checked.", "")]
		public bool isProperty = false;
		
		[ORKEditorHelp("Field Type", "Select the type of the field.", "")]
		public ParameterType type = ParameterType.String;
		
		
		// string
		[ORKEditorHelp("String Value", "Define the string value the field should have.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("type", ParameterType.String, endCheckGroup=true)]
		public string stringValue = "";
		
		
		// bool
		[ORKEditorHelp("Bool Value", "Define the bool value the field should have.", "")]
		[ORKEditorLayout("type", ParameterType.Bool, endCheckGroup=true)]
		public bool boolValue = false;
		
		
		// int
		[ORKEditorHelp("Int Value", "Define the int value the field should have.", "")]
		[ORKEditorLayout("type", ParameterType.Int, endCheckGroup=true)]
		public int intValue = 0;
		
		
		// float
		[ORKEditorHelp("Float Value", "Define the float value the field should have.", "")]
		[ORKEditorLayout("type", ParameterType.Float, endCheckGroup=true)]
		public float floatValue = 0;
		
		
		// vector2
		[ORKEditorHelp("Vector2 Value", "Define the Vector2 value the field should have.", "")]
		[ORKEditorLayout("type", ParameterType.Vector2, endCheckGroup=true)]
		public Vector2 vector2Value = Vector2.zero;
		
		
		// vector3
		[ORKEditorHelp("Vector3 Value", "Define the Vector3 value the field should have.", "")]
		[ORKEditorLayout("type", ParameterType.Vector3, endCheckGroup=true)]
		public Vector3 vector3Value = Vector3.zero;
		
		public CheckField()
		{
			
		}
		
		public System.Object GetValue()
		{
			if(ParameterType.String.Equals(this.type))
			{
				return this.stringValue;
			}
			else if(ParameterType.Bool.Equals(this.type))
			{
				return this.boolValue;
			}
			else if(ParameterType.Int.Equals(this.type))
			{
				return this.intValue;
			}
			else if(ParameterType.Float.Equals(this.type))
			{
				return this.floatValue;
			}
			else if(ParameterType.Vector2.Equals(this.type))
			{
				return this.vector2Value;
			}
			else if(ParameterType.Vector3.Equals(this.type))
			{
				return this.vector3Value;
			}
			return null;
		}
		
		public bool Check(System.Object instance, System.Type instanceType)
		{
			if(this.fieldName != "")
			{
				if(this.isProperty)
				{
					PropertyInfo propertyInfo = instanceType.GetProperty(this.fieldName);
					if(propertyInfo != null)
					{
						try
						{
							System.Object value = propertyInfo.GetValue(instance, null);
							return value != null && value.Equals(this.GetValue());
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Property change failed (" + instanceType + "): " + 
								this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Property not found (" + instanceType + "): " + this.fieldName);
					}
				}
				else
				{
					FieldInfo fieldInfo = instanceType.GetField(this.fieldName, 
						BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance );
					if(fieldInfo != null)
					{
						try
						{
							System.Object value = fieldInfo.GetValue(instance);
							return value != null && value.Equals(this.GetValue());
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Field change failed (" + instanceType + "): " + 
								this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Field not found (" + instanceType + "): " + this.fieldName);
					}
				}
			}
			return false;
		}
	}
}
