
using System.Collections.Generic;

namespace ORKFramework
{
	public class TurnSorter : IComparer<Combatant>
	{
		public int Compare(Combatant x , Combatant y)
		{
	        if(x.TurnValue < y.TurnValue)
			{
				return 1;
			}
			else if(x.TurnValue > y.TurnValue)
			{
				return -1;
			}
			else
			{
				return 0;
			}
	    }
	}
	
	public class DummyTurnSorter : IComparer<Combatant>
	{
		public int Compare(Combatant x , Combatant y)
		{
	        if(x.TurnValueDummy < y.TurnValueDummy)
			{
				return 1;
			}
			else if(x.TurnValueDummy > y.TurnValueDummy)
			{
				return -1;
			}
			else
			{
				return 0;
			}
	    }
	}
}
