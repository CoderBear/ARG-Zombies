
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class LogsSettings : BaseLanguageSettings
	{
		public Log[] data = new Log[] {new Log("Default Log")};
		
		public LogsSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}
		
		public override void SetRealIDs()
		{
			this.SetRealIDs(this.data);
		}
		
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "logs"; }
		}
		
		
		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			Log newData = new Log("New");
			ArrayHelper.Add(ref this.data, newData);
			DataHelper.Added(ORKDataType.Log);
			return this.data.Length - 1;
		}
		
		public override int Copy(int index)
		{
			Log newData = this.GetCopy(index);
			ArrayHelper.Add(ref this.data, newData);
			DataHelper.Added(ORKDataType.Log);
			return this.data.Length - 1;
		}
		
		public Log GetCopy(int index)
		{
			Log tmp = new Log();
			if(index >= 0 && index < this.data.Length)
			{
				tmp.SetData(this.data[index].GetData());
				tmp.RealID = index;
			}
			return tmp;
		}
		
		public override void Remove(int index)
		{
			ArrayHelper.RemoveAt(ref this.data, index);
			DataHelper.Removed(ORKDataType.Log, index);
		}
		
		public Log Get(int index)
		{
			if(index >= 0 && index < this.Count)
			{
				return this.data[index];
			}
			else if(this.data.Length > 0)
			{
				return this.data[0];
			}
			else
			{
				return null;
			}
		}
		
		public override void Move(int index, bool down)
		{
			if(down)
			{
				ArrayHelper.MoveDown(ref this.data, index);
			}
			else
			{
				ArrayHelper.MoveUp(ref this.data, index);
			}
			DataHelper.Moved(ORKDataType.Log, down, index);
		}
		
		
		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].languageInfo[ORK.Game.Language].GetName();
			}
			else
			{
				return "Log " + index + " not found";
			}
		}

		public override string[] GetNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i=0; i<names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = i + ": " + this.GetName(i);
				}
				else
				{
					names[i] = this.GetName(i);
				}
			}
			return names;
		}

		public string[] GetTypedNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i=0; i<names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = ORK.LogTypes.GetName(this.data[i].logTypeID) + "/" + i + ": " + this.GetName(i);
				}
				else
				{
					names[i] = this.GetName(i);
				}
			}
			return names;
		}
		
		public override int Count
		{
			get{ return this.data.Length;}
		}
		
		public override string GetDescription(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].languageInfo[ORK.Game.Language].GetDescription();
			}
			else
			{
				return "Log " + index + " not found";
			}
		}
		
		public override Texture2D GetIcon(int index)
		{
			Texture2D tex = null;
			
			if(index >= 0 && index < this.data.Length)
			{
				int l = ORK.Game.Language;
				tex = this.data[index].languageInfo[l].GetIcon();
				if(tex == null && l != 0)
				{
					tex = this.data[index].languageInfo[0].GetIcon();
				}
			}
			return tex;
		}
		
		
		/*
		============================================================================
		Log functions
		============================================================================
		*/
		public List<int> GetLogs(int logTypeID)
		{
			List<int> list = new List<int>();
			
			for(int i=0; i<this.data.Length; i++)
			{
				if(this.data[i].logTypeID == logTypeID)
				{
					list.Add(i);
				}
			}
			
			return list;
		}
	}
}

